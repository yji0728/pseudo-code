<#
.SYNOPSIS
    Automated EDR testing workflow with comprehensive validation.

.DESCRIPTION
    This script automates the execution of EDR (Endpoint Detection and Response) 
    testing samples and collects detailed results. It performs prerequisite checks,
    compiles C++ samples, executes various attack technique simulations, and 
    generates comprehensive test reports.

.PARAMETER BasicOnly
    Run only basic tests, skipping advanced scenarios.

.PARAMETER SkipCompilation
    Skip the C++ compilation step and use existing executables.

.PARAMETER LogFile
    Specify the output log file path. Defaults to 'edr_test_results.log'.

.PARAMETER Configuration
    Build configuration for C++ samples. Valid values: 'Debug', 'Release'.
    Defaults to 'Release'.

.PARAMETER Verbose
    Display detailed progress information during execution.

.EXAMPLE
    .\automated_test.ps1
    Runs all tests with default settings.

.EXAMPLE
    .\automated_test.ps1 -BasicOnly -LogFile "basic_test.log"
    Runs only basic tests and logs to a custom file.

.EXAMPLE
    .\automated_test.ps1 -SkipCompilation -Verbose
    Runs tests using existing executables with verbose output.

.NOTES
    Author: EDR Testing Tools Team
    Version: 2.0
    Last Modified: 2025-10-15
    
    WARNING: For testing purposes only in isolated environments.
    Requires administrator privileges for full functionality.

.LINK
    https://github.com/your-repo/edr-testing-tools
#>

[CmdletBinding()]
param(
    [Parameter(HelpMessage = "Run only basic tests")]
    [switch]$BasicOnly,
    
    [Parameter(HelpMessage = "Skip C++ compilation step")]
    [switch]$SkipCompilation,
    
    [Parameter(HelpMessage = "Path to the output log file")]
    [ValidateNotNullOrEmpty()]
    [string]$LogFile = "edr_test_results.log",
    
    [Parameter(HelpMessage = "Build configuration: Debug or Release")]
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Release'
)

#Requires -Version 5.1

# Strict mode for better error detection
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'
$InformationPreference = 'Continue'

# Script-scoped test results (avoid global variables)
$script:TestResults = [System.Collections.ArrayList]::new()

<#
.SYNOPSIS
    Writes a formatted test header to console and log.

.PARAMETER Title
    The title of the test section.
#>
function Write-TestHeader {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Title
    )
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $separator = '=' * 62
    
    $header = @"

$separator
    $Title
    Time: $timestamp
$separator
"@
    
    Write-Information $header
    Add-Content -Path $LogFile -Value $header
}

<#
.SYNOPSIS
    Records and displays a test result.

.PARAMETER TestName
    Name of the test being recorded.

.PARAMETER Status
    Test status: PASS, FAIL, SKIP, WARN, or INFO.

.PARAMETER Details
    Additional details about the test result.
#>
function Write-TestResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$TestName,
        
        [Parameter(Mandatory)]
        [ValidateSet('PASS', 'FAIL', 'SKIP', 'WARN', 'INFO')]
        [string]$Status,
        
        [Parameter(Mandatory)]
        [string]$Details
    )
    
    $timestamp = Get-Date -Format 'HH:mm:ss'
    $result = "[$timestamp] $TestName - $Status - $Details"
    
    # Use appropriate Write-* cmdlet based on status
    switch ($Status) {
        'PASS' { Write-Information $result }
        'FAIL' { Write-Error $result -ErrorAction Continue }
        'SKIP' { Write-Warning $result }
        'WARN' { Write-Warning $result }
        'INFO' { Write-Verbose $result }
    }
    
    Add-Content -Path $LogFile -Value $result
    
    $null = $script:TestResults.Add([PSCustomObject]@{
        Name    = $TestName
        Status  = $Status
        Details = $Details
        Time    = Get-Date
    })
}

<#
.SYNOPSIS
    Checks system prerequisites for running EDR tests.

.DESCRIPTION
    Validates administrator privileges, PowerShell version, available tools,
    and required directory structure.
#>
function Test-Prerequisite {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Checking Prerequisites'
    
    # Check administrator privileges
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal(
        [Security.Principal.WindowsIdentity]::GetCurrent()
    )
    $isAdmin = $currentPrincipal.IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator
    )
    
    if ($isAdmin) {
        Write-TestResult -TestName 'Admin Rights' -Status 'PASS' `
            -Details 'Running with administrator privileges'
    }
    else {
        Write-TestResult -TestName 'Admin Rights' -Status 'WARN' `
            -Details 'Not running as administrator - some tests may fail'
    }
    
    # Check PowerShell version
    $psVersion = $PSVersionTable.PSVersion
    $versionString = "$($psVersion.Major).$($psVersion.Minor)"
    if ($psVersion.PSObject.Properties['Build'] -and $psVersion.Build -gt 0) {
        $versionString += ".$($psVersion.Build)"
    }
    Write-TestResult -TestName 'PowerShell Version' -Status 'INFO' `
        -Details "Version $versionString"
    
    # Check compilation tools
    $clPath = Get-Command cl.exe -ErrorAction SilentlyContinue
    if ($clPath) {
        Write-TestResult -TestName 'C++ Compiler' -Status 'PASS' `
            -Details "cl.exe found at $($clPath.Source)"
    }
    else {
        Write-TestResult -TestName 'C++ Compiler' -Status 'WARN' `
            -Details 'cl.exe not found - C++ compilation will be skipped'
    }
    
    # Check required directories
    $requiredDirs = @(
        'samples\process_injection',
        'samples\fileless',
        'samples\shellcode',
        'samples\combined'
    )
    
    foreach ($dir in $requiredDirs) {
        if (Test-Path $dir) {
            Write-TestResult -TestName 'Directory Check' -Status 'PASS' `
                -Details "$dir exists"
        }
        else {
            Write-TestResult -TestName 'Directory Check' -Status 'FAIL' `
                -Details "$dir not found"
        }
    }
}

<#
.SYNOPSIS
    Builds a single C++ sample file.

.PARAMETER CppFile
    FileInfo object representing the C++ source file.

.PARAMETER Configuration
    Build configuration (Debug or Release).

.OUTPUTS
    Boolean indicating build success.
#>
function Build-CppSample {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)]
        [System.IO.FileInfo]$CppFile,
        
        [Parameter()]
        [ValidateSet('Debug', 'Release')]
        [string]$Configuration = 'Release',
        
        [Parameter()]
        [switch]$Skip
    )
    
    if ($Skip) {
        Write-TestResult -TestName 'Compilation' -Status 'SKIP' `
            -Details 'Skipped by user request'
        return $true
    }
    
    $outputName = [System.IO.Path]::GetFileNameWithoutExtension($CppFile.Name) + '.exe'
    $outputPath = Join-Path $CppFile.DirectoryName $outputName
    
    Write-Verbose "Compiling $($CppFile.Name)..."
    
    # Build compiler arguments
    $compilerArgs = @(
        '/EHsc'
        '/std:c++17'
        "/I$PSScriptRoot\..\include"
        $CppFile.FullName
        "/Fe:$outputPath"
        '/link'
        '/SUBSYSTEM:CONSOLE'
    )
    
    if ($Configuration -eq 'Debug') {
        $compilerArgs += '/Zi', '/Od'
    }
    else {
        $compilerArgs += '/O2'
    }
    
    try {
        $process = Start-Process -FilePath 'cl.exe' `
            -ArgumentList $compilerArgs `
            -NoNewWindow `
            -Wait `
            -PassThru `
            -RedirectStandardError "$env:TEMP\cl_error.log" `
            -RedirectStandardOutput "$env:TEMP\cl_output.log"
        
        if ($process.ExitCode -eq 0 -and (Test-Path $outputPath)) {
            $fileSize = (Get-Item $outputPath).Length / 1KB
            Write-TestResult -TestName "Build: $($CppFile.Name)" -Status 'PASS' `
                -Details "Compiled successfully ($([Math]::Round($fileSize, 1)) KB)"
            return $true
        }
        else {
            $errorContent = Get-Content "$env:TEMP\cl_error.log" -Raw
            Write-TestResult -TestName "Build: $($CppFile.Name)" -Status 'FAIL' `
                -Details "Compilation failed: $errorContent"
            return $false
        }
    }
    catch {
        Write-TestResult -TestName "Build: $($CppFile.Name)" -Status 'FAIL' `
            -Details "Error: $($_.Exception.Message)"
        return $false
    }
    finally {
        # Clean up temporary files
        Remove-Item "$env:TEMP\cl_error.log" -ErrorAction SilentlyContinue
        Remove-Item "$env:TEMP\cl_output.log" -ErrorAction SilentlyContinue
    }
}

<#
.SYNOPSIS
    Builds all C++ samples in the project.
#>
function Build-AllCppSample {
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$Skip,
        
        [Parameter()]
        [ValidateSet('Debug', 'Release')]
        [string]$BuildConfiguration = 'Release'
    )
    
    Write-TestHeader -Title 'Building C++ Samples'
    
    if ($Skip) {
        Write-Information 'Compilation skipped by user request'
        return
    }
    
    $cppFiles = Get-ChildItem -Path 'samples' -Recurse -Filter '*.cpp'
    $successCount = 0
    $totalCount = $cppFiles.Count
    
    foreach ($file in $cppFiles) {
        if (Build-CppSample -CppFile $file -Configuration $BuildConfiguration) {
            $successCount++
        }
    }
    
    Write-Information "`nBuild Summary: $successCount/$totalCount successful"
}

<#
.SYNOPSIS
    Tests process injection techniques.
#>
function Test-ProcessInjection {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Process Injection Tests'
    
    $samples = @(
        @{Name = 'DLL Injection'; Path = 'samples\process_injection\dll_injection.exe' },
        @{Name = 'Process Hollowing'; Path = 'samples\process_injection\process_hollowing.exe' },
        @{Name = 'APC Injection'; Path = 'samples\process_injection\apc_injection.exe' }
    )
    
    foreach ($sample in $samples) {
        if (Test-Path $sample.Path) {
            Write-Verbose "Running $($sample.Name)..."
            
            try {
                $process = Start-Process -FilePath $sample.Path `
                    -NoNewWindow `
                    -Wait `
                    -PassThru `
                    -RedirectStandardOutput "$env:TEMP\test_output.log" `
                    -RedirectStandardError "$env:TEMP\test_error.log"
                
                if ($process.ExitCode -eq 0) {
                    Write-TestResult -TestName $sample.Name -Status 'PASS' `
                        -Details 'Executed successfully'
                }
                else {
                    $errorContent = Get-Content "$env:TEMP\test_error.log" -Raw
                    Write-TestResult -TestName $sample.Name -Status 'FAIL' `
                        -Details "Exit code: $($process.ExitCode), Error: $errorContent"
                }
            }
            catch {
                Write-TestResult -TestName $sample.Name -Status 'FAIL' `
                    -Details "Exception: $($_.Exception.Message)"
            }
            finally {
                Remove-Item "$env:TEMP\test_output.log" -ErrorAction SilentlyContinue
                Remove-Item "$env:TEMP\test_error.log" -ErrorAction SilentlyContinue
            }
        }
        else {
            Write-TestResult -TestName $sample.Name -Status 'SKIP' `
                -Details 'Executable not found'
        }
    }
}

<#
.SYNOPSIS
    Tests fileless attack techniques.
#>
function Test-FilelessTechnique {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Fileless Technique Tests'
    
    $samples = @(
        @{Name = 'Memory Execution'; Path = 'samples\fileless\memory_execution.ps1' },
        @{Name = 'WMI Execution'; Path = 'samples\fileless\wmi_execution.ps1' }
    )
    
    foreach ($sample in $samples) {
        if (Test-Path $sample.Path) {
            Write-Verbose "Running $($sample.Name)..."
            
            try {
                & $sample.Path
                Write-TestResult -TestName $sample.Name -Status 'PASS' `
                    -Details 'Executed successfully'
            }
            catch {
                Write-TestResult -TestName $sample.Name -Status 'FAIL' `
                    -Details "Error: $($_.Exception.Message)"
            }
        }
        else {
            Write-TestResult -TestName $sample.Name -Status 'SKIP' `
                -Details 'Script not found'
        }
    }
}

<#
.SYNOPSIS
    Tests shellcode execution techniques.
#>
function Test-ShellcodeExecution {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Shellcode Execution Tests'
    
    $samplePath = 'samples\shellcode\shellcode_injection.exe'
    
    if (Test-Path $samplePath) {
        Write-Verbose 'Running Shellcode Injection...'
        
        try {
            $process = Start-Process -FilePath $samplePath `
                -NoNewWindow `
                -Wait `
                -PassThru
            
            if ($process.ExitCode -eq 0) {
                Write-TestResult -TestName 'Shellcode Injection' -Status 'PASS' `
                    -Details 'Executed successfully'
            }
            else {
                Write-TestResult -TestName 'Shellcode Injection' -Status 'FAIL' `
                    -Details "Exit code: $($process.ExitCode)"
            }
        }
        catch {
            Write-TestResult -TestName 'Shellcode Injection' -Status 'FAIL' `
                -Details "Error: $($_.Exception.Message)"
        }
    }
    else {
        Write-TestResult -TestName 'Shellcode Injection' -Status 'SKIP' `
            -Details 'Executable not found'
    }
}

<#
.SYNOPSIS
    Tests combined/multi-stage attack techniques.
#>
function Test-CombinedAttack {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Combined Attack Tests'
    
    $samplePath = 'samples\combined\multi_stage_attack.exe'
    
    if (Test-Path $samplePath) {
        Write-Verbose 'Running Multi-Stage Attack...'
        
        try {
            $process = Start-Process -FilePath $samplePath `
                -NoNewWindow `
                -Wait `
                -PassThru
            
            if ($process.ExitCode -eq 0) {
                Write-TestResult -TestName 'Multi-Stage Attack' -Status 'PASS' `
                    -Details 'Executed successfully'
            }
            else {
                Write-TestResult -TestName 'Multi-Stage Attack' -Status 'FAIL' `
                    -Details "Exit code: $($process.ExitCode)"
            }
        }
        catch {
            Write-TestResult -TestName 'Multi-Stage Attack' -Status 'FAIL' `
                -Details "Error: $($_.Exception.Message)"
        }
    }
    else {
        Write-TestResult -TestName 'Multi-Stage Attack' -Status 'SKIP' `
            -Details 'Executable not found'
    }
}

<#
.SYNOPSIS
    Displays a summary of all test results.
#>
function Show-TestSummary {
    [CmdletBinding()]
    param()
    
    Write-TestHeader -Title 'Test Summary'
    
    # Convert to array for reliable Count access
    $allResults = @($script:TestResults)
    
    # Count results by status with safe null handling
    $passCount = @($allResults | Where-Object { $_.Status -eq 'PASS' }).Count
    $failCount = @($allResults | Where-Object { $_.Status -eq 'FAIL' }).Count
    $skipCount = @($allResults | Where-Object { $_.Status -eq 'SKIP' }).Count
    $warnCount = @($allResults | Where-Object { $_.Status -eq 'WARN' }).Count
    
    $total = $allResults.Count
    
    if ($total -eq 0) {
        Write-Warning 'No test results recorded'
        return
    }
    
    $successRate = if ($total -gt 0) { [Math]::Round(($passCount / $total) * 100, 2) } else { 0 }
    
    $summary = @"

Test Execution Summary:
-----------------------
Total Tests:     $total
Passed:          $passCount
Failed:          $failCount
Skipped:         $skipCount
Warnings:        $warnCount

Success Rate:    $successRate%

Log File:        $LogFile
"@
    
    Write-Information $summary
    Add-Content -Path $LogFile -Value $summary
    
    # Display failed tests
    $failedTests = $allResults | Where-Object { $_.Status -eq 'FAIL' }
    if ($failedTests) {
        Write-Warning "`nFailed Tests:"
        foreach ($test in $failedTests) {
            Write-Warning "  - $($test.Name): $($test.Details)"
        }
    }
}

# Main execution flow
try {
    Write-Information "EDR Testing Workflow Started" -InformationAction Continue
    Write-Information "Configuration: $Configuration" -InformationAction Continue
    Write-Information "Log File: $LogFile`n" -InformationAction Continue
    
    # Initialize log file
    "EDR Test Results - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Out-File -FilePath $LogFile
    "=" * 62 | Out-File -FilePath $LogFile -Append
    
    # Run test phases
    Test-Prerequisite
    Build-AllCppSample -Skip:$SkipCompilation -BuildConfiguration $Configuration
    Test-ProcessInjection
    Test-FilelessTechnique
    Test-ShellcodeExecution
    
    if (-not $BasicOnly) {
        Test-CombinedAttack
    }
    
    Show-TestSummary
    
    Write-Information "`n✅ Testing workflow completed" -InformationAction Continue
}
catch {
    Write-Error "Fatal error in test execution: $($_.Exception.Message)"
    Write-Error $_.ScriptStackTrace
    exit 1
}
finally {
    # Cleanup
    Write-Verbose 'Performing cleanup...'
}
