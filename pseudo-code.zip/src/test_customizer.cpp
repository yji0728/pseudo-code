// Minimal implementation of Test Customization System
#include "../include/test_customizer.hpp"
#include "../include/logger.hpp"

#include <fstream>
#include <sstream>
#include <algorithm>
#pragma comment(lib, "advapi32.lib")

using namespace EDR;

namespace {
	ExecutionMode ParseExecutionMode(const std::string& s) {
		std::string v = s; 
		std::transform(v.begin(), v.end(), v.begin(), ::tolower);
		if (v == "sequential") return ExecutionMode::SEQUENTIAL;
		if (v == "parallel") return ExecutionMode::PARALLEL;
		if (v == "conditional") return ExecutionMode::CONDITIONAL;
		if (v == "chain") return ExecutionMode::CHAIN;
		return ExecutionMode::SEQUENTIAL;
	}

	std::string ToString(ExecutionMode m) {
		switch (m) {
			case ExecutionMode::SEQUENTIAL: return "sequential";
			case ExecutionMode::PARALLEL: return "parallel";
			case ExecutionMode::CONDITIONAL: return "conditional";
			case ExecutionMode::CHAIN: return "chain";
		}
		return "sequential";
	}

	ParameterType ParseParamType(const std::string& s) {
		std::string v = s; 
		std::transform(v.begin(), v.end(), v.begin(), ::tolower);
		if (v == "string") return ParameterType::STRING;
		if (v == "integer") return ParameterType::INTEGER;
		if (v == "boolean") return ParameterType::BOOLEAN;
		if (v == "process_id") return ParameterType::PROCESS_ID;
		if (v == "shellcode") return ParameterType::SHELLCODE;
		if (v == "file_path") return ParameterType::FILE_PATH;
		if (v == "registry_key") return ParameterType::REGISTRY_KEY;
		return ParameterType::STRING;
	}

	std::string ToString(ParameterType t) {
		switch (t) {
			case ParameterType::STRING: return "string";
			case ParameterType::INTEGER: return "integer";
			case ParameterType::BOOLEAN: return "boolean";
			case ParameterType::PROCESS_ID: return "process_id";
			case ParameterType::SHELLCODE: return "shellcode";
			case ParameterType::FILE_PATH: return "file_path";
			case ParameterType::REGISTRY_KEY: return "registry_key";
		}
		return "string";
	}
}

// -------------------- ExecutionCondition --------------------
bool ExecutionCondition::Evaluate() const {
	// Minimal evaluation so that demo can run without system queries.
	// Implement basic file/process checks using helper functions when possible.
	try {
		if (conditionType == "file_exists") {
			bool ok = CheckFileExists(parameters.value("filepath", ""));
			return negate ? !ok : ok;
		}
		if (conditionType == "process_exists") {
			bool ok = CheckProcessExists(parameters.value("process_name", ""));
			return negate ? !ok : ok;
		}
		if (conditionType == "is_elevated") {
			bool ok = CheckIsElevated();
			return negate ? !ok : ok;
		}
		// Fallback: pass
		return !negate;
	} catch (...) {
		return !negate; // be permissive on error
	}
}

// -------------------- CustomTest --------------------
CustomTest CustomTest::FromJSON(const json& j) {
	CustomTest t;
	t.id = j.value("id", "");
	t.name = j.value("name", t.id);
	t.description = j.value("description", "");
	t.techniqueId = j.value("techniqueId", "");
	t.category = j.value("category", "");
	t.executionMode = ParseExecutionMode(j.value("executionMode", "sequential"));
	t.priority = j.value("priority", 0);
	t.maxRetries = j.value("maxRetries", 1);
	t.timeout = std::chrono::seconds(j.value("timeout", 60));

	if (j.contains("parameters") && j["parameters"].is_array()) {
		for (const auto& pj : j["parameters"]) {
			TestParameter p;
			p.name = pj.value("name", "");
			p.type = ParseParamType(pj.value("type", "string"));
			p.value = pj.value("value", json());
			p.description = pj.value("description", "");
			p.required = pj.value("required", true);
			p.defaultValue = pj.value("default", json());
			t.parameters.push_back(std::move(p));
		}
	}

	if (j.contains("preconditions") && j["preconditions"].is_array()) {
		for (const auto& cj : j["preconditions"]) {
			ExecutionCondition c;
			c.conditionType = cj.value("conditionType", "");
			if (cj.contains("parameters")) c.parameters = cj["parameters"];
			c.negate = cj.value("negate", false);
			t.preconditions.push_back(std::move(c));
		}
	}

	if (j.contains("postconditions") && j["postconditions"].is_array()) {
		for (const auto& cj : j["postconditions"]) {
			ExecutionCondition c;
			c.conditionType = cj.value("conditionType", "");
			if (cj.contains("parameters")) c.parameters = cj["parameters"];
			c.negate = cj.value("negate", false);
			t.postconditions.push_back(std::move(c));
		}
	}

	if (j.contains("dependencies") && j["dependencies"].is_array()) {
		for (const auto& d : j["dependencies"]) t.dependencies.push_back(d.get<std::string>());
	}
	return t;
}

json CustomTest::ToJSON() const {
	json j;
	j["id"] = id;
	j["name"] = name;
	j["description"] = description;
	j["techniqueId"] = techniqueId;
	j["category"] = category;
	j["executionMode"] = ToString(executionMode);
	j["priority"] = priority;
	j["maxRetries"] = maxRetries;
	j["timeout"] = static_cast<int>(timeout.count());
	j["parameters"] = json::array();
	for (const auto& p : parameters) {
		json pj;
		pj["name"] = p.name;
		pj["type"] = ToString(p.type);
		pj["value"] = p.value;
		pj["description"] = p.description;
		pj["required"] = p.required;
		if (!p.defaultValue.is_null()) pj["default"] = p.defaultValue;
		j["parameters"].push_back(std::move(pj));
	}
	return j;
}

bool CustomTest::Validate() const {
	if (id.empty() || techniqueId.empty()) return false;
	return true;
}

void CustomTest::SetParameter(const std::string& name, const json& value) {
	for (auto& p : parameters) {
		if (p.name == name) { p.value = value; return; }
	}
	// If not found, add as loose param
	TestParameter p; p.name = name; p.type = ParameterType::STRING; p.value = value; p.required = false;
	parameters.push_back(std::move(p));
}

json CustomTest::GetParameter(const std::string& name) const {
	for (const auto& p : parameters) if (p.name == name) return p.value;
	return json();
}

// -------------------- TestChain --------------------
TestChain TestChain::FromJSON(const json& j) {
	TestChain c;
	c.id = j.value("id", "");
	c.name = j.value("name", c.id);
	c.description = j.value("description", "");
	c.executionMode = ParseExecutionMode(j.value("executionMode", "sequential"));
	c.stopOnFirstFailure = j.value("stopOnFirstFailure", false);
	c.shareContext = j.value("shareContext", false);
	if (j.contains("testIds") && j["testIds"].is_array())
		for (const auto& t : j["testIds"]) c.testIds.push_back(t.get<std::string>());
	return c;
}

json TestChain::ToJSON() const {
	json j;
	j["id"] = id;
	j["name"] = name;
	j["description"] = description;
	j["executionMode"] = ToString(executionMode);
	j["stopOnFirstFailure"] = stopOnFirstFailure;
	j["shareContext"] = shareContext;
	j["testIds"] = testIds;
	return j;
}

// -------------------- TestScenario --------------------
TestScenario TestScenario::LoadFromFile(const std::string& filepath) {
	std::ifstream f(filepath, std::ios::binary);
	if (!f) {
		throw EDR::Exception(EDR::ErrorCode::FILE_NOT_FOUND, "Failed to open scenario file", filepath);
	}
	std::stringstream ss; ss << f.rdbuf();
	auto j = json::parse(ss.str());
	return FromJSON(j);
}

void TestScenario::SaveToFile(const std::string& filepath) const {
	std::ofstream f(filepath, std::ios::binary);
	auto j = ToJSON();
	f << j.dump(2);
}

TestScenario TestScenario::FromJSON(const json& j) {
	TestScenario s;
	s.id = j.value("id", "");
	s.name = j.value("name", s.id);
	s.description = j.value("description", "");
	s.author = j.value("author", "");
	s.version = j.value("version", "1.0");
	if (j.contains("globalParameters") && j["globalParameters"].is_object()) {
		for (auto it = j["globalParameters"].begin(); it != j["globalParameters"].end(); ++it) {
			s.globalParameters[it.key()] = it.value();
		}
	}
	if (j.contains("preconditions") && j["preconditions"].is_array()) {
		for (const auto& cj : j["preconditions"]) {
			ExecutionCondition c;
			c.conditionType = cj.value("conditionType", "");
			if (cj.contains("parameters")) c.parameters = cj["parameters"];
			c.negate = cj.value("negate", false);
			s.preconditions.push_back(std::move(c));
		}
	}
	if (j.contains("tests") && j["tests"].is_array()) {
		for (const auto& tj : j["tests"]) s.tests.push_back(CustomTest::FromJSON(tj));
	}
	if (j.contains("chains") && j["chains"].is_array()) {
		for (const auto& cj : j["chains"]) s.chains.push_back(TestChain::FromJSON(cj));
	}
	return s;
}

json TestScenario::ToJSON() const {
	json j;
	j["id"] = id;
	j["name"] = name;
	j["description"] = description;
	j["author"] = author;
	j["version"] = version;
	j["globalParameters"] = globalParameters;
	j["preconditions"] = json::array();
	for (const auto& c : preconditions) {
		json cj; cj["conditionType"] = c.conditionType; cj["parameters"] = c.parameters; cj["negate"] = c.negate; j["preconditions"].push_back(cj);
	}
	j["tests"] = json::array();
	for (const auto& t : tests) j["tests"].push_back(t.ToJSON());
	j["chains"] = json::array();
	for (const auto& c : chains) j["chains"].push_back(c.ToJSON());
	return j;
}

bool TestScenario::Validate() const {
	return !id.empty();
}

void TestScenario::AddTest(const CustomTest& test) { tests.push_back(test); }
void TestScenario::AddChain(const TestChain& chain) { chains.push_back(chain); }
void TestScenario::SetGlobalParameter(const std::string& name, const json& value) { globalParameters[name] = value; }

// -------------------- TestCustomizer --------------------
TestCustomizer* TestCustomizer::instance_ = nullptr;

std::vector<TestResult> TestCustomizer::ExecuteScenario(
	const std::string& scenarioId,
	const std::map<std::string, json>& parameters
) {
	std::vector<TestResult> results;
	auto scenario = GetScenario(scenarioId);

	// Evaluate preconditions (permissive)
	for (const auto& c : scenario.preconditions) { (void)c.Evaluate(); }

	// Simple behavior: execute tests sequentially if they are registered with executeFunction
	for (const auto& t : scenario.tests) {
		if (registeredTests_.count(t.id) == 0) {
			// If not registered, skip
			continue;
		}
		auto r = ExecuteTest(t.id, parameters);
		results.push_back(std::move(r));
	}

	// Chains not executed here for simplicity
	return results;
}

TestResult TestCustomizer::ExecuteTest(
	const std::string& testId,
	const std::map<std::string, json>& parameters
) {
	auto it = registeredTests_.find(testId);
	if (it == registeredTests_.end()) {
		TestResult r; r.techniqueId = ""; r.success = false; r.errorMessage = "Test not found: " + testId; return r;
	}
	const CustomTest& t = it->second;

	// Merge parameters: start from test defaults then apply overrides
	std::map<std::string, json> finalParams;
	for (const auto& p : t.parameters) {
		if (!p.value.is_null()) finalParams[p.name] = p.value;
		else if (!p.defaultValue.is_null()) finalParams[p.name] = p.defaultValue;
	}
	for (const auto& kv : parameters) finalParams[kv.first] = kv.second;

	auto start = std::chrono::steady_clock::now();
	TestResult r;
	r.techniqueId = t.techniqueId;
	r.techniqueName = t.name;
	try {
		if (t.executeFunction) {
			r = t.executeFunction(finalParams);
		} else {
			r.success = true;
			r.output = "Executed stub for test '" + t.id + "'";
		}
	} catch (const std::exception& e) {
		r.success = false;
		r.errorMessage = e.what();
	}
	auto end = std::chrono::steady_clock::now();
	r.duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
	context_.SetResult(testId, r);
	return r;
}

std::vector<TestResult> TestCustomizer::ExecuteChain(
	const TestChain& chain,
	const std::map<std::string, json>& parameters
) {
	std::vector<TestResult> results;
	for (const auto& id : chain.testIds) {
		auto r = ExecuteTest(id, parameters);
		results.push_back(r);
		if (chain.stopOnFirstFailure && !r.success) break;
	}
	return results;
}

void TestCustomizer::RegisterBuiltInTests() {
	RegisterTest(CreateDLLInjectionTest());
	RegisterTest(CreateProcessHollowingTest());
	RegisterTest(CreateAPCInjectionTest());
	RegisterTest(CreateShellcodeInjectionTest());
	RegisterTest(CreateFilelessExecutionTest());
}

CustomTest TestCustomizer::CreateTestTemplate(
	const std::string& id,
	const std::string& name,
	const std::string& techniqueId
) {
	CustomTest t; t.id = id; t.name = name; t.techniqueId = techniqueId; t.description = "Template"; return t;
}

TestScenario TestCustomizer::CreateScenarioTemplate(
	const std::string& id,
	const std::string& name
) {
	TestScenario s; s.id = id; s.name = name; return s;
}

// -------------------- Condition helpers --------------------
bool EDR::CheckProcessExists(const std::string& /*processName*/) {
	// Lightweight stub: not scanning processes for now
	return true;
}

bool EDR::CheckMemoryAvailable(size_t /*requiredBytes*/) {
	return true;
}

bool EDR::CheckOSVersion(const std::string& /*minVersion*/) {
	return true;
}

bool EDR::CheckFileExists(const std::string& filepath) {
	DWORD attr = GetFileAttributesA(filepath.c_str());
	return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
}

bool EDR::CheckRegistryKeyExists(const std::string& /*keyPath*/) {
	return true;
}

bool EDR::CheckIsElevated() {
	BOOL isElevated = FALSE;
	HANDLE token = NULL;
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return false;
	TOKEN_ELEVATION elevation{};
	DWORD retSize = 0;
	BOOL ok = GetTokenInformation(token, TokenElevation, &elevation, sizeof(elevation), &retSize);
	CloseHandle(token);
	if (!ok) return false;
	isElevated = elevation.TokenIsElevated;
	return isElevated ? true : false;
}

// -------------------- Built-in test factories (stubs) --------------------
CustomTest EDR::CreateDLLInjectionTest() {
	CustomTest t; t.id = "dll_injection"; t.name = "DLL Injection"; t.techniqueId = "T1055.001";
	t.executeFunction = [](const std::map<std::string, json>&){ TestResult r; r.techniqueId="T1055.001"; r.techniqueName="DLL Injection"; r.success=true; r.output="Stub executed"; return r; };
	return t;
}

CustomTest EDR::CreateProcessHollowingTest() {
	CustomTest t; t.id = "process_hollowing"; t.name = "Process Hollowing"; t.techniqueId = "T1055.012";
	t.executeFunction = [](const std::map<std::string, json>&){ TestResult r; r.techniqueId="T1055.012"; r.techniqueName="Process Hollowing"; r.success=true; r.output="Stub executed"; return r; };
	return t;
}

CustomTest EDR::CreateAPCInjectionTest() {
	CustomTest t; t.id = "apc_injection"; t.name = "APC Injection"; t.techniqueId = "T1055.004";
	t.executeFunction = [](const std::map<std::string, json>&){ TestResult r; r.techniqueId="T1055.004"; r.techniqueName="APC Injection"; r.success=true; r.output="Stub executed"; return r; };
	return t;
}

CustomTest EDR::CreateShellcodeInjectionTest() {
	CustomTest t; t.id = "shellcode_injection"; t.name = "Shellcode Injection"; t.techniqueId = "T1055";
	t.executeFunction = [](const std::map<std::string, json>&){ TestResult r; r.techniqueId="T1055"; r.techniqueName="Shellcode Injection"; r.success=true; r.output="Stub executed"; return r; };
	return t;
}

CustomTest EDR::CreateFilelessExecutionTest() {
	CustomTest t; t.id = "fileless_execution"; t.name = "Fileless Execution"; t.techniqueId = "T1055";
	t.executeFunction = [](const std::map<std::string, json>&){ TestResult r; r.techniqueId="T1055"; r.techniqueName="Fileless Execution"; r.success=true; r.output="Stub executed"; return r; };
	return t;
}

