/**
 * @file edr_cli.cpp
 * @brief 고급 커맨드라인 인터페이스 (Advanced Command-Line Interface)
 * @details
 * 기능:
 * - 기법 실행 (run)
 * - 기법 리스트 조회 (list)
 * - 설정 관리 (config)
 * - 보고서 생성 (report)
 * - 검증 모드 (validate)
 * - 프로파일 관리 (profile)
 * 
 * 사용 예제:
 * @code
 * edr-cli run --technique T1055.001
 * edr-cli run --techniques T1055.001,T1055.012 --output report.json
 * edr-cli list techniques
 * edr-cli config show
 * edr-cli report --format html
 * @endcode
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include "../include/config_manager.hpp"
#include "../include/logger.hpp"
#include "../include/detection_validator.hpp"
#include "../include/report_generator.hpp"

using namespace EDR;

// 콘솔 색상
void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// 배너 출력
void PrintBanner() {
    SetColor(11); // Cyan
    std::cout << R"(
╔══════════════════════════════════════════════════════════════╗
║              EDR Testing Tools - CLI v1.0                   ║
║         Advanced Command-Line Interface Tool                ║
╚══════════════════════════════════════════════════════════════╝
)" << std::endl;
    SetColor(7); // White
}

// 도움말 출력
void PrintHelp() {
    std::cout << R"(
Usage: edr-cli <command> [options]

Commands:
  run          Execute techniques
  list         List available items
  config       Manage configuration
  report       Generate reports
  validate     Validate detection results
  profile      Manage configuration profiles
  help         Show this help message

Options:
  --technique <ID>         Single technique ID (e.g., T1055.001)
  --techniques <IDs>       Multiple technique IDs (comma-separated)
  --scenario <name>        Test scenario name
  --profile <name>         Configuration profile
  --output <file>          Output file path
  --format <fmt>           Output format (html/json/csv/txt)
  --config <file>          Configuration file path
  --verbose                Enable verbose output
  --no-confirm             Skip confirmation prompts
  --help                   Show help for specific command

Examples:
  # Run single technique
  edr-cli run --technique T1055.001

  # Run multiple techniques
  edr-cli run --techniques T1055.001,T1055.012 --output report.json

  # Run all techniques in a scenario
  edr-cli run --scenario process_injection

  # Use specific profile
  edr-cli run --profile aggressive --scenario process_injection

  # List available techniques
  edr-cli list techniques

  # List available profiles
  edr-cli list profiles

  # Show current configuration
  edr-cli config show

  # Set configuration value
  edr-cli config set execution.timeout_seconds 120

  # Generate HTML report
  edr-cli report --format html --output report.html

  # Validate detection with EDR logs
  edr-cli validate --edr-logs C:\logs\edr.json

  # Switch profile
  edr-cli profile use aggressive
)" << std::endl;
}

// 기법 리스트 출력
void ListTechniques() {
    std::cout << "\n=== Available Techniques ===" << std::endl;
    std::cout << std::endl;
    
    std::map<std::string, std::vector<std::string>> categories = {
        {"Process Injection", {"T1055.001 - DLL Injection", 
                               "T1055.012 - Process Hollowing",
                               "T1055.004 - APC Injection"}},
        {"Fileless", {"Memory Execution", "WMI Execution"}},
        {"Shellcode", {"Shellcode Injection"}}
    };
    
    for (const auto& [category, techniques] : categories) {
        SetColor(14); // Yellow
        std::cout << category << ":" << std::endl;
        SetColor(7);
        
        for (const auto& tech : techniques) {
            std::cout << "  • " << tech << std::endl;
        }
        std::cout << std::endl;
    }
}

// 프로파일 리스트 출력
void ListProfiles() {
    std::cout << "\n=== Available Profiles ===" << std::endl;
    std::cout << std::endl;
    
    std::vector<std::pair<std::string, std::string>> profiles = {
        {"default", "Standard testing profile with balanced settings"},
        {"aggressive", "High-intensity testing with all techniques enabled"},
        {"safe", "Minimal impact testing for production-like environments"}
    };
    
    for (const auto& [name, description] : profiles) {
        SetColor(11); // Cyan
        std::cout << name << std::endl;
        SetColor(7);
        std::cout << "  " << description << std::endl;
        std::cout << std::endl;
    }
}

// 설정 시나리오 리스트
void ListScenarios() {
    ConfigManager& config = ConfigManager::Instance();
    
    std::cout << "\n=== Available Scenarios ===" << std::endl;
    std::cout << std::endl;
    
    std::vector<std::string> scenarios = {"process_injection", "fileless", "shellcode"};
    
    for (const auto& scenario : scenarios) {
        bool enabled = config.IsScenarioEnabled(scenario);
        auto techniques = config.GetEnabledTechniques(scenario);
        
        SetColor(enabled ? 10 : 12); // Green or Red
        std::cout << scenario << " [" << (enabled ? "ENABLED" : "DISABLED") << "]" << std::endl;
        SetColor(7);
        
        std::cout << "  Techniques: " << techniques.size() << std::endl;
        for (const auto& tech : techniques) {
            std::cout << "    • " << tech << std::endl;
        }
        std::cout << std::endl;
    }
}

// 설정 표시
void ShowConfig() {
    ConfigManager& config = ConfigManager::Instance();
    
    std::cout << "\n=== Current Configuration ===" << std::endl;
    std::cout << std::endl;
    
    std::cout << "Profile: " << config.GetProfile() << std::endl;
    std::cout << std::endl;
    
    std::cout << "Execution:" << std::endl;
    std::cout << "  Timeout: " << config.GetExecutionTimeout() << " seconds" << std::endl;
    std::cout << "  Retry Count: " << config.GetRetryCount() << std::endl;
    std::cout << "  Delay: " << config.GetDelayBetweenTests() << " ms" << std::endl;
    std::cout << std::endl;
    
    std::cout << "Logging:" << std::endl;
    std::cout << "  Level: " << config.GetLoggingLevel() << std::endl;
    std::cout << "  Output: " << config.GetLogOutputFile() << std::endl;
    std::cout << "  Format: " << config.GetLogFormat() << std::endl;
    std::cout << std::endl;
    
    std::cout << "Safety:" << std::endl;
    std::cout << "  Require Confirmation: " << (config.GetRequireConfirmation() ? "Yes" : "No") << std::endl;
    std::cout << "  Sandbox Check: " << (config.GetSandboxCheck() ? "Yes" : "No") << std::endl;
    std::cout << "  Enable Cleanup: " << (config.GetEnableCleanup() ? "Yes" : "No") << std::endl;
    std::cout << std::endl;
    
    std::cout << "Performance:" << std::endl;
    std::cout << "  Monitoring: " << (config.GetEnablePerformanceMonitoring() ? "Enabled" : "Disabled") << std::endl;
    std::cout << "  Export Format: " << config.GetPerformanceExportFormat() << std::endl;
    std::cout << std::endl;
    
    std::cout << "Detection:" << std::endl;
    std::cout << "  Validation: " << (config.GetEnableDetectionValidation() ? "Enabled" : "Disabled") << std::endl;
    std::cout << "  Sysmon: " << (config.GetSysmonEnabled() ? "Enabled" : "Disabled") << std::endl;
    std::cout << std::endl;
    
    std::cout << "Reporting:" << std::endl;
    std::cout << "  Auto Generate: " << (config.GetAutoGenerateReports() ? "Yes" : "No") << std::endl;
    auto formats = config.GetReportFormats();
    std::cout << "  Formats: ";
    for (size_t i = 0; i < formats.size(); ++i) {
        std::cout << formats[i];
        if (i < formats.size() - 1) std::cout << ", ";
    }
    std::cout << std::endl;
    std::cout << std::endl;
}

// 설정 값 설정
void SetConfigValue(const std::string& path, const std::string& value) {
    ConfigManager& config = ConfigManager::Instance();
    
    try {
        // 값 타입 추론 및 변환
        json jsonValue;
        
        if (value == "true" || value == "false") {
            jsonValue = (value == "true");
        } else if (value.find_first_not_of("0123456789") == std::string::npos) {
            jsonValue = std::stoi(value);
        } else {
            jsonValue = value;
        }
        
        config.SetValue(path, jsonValue);
        config.SaveToFile();
        
        SetColor(10); // Green
        std::cout << "\n[SUCCESS] Configuration updated: " << path << " = " << value << std::endl;
        SetColor(7);
        
    } catch (const std::exception& e) {
        SetColor(12); // Red
        std::cerr << "\n[ERROR] Failed to set configuration: " << e.what() << std::endl;
        SetColor(7);
    }
}

// 기법 실행
void RunTechniques(const std::vector<std::string>& techniques, const std::string& outputFile) {
    SetColor(14); // Yellow
    std::cout << "\n[*] Initializing EDR Testing Framework..." << std::endl;
    SetColor(7);
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 확인 프롬프트
    if (config.GetRequireConfirmation()) {
        std::cout << "\nYou are about to execute " << techniques.size() << " technique(s)." << std::endl;
        std::cout << "This may trigger EDR alerts and system monitoring." << std::endl;
        std::cout << "\nContinue? (y/n): ";
        
        char response;
        std::cin >> response;
        
        if (response != 'y' && response != 'Y') {
            std::cout << "\nOperation cancelled by user." << std::endl;
            return;
        }
    }
    
    // 탐지 검증 시작
    DetectionValidator validator;
    
    std::cout << "\n[*] Starting detection validation..." << std::endl;
    validator.StartMonitoring();
    
    // 기법 실행
    for (const auto& tech : techniques) {
        SetColor(11); // Cyan
        std::cout << "\n[*] Testing technique: " << tech << std::endl;
        SetColor(7);
        
        // 실제 기법 실행은 여기서 구현
        // TODO: 실제 기법 실행 코드 통합
        
        Sleep(2000); // 시뮬레이션
    }
    
    std::cout << "\n[*] Stopping monitoring..." << std::endl;
    validator.StopMonitoring();
    
    // 보고서 생성
    std::cout << "\n[*] Generating reports..." << std::endl;
    DetectionReport report = validator.GenerateReport();
    
    if (!outputFile.empty()) {
        // Write JSON report to file
        std::string jsonStr = report.ExportToJSON();
        std::ofstream jf(outputFile, std::ios::binary);
        if (jf.is_open()) { jf << jsonStr; jf.close(); }
        SetColor(10);
        std::cout << "\n[SUCCESS] Report saved to: " << outputFile << std::endl;
        SetColor(7);
    }
    
    // 자동 보고서 생성
    if (config.GetAutoGenerateReports()) {
        ReportGenerator generator(report, config.GetReportOutputDirectory());
        generator.GenerateAllReports();
        
        SetColor(10);
        std::cout << "\n[SUCCESS] All reports generated in: " 
                  << config.GetReportOutputDirectory() << std::endl;
        SetColor(7);
    }
    
    // 요약 출력
    std::cout << "\n=== Execution Summary ===" << std::endl;
    std::cout << "Total Techniques: " << report.totalTechniques << std::endl;
    std::cout << "Detected: " << report.detectedTechniques << std::endl;
    std::cout << "Detection Rate: " << (report.overallDetectionRate * 100) << "%" << std::endl;
}

// 메인 함수
int main(int argc, char* argv[]) {
    // 로거 초기화
    EDR::Logger::Instance().SetLevel(EDR::Logger::Level::INFO);
    
    // 설정 초기화
    ConfigManager& config = ConfigManager::Instance();
    config.LoadFromFile("config.json");
    
    // 환경 변수 오버라이드 적용
    config.ApplyEnvironmentVariableOverrides();
    
    // 인자가 없으면 도움말 표시
    if (argc < 2) {
        PrintBanner();
        PrintHelp();
        return 0;
    }
    
    std::string command = argv[1];
    
    // 명령 파싱
    std::map<std::string, std::string> options;
    for (int i = 2; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.substr(0, 2) == "--") {
            std::string key = arg.substr(2);
            std::string value;
            
            if (i + 1 < argc && argv[i + 1][0] != '-') {
                value = argv[++i];
            } else {
                value = "true";
            }
            
            options[key] = value;
        }
    }
    
    PrintBanner();
    
    try {
        // 명령 실행
        if (command == "run") {
            std::vector<std::string> techniques;
            
            if (options.count("technique")) {
                techniques.push_back(options["technique"]);
            } else if (options.count("techniques")) {
                std::stringstream ss(options["techniques"]);
                std::string tech;
                while (std::getline(ss, tech, ',')) {
                    techniques.push_back(tech);
                }
            } else if (options.count("scenario")) {
                techniques = config.GetEnabledTechniques(options["scenario"]);
            } else {
                techniques = config.GetAllEnabledTechniques();
            }
            
            std::string outputFile = options.count("output") ? options["output"] : "";
            RunTechniques(techniques, outputFile);
            
        } else if (command == "list") {
            std::string what = options.count("_arg") ? options["_arg"] : "techniques";
            
            if (argc >= 3) {
                what = argv[2];
            }
            
            if (what == "techniques") {
                ListTechniques();
            } else if (what == "profiles") {
                ListProfiles();
            } else if (what == "scenarios") {
                ListScenarios();
            } else {
                std::cerr << "Unknown list target: " << what << std::endl;
                std::cerr << "Available: techniques, profiles, scenarios" << std::endl;
            }
            
        } else if (command == "config") {
            if (argc < 3) {
                ShowConfig();
            } else {
                std::string subcommand = argv[2];
                
                if (subcommand == "show") {
                    ShowConfig();
                } else if (subcommand == "set" && argc >= 5) {
                    SetConfigValue(argv[3], argv[4]);
                } else {
                    std::cerr << "Usage: edr-cli config [show|set <path> <value>]" << std::endl;
                }
            }
            
        } else if (command == "profile") {
            if (argc < 3) {
                ListProfiles();
            } else {
                std::string subcommand = argv[2];
                
                if (subcommand == "use" && argc >= 4) {
                    std::string profileName = argv[3];
                    std::string configFile = "config_" + profileName + ".json";
                    
                    if (config.LoadFromFile(configFile)) {
                        config.SetProfile(profileName);
                        config.SaveToFile("config.json");
                        
                        SetColor(10);
                        std::cout << "\n[SUCCESS] Switched to profile: " << profileName << std::endl;
                        SetColor(7);
                    } else {
                        SetColor(12);
                        std::cerr << "\n[ERROR] Profile not found: " << profileName << std::endl;
                        SetColor(7);
                    }
                } else if (subcommand == "list") {
                    ListProfiles();
                } else {
                    std::cerr << "Usage: edr-cli profile [use <name>|list]" << std::endl;
                }
            }
            
        } else if (command == "help" || command == "--help" || command == "-h") {
            PrintHelp();
            
        } else {
            SetColor(12);
            std::cerr << "\n[ERROR] Unknown command: " << command << std::endl;
            SetColor(7);
            std::cout << "\nRun 'edr-cli help' for usage information." << std::endl;
            return 1;
        }
        
    } catch (const std::exception& e) {
        SetColor(12);
        std::cerr << "\n[ERROR] " << e.what() << std::endl;
        SetColor(7);
        return 1;
    }
    
    return 0;
}
