// Minimal implementation of Real-time Monitoring System
#include "../include/realtime_monitor.hpp"
#include "../include/logger.hpp"
#include <fstream>
#include <psapi.h>
#include <algorithm>

using namespace EDR;

RealtimeMonitor* RealtimeMonitor::instance_ = nullptr;

// --------- JSON helpers ---------
json MonitorEvent::ToJSON() const {
	json j;
	j["type"] = static_cast<int>(type);
	j["testId"] = testId;
	j["message"] = message;
	j["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(timestamp.time_since_epoch()).count();
	if (!data.is_null()) j["data"] = data;
	return j;
}

json RealtimeMetrics::ToJSON() const {
	return json{
		{"cpuUsagePercent", cpuUsagePercent},
		{"memoryUsageMB", memoryUsageMB},
		{"peakMemoryMB", peakMemoryMB},
		{"diskReadMB", diskReadMB},
		{"diskWriteMB", diskWriteMB},
		{"networkSentMB", networkSentMB},
		{"networkReceivedMB", networkReceivedMB},
		{"totalTests", totalTests},
		{"completedTests", completedTests},
		{"failedTests", failedTests},
		{"skippedTests", skippedTests},
		{"totalDuration", totalDuration.count()},
		{"averageTestDuration", averageTestDuration.count()}
	};
}

json RealtimeTestStatus::ToJSON() const {
	return json{
		{"testId", testId},
		{"testName", testName},
		{"status", static_cast<int>(status)},
		{"progressPercent", progressPercent},
		{"elapsedTime", elapsedTime.count()},
		{"currentPhase", currentPhase},
		{"recentLogs", recentLogs}
	};
}

// --------- Monitor lifecycle ---------
void RealtimeMonitor::Start() {
	if (isRunning_) return;
	isRunning_ = true; isPaused_ = false; shouldStop_ = false;

	// Start update loop
	updateThread_.reset(new std::thread([this]() { this->UpdateLoop(); }));
	// Start event loop
	eventThread_.reset(new std::thread([this]() { this->EventLoop(); }));

	Logger::Instance().Log(EDRLOG_INFO, "RealtimeMonitor started");
}

void RealtimeMonitor::Stop() {
	if (!isRunning_) return;
	shouldStop_ = true;
	isRunning_ = false;
	if (updateThread_ && updateThread_->joinable()) updateThread_->join();
	if (eventThread_ && eventThread_->joinable()) eventThread_->join();
	updateThread_.reset(); eventThread_.reset();
	Logger::Instance().Log(EDRLOG_INFO, "RealtimeMonitor stopped");
}

void RealtimeMonitor::UpdateLoop() {
	auto start = std::chrono::steady_clock::now();
	while (!shouldStop_) {
		if (!isPaused_) {
			CollectMetrics();
			PrintToConsole();
			auto now = std::chrono::steady_clock::now();
			metrics_.totalDuration = std::chrono::duration_cast<std::chrono::milliseconds>(now - start);
		}
		std::this_thread::sleep_for(updateInterval_);
	}
}

void RealtimeMonitor::EventLoop() {
	while (!shouldStop_) {
		MonitorEvent evt;
		bool has = false;
		{
			std::lock_guard<std::mutex> lock(eventMutex_);
			if (!eventQueue_.empty()) { evt = eventQueue_.front(); eventQueue_.pop(); has = true; }
		}
		if (has) {
			// dispatch
			std::vector<std::function<void(const MonitorEvent&)>> handlers;
			{
				std::lock_guard<std::mutex> lock(handlerMutex_);
				handlers = eventHandlers_;
			}
			for (auto& h : handlers) {
				try { h(evt); } catch (...) {}
			}
		} else {
			std::this_thread::sleep_for(std::chrono::milliseconds(20));
		}
	}
}

void RealtimeMonitor::CollectMetrics() {
	// Lightweight metrics: query process working set
	PROCESS_MEMORY_COUNTERS pmc{};
	if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
		metrics_.memoryUsageMB = static_cast<size_t>(pmc.WorkingSetSize / (1024 * 1024));
		metrics_.peakMemoryMB = static_cast<size_t>(pmc.PeakWorkingSetSize / (1024 * 1024));
	}
	// CPU usage not trivial without PDH; leave as 0 for demo
}

void RealtimeMonitor::PrintToConsole() {
	if (!enableConsoleOutput_) return;
	// Keep it minimal to avoid flicker; do nothing per-tick. Demo renders its own UI.
}

json RealtimeMonitor::TakeSnapshot() const {
	json j;
	j["metrics"] = metrics_.ToJSON();
	j["tests"] = json::array();
	{
		std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(statusMutex_));
		for (const auto& kv : testStatuses_) j["tests"].push_back(kv.second.ToJSON());
	}
	return j;
}

void RealtimeMonitor::ExportLogs(const std::string& filepath) const {
	std::ofstream f(filepath, std::ios::binary);
	auto snap = TakeSnapshot();
	f << snap.dump(2);
}

// --------- MonitorUtils ---------
#include <iomanip>

std::string MonitorUtils::CreateProgressBar(double percent, int width) {
	if (percent < 0) percent = 0; if (percent > 100) percent = 100;
	int filled = static_cast<int>((percent / 100.0) * width);
	std::string bar = "[";
	bar.append(filled, '#');
	bar.append((std::max)(0, width - filled), '-');
	bar.push_back(']');
	std::ostringstream oss; oss << bar << " " << std::fixed << std::setprecision(1) << percent << "%";
	return oss.str();
}

std::string MonitorUtils::FormatDuration(std::chrono::milliseconds duration) {
	using namespace std::chrono;
	auto secs = duration_cast<seconds>(duration).count();
	int h = static_cast<int>(secs / 3600);
	int m = static_cast<int>((secs % 3600) / 60);
	int s = static_cast<int>(secs % 60);
	std::ostringstream oss;
	if (h > 0) oss << h << "h ";
	if (m > 0 || h > 0) oss << m << "m ";
	oss << s << "s";
	return oss.str();
}

std::string MonitorUtils::FormatBytes(size_t bytes) {
	const char* suffix[] = {"B","KB","MB","GB","TB"};
	double count = static_cast<double>(bytes); int i = 0;
	while (count >= 1024 && i < 4) { count /= 1024; ++i; }
	std::ostringstream oss; oss.setf(std::ios::fixed); oss<<std::setprecision( (i==0)?0:2 )<<count<<" "<<suffix[i];
	return oss.str();
}

void MonitorUtils::PrintColored(const std::string& text, int colorCode) {
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO info{};
	GetConsoleScreenBufferInfo(h, &info);
	SetConsoleTextAttribute(h, static_cast<WORD>(colorCode));
	DWORD written=0; WriteConsoleA(h, text.c_str(), (DWORD)text.size(), &written, nullptr);
	SetConsoleTextAttribute(h, info.wAttributes);
}

void MonitorUtils::ClearConsole() {
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if (!GetConsoleScreenBufferInfo(h, &csbi)) return;
	DWORD cellCount = csbi.dwSize.X * csbi.dwSize.Y;
	DWORD count; COORD home = {0,0};
	FillConsoleOutputCharacter(h, ' ', cellCount, home, &count);
	FillConsoleOutputAttribute(h, csbi.wAttributes, cellCount, home, &count);
	SetConsoleCursorPosition(h, home);
}

void MonitorUtils::SetCursorPosition(int x, int y) {
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos{ static_cast<SHORT>(x), static_cast<SHORT>(y) };
	SetConsoleCursorPosition(h, pos);
}

// --------- WebSocket server placeholders ---------
void MonitorWebSocketServer::ServerLoop() { while (isRunning_) { std::this_thread::sleep_for(std::chrono::milliseconds(100)); } }
void MonitorWebSocketServer::Start() { if (isRunning_) return; isRunning_ = true; serverThread_.reset(new std::thread([this]{ ServerLoop(); })); }
void MonitorWebSocketServer::Stop() { if (!isRunning_) return; isRunning_ = false; if (serverThread_ && serverThread_->joinable()) serverThread_->join(); serverThread_.reset(); }
void MonitorWebSocketServer::BroadcastEvent(const MonitorEvent&) {}
void MonitorWebSocketServer::BroadcastStatus(const RealtimeMetrics&, const std::vector<RealtimeTestStatus>&) {}

