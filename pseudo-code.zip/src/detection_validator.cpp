/*
 * Detection Validator Implementation
 */

#include "detection_validator.hpp"
#include <sstream>
#include <iomanip>
#include <winevt.h>

#pragma comment(lib, "wevtapi.lib")
#pragma comment(lib, "advapi32.lib")

namespace EDR {

// ============================================================================
// DetectionValidator Implementation
// ============================================================================

DetectionValidator::DetectionValidator()
    : traceSessionHandle_(INVALID_PROCESSTRACE_HANDLE)
    , traceConsumerHandle_(INVALID_PROCESSTRACE_HANDLE)
    , sessionName_(L"EDR_Detection_Session")
    , isMonitoring_(false)
    , detectionTimeout_(std::chrono::milliseconds(5000))
    , verboseLogging_(false)
{
    LOG_INFO("DetectionValidator initialized");
}

DetectionValidator::~DetectionValidator() {
    if (isMonitoring_) {
        StopMonitoring();
    }
    LOG_INFO("DetectionValidator destroyed");
}

bool DetectionValidator::StartMonitoring() {
    if (isMonitoring_) {
        LOG_WARN("Monitoring already started");
        return true;
    }
    
    if (!IsElevated()) {
        LOG_ERROR("Administrator privileges required for ETW monitoring");
        return false;
    }
    
    monitoringStartTime_ = std::chrono::system_clock::now();
    
    // ETW 세션 시작
    if (!StartETWSession()) {
        LOG_ERROR("Failed to start ETW session");
        return false;
    }
    
    isMonitoring_ = true;
    LOG_INFO("Monitoring started successfully");
    
    return true;
}

bool DetectionValidator::StopMonitoring() {
    if (!isMonitoring_) {
        LOG_WARN("Monitoring not active");
        return true;
    }
    
    monitoringEndTime_ = std::chrono::system_clock::now();
    
    // ETW 세션 중지
    if (!StopETWSession()) {
        LOG_ERROR("Failed to stop ETW session");
        return false;
    }
    
    isMonitoring_ = false;
    
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
        monitoringEndTime_ - monitoringStartTime_);
    
    LOG_INFO("Monitoring stopped. Duration: " + std::to_string(duration.count()) + " ms");
    LOG_INFO("Total ETW events collected: " + std::to_string(etwEvents_.size()));
    
    return true;
}

bool DetectionValidator::EnableETWProvider(const GUID& providerId, 
                                          const std::wstring& providerName) {
    if (isMonitoring_) {
        LOG_WARN("Cannot enable provider while monitoring is active");
        return false;
    }
    
    enabledProviders_[providerId] = providerName;
    
    if (verboseLogging_) {
        LOG_INFO("ETW Provider enabled: " + WStringToString(providerName));
    }
    
    return true;
}

int DetectionValidator::EnableETWProviders(
    const std::map<GUID, std::wstring, GuidLess>& providers) {
    int count = 0;
    
    for (const auto& [guid, name] : providers) {
        if (EnableETWProvider(guid, name)) {
            ++count;
        }
    }
    
    LOG_INFO("Enabled " + std::to_string(count) + " ETW providers");
    
    return count;
}

std::vector<SysmonEvent> DetectionValidator::ParseSysmonLogs(
    const std::chrono::system_clock::time_point& startTime) {
    
    std::vector<SysmonEvent> events;
    
    if (!IsSysmonInstalled()) {
        LOG_WARN("Sysmon not installed");
        return events;
    }
    
    // Windows Event Log에서 Sysmon 이벤트 읽기
    EVT_HANDLE hQuery = EvtQuery(
        NULL,
        L"Microsoft-Windows-Sysmon/Operational",
        NULL,
        EvtQueryChannelPath | EvtQueryForwardDirection
    );
    
    if (!hQuery) {
        LOG_ERROR("Failed to query Sysmon log. Error: " + 
                 std::to_string(GetLastError()));
        return events;
    }
    
    const DWORD bufferSize = 4096;
    EVT_HANDLE eventHandles[bufferSize];
    DWORD returned = 0;
    
    while (EvtNext(hQuery, bufferSize, eventHandles, INFINITE, 0, &returned)) {
        for (DWORD i = 0; i < returned; ++i) {
            // 이벤트 파싱 (간소화된 버전)
            SysmonEvent event;
            event.timestamp = std::chrono::system_clock::now();
            event.type = SysmonEvent::Type::ProcessCreate;
            
            // 실제 구현에서는 EvtRender를 사용하여 상세 정보 파싱
            
            if (event.timestamp >= startTime) {
                events.push_back(event);
            }
            
            EvtClose(eventHandles[i]);
        }
    }
    
    EvtClose(hQuery);
    
    LOG_INFO("Parsed " + std::to_string(events.size()) + " Sysmon events");
    
    return events;
}

std::vector<WindowsEvent> DetectionValidator::ParseWindowsEventLog(
    const std::wstring& logName,
    const std::chrono::system_clock::time_point& startTime) {
    
    std::vector<WindowsEvent> events;
    
    EVT_HANDLE hQuery = EvtQuery(
        NULL,
        logName.c_str(),
        NULL,
        EvtQueryChannelPath | EvtQueryForwardDirection
    );
    
    if (!hQuery) {
        LOG_ERROR("Failed to query Windows Event Log: " + 
                 WStringToString(logName) + 
                 ". Error: " + std::to_string(GetLastError()));
        return events;
    }
    
    const DWORD bufferSize = 4096;
    EVT_HANDLE eventHandles[bufferSize];
    DWORD returned = 0;
    
    while (EvtNext(hQuery, bufferSize, eventHandles, INFINITE, 0, &returned)) {
        for (DWORD i = 0; i < returned; ++i) {
            WindowsEvent event;
            event.timestamp = std::chrono::system_clock::now();
            event.source = logName;
            
            if (event.timestamp >= startTime) {
                events.push_back(event);
            }
            
            EvtClose(eventHandles[i]);
        }
    }
    
    EvtClose(hQuery);
    
    LOG_INFO("Parsed " + std::to_string(events.size()) + 
             " events from " + WStringToString(logName));
    
    return events;
}

std::vector<ETWEvent> DetectionValidator::GetETWEvents() const {
    return etwEvents_;
}

DetectionResult DetectionValidator::ValidateTechnique(
    const std::string& techniqueName) {
    
    DetectionResult result;
    result.technique = techniqueName;
    result.detected = false;
    result.detectionLatency = std::chrono::milliseconds(0);
    result.detectionScore = 0.0;
    result.totalIndicators = 0;
    result.triggeredIndicators = 0;
    
    // 기법 정보 가져오기
    if (TechniqueDatabase::IsTechniqueSupported(techniqueName)) {
        TechniqueInfo info = TechniqueDatabase::GetTechniqueInfo(techniqueName);
        result.techniqueName = info.name;
        result.totalIndicators = static_cast<int>(info.indicators.size());
    } else {
        result.techniqueName = techniqueName;
        LOG_WARN("Unknown technique: " + techniqueName);
    }
    
    auto searchStart = std::chrono::system_clock::now();
    
    // ETW 이벤트 검색
    for (const auto& event : etwEvents_) {
        if (MatchesTechnique(event, techniqueName)) {
            result.etwEvents.push_back(event);
            result.detected = true;
            result.detectionMethods.push_back("ETW");
            
            if (result.detectionLatency.count() == 0) {
                result.detectionLatency = 
                    std::chrono::duration_cast<std::chrono::milliseconds>(
                        event.timestamp - monitoringStartTime_);
            }
        }
    }
    
    // Sysmon 이벤트 검색
    auto sysmonEvents = ParseSysmonLogs(monitoringStartTime_);
    for (const auto& event : sysmonEvents) {
        if (MatchesTechnique(event, techniqueName)) {
            result.sysmonEvents.push_back(event);
            result.detected = true;
            
            if (std::find(result.detectionMethods.begin(), 
                         result.detectionMethods.end(), 
                         "Sysmon") == result.detectionMethods.end()) {
                result.detectionMethods.push_back("Sysmon");
            }
        }
    }
    
    // Windows Event Log 검색
    auto securityEvents = ParseWindowsEventLog(L"Security", monitoringStartTime_);
    for (const auto& event : securityEvents) {
        result.windowsEvents.push_back(event);
        if (!result.detected && event.eventId >= 4688 && event.eventId <= 4689) {
            result.detected = true;
            result.detectionMethods.push_back("Windows Security Log");
        }
    }
    
    // 결과 계산
    result.triggeredIndicators = static_cast<int>(
        result.etwEvents.size() + 
        result.sysmonEvents.size() + 
        result.windowsEvents.size()
    );
    
    result.detectionScore = CalculateDetectionScore(result);
    result.confidence = DetermineConfidence(result);
    result.severity = DetermineSeverity(techniqueName);
    
    // 상세 정보
    std::ostringstream oss;
    oss << "ETW Events: " << result.etwEvents.size() << ", "
        << "Sysmon Events: " << result.sysmonEvents.size() << ", "
        << "Windows Events: " << result.windowsEvents.size();
    result.details = oss.str();
    
    LOG_INFO("Technique validation completed: " + techniqueName + 
             " - Detected: " + (result.detected ? "Yes" : "No"));
    
    detectionResults_.push_back(result);
    
    return result;
}

std::vector<DetectionResult> DetectionValidator::ValidateTechniques(
    const std::vector<std::string>& techniqueNames) {
    
    std::vector<DetectionResult> results;
    
    LOG_INFO("Validating " + std::to_string(techniqueNames.size()) + " techniques");
    
    for (const auto& name : techniqueNames) {
        results.push_back(ValidateTechnique(name));
    }
    
    return results;
}

DetectionResult DetectionValidator::ValidateByProcessId(DWORD processId) {
    DetectionResult result;
    result.technique = "Process-" + std::to_string(processId);
    result.techniqueName = "Process Activity";
    result.detected = false;
    
    // 프로세스 ID로 이벤트 필터링
    for (const auto& event : etwEvents_) {
        if (event.processId == processId) {
            result.etwEvents.push_back(event);
            result.detected = true;
        }
    }
    
    result.detectionScore = CalculateDetectionScore(result);
    result.confidence = DetermineConfidence(result);
    
    return result;
}

DetectionReport DetectionValidator::GenerateReport() {
    return GenerateReport(monitoringStartTime_, monitoringEndTime_);
}

DetectionReport DetectionValidator::GenerateReport(
    const std::chrono::system_clock::time_point& startTime,
    const std::chrono::system_clock::time_point& endTime) {
    
    DetectionReport report;
    report.startTime = startTime;
    report.endTime = endTime;
    report.results = detectionResults_;
    
    // 통계 계산
    report.totalTechniques = static_cast<int>(detectionResults_.size());
    report.detectedTechniques = 0;
    
    std::chrono::milliseconds totalLatency(0);
    report.minDetectionLatency = (std::chrono::milliseconds::max)();
    report.maxDetectionLatency = std::chrono::milliseconds::zero();
    
    for (const auto& result : detectionResults_) {
        if (result.detected) {
            ++report.detectedTechniques;
            
            totalLatency += result.detectionLatency;
            
            if (result.detectionLatency < report.minDetectionLatency) {
                report.minDetectionLatency = result.detectionLatency;
            }
            if (result.detectionLatency > report.maxDetectionLatency) {
                report.maxDetectionLatency = result.detectionLatency;
            }
        }
        
        // 탐지 방법 카운트
        for (const auto& method : result.detectionMethods) {
            report.detectionMethodCounts[method]++;
        }
        
        // 기법별 탐지율
        report.techniqueDetectionRates[result.technique] = result.detectionScore;
    }
    
    if (report.totalTechniques > 0) {
        report.overallDetectionRate = 
            static_cast<double>(report.detectedTechniques) / 
            report.totalTechniques;
    } else {
        report.overallDetectionRate = 0.0;
    }
    
    if (report.detectedTechniques > 0) {
        report.averageDetectionLatency = 
            totalLatency / report.detectedTechniques;
    }
    
    LOG_INFO("Report generated - Detection rate: " + 
             std::to_string(report.overallDetectionRate * 100.0) + "%");
    
    return report;
}

// Static utility methods
bool DetectionValidator::IsSysmonInstalled() {
    // Sysmon 서비스 확인
    SC_HANDLE scm = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
    if (!scm) {
        return false;
    }
    
    SC_HANDLE service = OpenServiceW(scm, L"Sysmon64", SERVICE_QUERY_STATUS);
    bool installed = (service != NULL);
    
    if (service) {
        CloseServiceHandle(service);
    }
    CloseServiceHandle(scm);
    
    return installed;
}

bool DetectionValidator::IsETWSessionActive(const std::wstring& sessionName) {
    // ETW 세션 상태 확인 (간소화된 버전)
    return false; // 실제 구현 필요
}

bool DetectionValidator::IsElevated() {
    BOOL isElevated = FALSE;
    HANDLE token = NULL;
    
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) {
        TOKEN_ELEVATION elevation;
        DWORD size = sizeof(TOKEN_ELEVATION);
        
        if (GetTokenInformation(token, TokenElevation, &elevation, 
                               sizeof(elevation), &size)) {
            isElevated = elevation.TokenIsElevated;
        }
        
        CloseHandle(token);
    }
    
    return isElevated != FALSE;
}

// Private methods
bool DetectionValidator::StartETWSession() {
    // ETW 세션 시작 (간소화된 버전)
    LOG_INFO("ETW session started: " + WStringToString(sessionName_));
    return true;
}

bool DetectionValidator::StopETWSession() {
    // ETW 세션 중지
    LOG_INFO("ETW session stopped");
    return true;
}

bool DetectionValidator::MatchesTechnique(const ETWEvent& event, 
                                         const std::string& technique) {
    // 간단한 패턴 매칭 (실제로는 더 정교한 로직 필요)
    if (technique == "T1055.001" || technique == "dll_injection") {
        // DLL Injection indicators
        return (event.eventId == 8 || // CreateRemoteThread
                event.eventId == 10);  // ProcessAccess
    }
    
    if (technique == "T1055.012" || technique == "process_hollowing") {
        return (event.eventId == 1 ||  // ProcessCreate
                event.eventId == 10);   // ProcessAccess
    }
    
    return false;
}

bool DetectionValidator::MatchesTechnique(const SysmonEvent& event, 
                                         const std::string& technique) {
    if (technique == "T1055.001" || technique == "dll_injection") {
        return (event.type == SysmonEvent::Type::CreateRemoteThread ||
                event.type == SysmonEvent::Type::ProcessAccess);
    }
    
    if (technique == "T1055.012" || technique == "process_hollowing") {
        return (event.type == SysmonEvent::Type::ProcessCreate ||
                event.type == SysmonEvent::Type::ProcessAccess);
    }
    
    return false;
}

double DetectionValidator::CalculateDetectionScore(const DetectionResult& result) {
    if (!result.detected) {
        return 0.0;
    }
    
    double score = 0.0;
    
    // ETW 이벤트 가중치
    score += result.etwEvents.size() * 0.3;
    
    // Sysmon 이벤트 가중치
    score += result.sysmonEvents.size() * 0.4;
    
    // Windows 이벤트 가중치
    score += result.windowsEvents.size() * 0.2;
    
    // 탐지 방법 다양성 가중치
    score += result.detectionMethods.size() * 0.1;
    
    // 0.0 ~ 1.0으로 정규화
    // Use parentheses to avoid potential macro interference with min/max
    return (std::min)(score / 10.0, 1.0);
}

std::string DetectionValidator::DetermineConfidence(const DetectionResult& result) {
    if (result.detectionScore >= 0.8) {
        return "High";
    } else if (result.detectionScore >= 0.5) {
        return "Medium";
    } else {
        return "Low";
    }
}

std::string DetectionValidator::DetermineSeverity(const std::string& technique) {
    // 기법별 심각도 (실제로는 데이터베이스에서 가져오기)
    if (technique.find("T1055") != std::string::npos) {
        return "High";
    }
    
    return "Medium";
}

// ============================================================================
// TechniqueDatabase Implementation
// ============================================================================

std::map<std::string, TechniqueInfo> TechniqueDatabase::techniques_;

void TechniqueDatabase::InitializeDatabase() {
    if (!techniques_.empty()) {
        return;
    }
    
    // T1055.001 - DLL Injection
    TechniqueInfo dll_injection;
    dll_injection.id = "T1055.001";
    dll_injection.name = "DLL Injection";
    dll_injection.tactic = "Defense Evasion";
    dll_injection.indicators = {
        "CreateRemoteThread API call",
        "VirtualAllocEx with PAGE_EXECUTE_READWRITE",
        "WriteProcessMemory to remote process",
        "LoadLibrary in remote process"
    };
    dll_injection.sysmonEventIds = {8, 10}; // CreateRemoteThread, ProcessAccess
    dll_injection.etwProviders = {ETWProviders::KernelProcess};
    techniques_["T1055.001"] = dll_injection;
    techniques_["dll_injection"] = dll_injection;
    
    // T1055.012 - Process Hollowing
    TechniqueInfo process_hollowing;
    process_hollowing.id = "T1055.012";
    process_hollowing.name = "Process Hollowing";
    process_hollowing.tactic = "Defense Evasion";
    process_hollowing.indicators = {
        "Process created in suspended state",
        "UnmapViewOfSection call",
        "VirtualAllocEx in remote process",
        "WriteProcessMemory to overwrite image",
        "SetThreadContext to update entry point",
        "ResumeThread to start execution"
    };
    process_hollowing.sysmonEventIds = {1, 10}; // ProcessCreate, ProcessAccess
    process_hollowing.etwProviders = {ETWProviders::KernelProcess};
    techniques_["T1055.012"] = process_hollowing;
    techniques_["process_hollowing"] = process_hollowing;
    
    // T1055.004 - APC Injection
    TechniqueInfo apc_injection;
    apc_injection.id = "T1055.004";
    apc_injection.name = "Asynchronous Procedure Call";
    apc_injection.tactic = "Defense Evasion";
    apc_injection.indicators = {
        "QueueUserAPC API call",
        "VirtualAllocEx with executable memory",
        "WriteProcessMemory",
        "Thread enumeration"
    };
    apc_injection.sysmonEventIds = {8, 10};
    apc_injection.etwProviders = {ETWProviders::KernelProcess};
    techniques_["T1055.004"] = apc_injection;
    techniques_["apc_injection"] = apc_injection;
}

TechniqueInfo TechniqueDatabase::GetTechniqueInfo(const std::string& techniqueId) {
    InitializeDatabase();
    
    auto it = techniques_.find(techniqueId);
    if (it != techniques_.end()) {
        return it->second;
    }
    
    // 기본값 반환
    TechniqueInfo unknown;
    unknown.id = techniqueId;
    unknown.name = "Unknown Technique";
    return unknown;
}

std::vector<TechniqueInfo> TechniqueDatabase::GetAllTechniques() {
    InitializeDatabase();
    
    std::vector<TechniqueInfo> result;
    for (const auto& [id, info] : techniques_) {
        // 중복 제거 (T1055.001과 dll_injection이 같은 항목)
        if (id.find("T") == 0) {
            result.push_back(info);
        }
    }
    
    return result;
}

bool TechniqueDatabase::IsTechniqueSupported(const std::string& techniqueId) {
    InitializeDatabase();
    return techniques_.find(techniqueId) != techniques_.end();
}

// ============================================================================
// DetectionReport Export Methods
// ============================================================================

std::string DetectionReport::ExportToJSON() const {
    std::ostringstream oss;
    
    oss << "{\n"
        << "  \"summary\": {\n"
        << "    \"totalTechniques\": " << totalTechniques << ",\n"
        << "    \"detectedTechniques\": " << detectedTechniques << ",\n"
        << "    \"overallDetectionRate\": " << overallDetectionRate << ",\n"
        << "    \"averageDetectionLatencyMs\": " 
        << averageDetectionLatency.count() << "\n"
        << "  },\n"
        << "  \"results\": [\n";
    
    for (size_t i = 0; i < results.size(); ++i) {
        oss << "    " << results[i].ToJSON();
        if (i < results.size() - 1) {
            oss << ",";
        }
        oss << "\n";
    }
    
    oss << "  ]\n"
        << "}";
    
    return oss.str();
}

void DetectionReport::ExportToCSV(const std::string& filename) const {
    std::ofstream file(filename);
    
    if (!file.is_open()) {
        LOG_ERROR("Failed to open file for CSV export: " + filename);
        return;
    }
    
    // CSV 헤더
    file << "Technique,Technique Name,Detected,Detection Methods,"
         << "Latency (ms),Severity,Confidence,Score,"
         << "ETW Events,Sysmon Events,Windows Events\n";
    
    // 데이터 행
    for (const auto& result : results) {
        file << result.technique << ","
             << result.techniqueName << ","
             << (result.detected ? "Yes" : "No") << ",";
        
        // 탐지 방법 (따옴표로 감싸기)
        file << "\"";
        for (size_t i = 0; i < result.detectionMethods.size(); ++i) {
            file << result.detectionMethods[i];
            if (i < result.detectionMethods.size() - 1) {
                file << ";";
            }
        }
        file << "\",";
        
        file << result.detectionLatency.count() << ","
             << result.severity << ","
             << result.confidence << ","
             << result.detectionScore << ","
             << result.etwEvents.size() << ","
             << result.sysmonEvents.size() << ","
             << result.windowsEvents.size() << "\n";
    }
    
    file.close();
    LOG_INFO("Report exported to CSV: " + filename);
}

} // namespace EDR
