/**
 * @file report_generator.cpp
 * @brief Advanced reporting system with HTML dashboard and ATT&CK Navigator export
 */

#include <windows.h>
#include "../include/json.hpp"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <algorithm>
#include <vector>
#include <string>
#include "../include/detection_validator.hpp"
#include "../include/logger.hpp"
#include "../include/report_generator.hpp"

using json = nlohmann::json;
using namespace EDR;

namespace EDR {

ReportGenerator::ReportGenerator(const DetectionReport& report, const std::string& outputDir)
    : report_(report), outputDir_(outputDir) {
    CreateDirectoryA(outputDir_.c_str(), NULL);
}

    bool ReportGenerator::GenerateHTMLDashboard(const std::string& filename) {
        try {
            Logger::Instance().Info("Generating HTML dashboard...");

            std::string filepath = outputDir_ + "\\" + filename;
            std::ofstream file(filepath);
            if (!file.is_open()) {
                Logger::Instance().Error("Failed to create HTML dashboard file: " + filepath);
                return false;
            }

            file << GenerateHTMLHeader();
            file << GenerateSummarySection();
            file << GenerateChartsSection();
            file << GenerateTechniquesSection();
            file << GenerateTimelineSection();
            file << GenerateDetailsSection();
            file << GenerateJavaScriptData();
            file << GenerateHTMLFooter();

            file.close();
            Logger::Instance().Info("HTML dashboard generated: " + filepath);
            return true;
        } catch (const std::exception& e) {
            Logger::Instance().Error(std::string("Failed to generate HTML dashboard: ") + e.what());
            return false;
        }
    }

    bool ReportGenerator::GenerateAttackNavigatorJSON(const std::string& filename) {
        try {
            Logger::Instance().Info("Generating ATT&CK Navigator JSON...");

            json navigator;
            navigator["name"] = "EDR Detection Coverage";
            navigator["versions"]["attack"] = "14";
            navigator["versions"]["navigator"] = "4.9.5";
            navigator["versions"]["layer"] = "4.5";
            navigator["domain"] = "enterprise-attack";
            navigator["description"] = "Detection validation results from EDR testing";

            json techniques = json::array();
            for (const auto& result : report_.results) {
                json technique;
                technique["techniqueID"] = result.technique;
                technique["enabled"] = true;
                technique["score"] = static_cast<int>(result.detectionScore * 100);

                if (result.detected) {
                    if (result.detectionScore >= 0.8) {
                        technique["color"] = "#00ff00";  // Green
                        technique["comment"] = "High confidence detection";
                    } else if (result.detectionScore >= 0.5) {
                        technique["color"] = "#ffff00";  // Yellow
                        technique["comment"] = "Medium confidence detection";
                    } else {
                        technique["color"] = "#ffa500";  // Orange
                        technique["comment"] = "Low confidence detection";
                    }
                } else {
                    technique["color"] = "#ff0000";  // Red
                    technique["comment"] = "Not detected";
                }

                if (!result.detectionMethods.empty()) {
                    std::string methods = "Methods: ";
                    for (size_t i = 0; i < result.detectionMethods.size(); ++i) {
                        methods += result.detectionMethods[i];
                        if (i + 1 < result.detectionMethods.size()) methods += ", ";
                    }
                    technique["comment"] = technique["comment"].get<std::string>() + " | " + methods;
                }

                techniques.push_back(technique);
            }
            navigator["techniques"] = techniques;

            std::string filepath = outputDir_ + "\\" + filename;
            std::ofstream file(filepath);
            if (!file.is_open()) {
                Logger::Instance().Error("Failed to create Navigator JSON file: " + filepath);
                return false;
            }
            file << navigator.dump(2);
            file.close();

            Logger::Instance().Info("ATT&CK Navigator JSON generated: " + filepath);
            Logger::Instance().Info("Import this file at: https://mitre-attack.github.io/attack-navigator/");
            return true;
        } catch (const std::exception& e) {
            Logger::Instance().Error(std::string("Failed to generate Navigator JSON: ") + e.what());
            return false;
        }
    }

    bool ReportGenerator::GenerateAllReports() {
        bool success = true;
        if (!GenerateHTMLDashboard()) { Logger::Instance().Warn("HTML dashboard generation failed"); success = false; }
        if (!GenerateAttackNavigatorJSON()) { Logger::Instance().Warn("Navigator JSON generation failed"); success = false; }

        // JSON
        {
            std::string jsonStr = report_.ExportToJSON();
            std::ofstream jf(outputDir_ + "\\detection_report.json", std::ios::binary);
            if (jf.is_open()) { jf << jsonStr; jf.close(); } else { Logger::Instance().Warn("JSON report generation failed"); success = false; }
        }
        // CSV
        report_.ExportToCSV(outputDir_ + "\\detection_report.csv");

        if (!GenerateSummaryReport()) { Logger::Instance().Warn("Summary report generation failed"); success = false; }
        return success;
    }

    std::string ReportGenerator::GenerateHTMLHeader() {
        std::stringstream ss;
        ss << R"(<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EDR Detection Report</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        h1 { color: #667eea; border-bottom: 3px solid #667eea; padding-bottom: 10px; }
        .summary-card { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 10px; margin: 20px 0; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }
        .stat-box { background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #667eea; }
        .stat-value { font-size: 2em; font-weight: bold; color: #667eea; }
        .stat-label { color: #666; font-size: 0.9em; margin-top: 5px; }
        .technique { background: white; border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 8px; }
        .detected { border-left: 5px solid #10b981; }
        .not-detected { border-left: 5px solid #ef4444; }
        .badge { display: inline-block; padding: 5px 10px; border-radius: 15px; font-size: 0.85em; margin: 3px; }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #dbeafe; color: #1e40af; }
    </style>
</head>
<body>
<div class="container">
)";
        return ss.str();
    }

    std::string ReportGenerator::GenerateSummarySection() {
        std::stringstream ss;
        ss << "<div class=\"summary-card\">\n";
        ss << "<h1>EDR Detection Validation Report</h1>\n";
        ss << "<p>Generated: " << GetCurrentTimestamp() << "</p>\n";
        ss << "</div>\n";

        ss << "<div class=\"stats\">\n";

        ss << "<div class=\"stat-box\">\n";
        ss << "<div class=\"stat-value\">" << report_.totalTechniques << "</div>\n";
        ss << "<div class=\"stat-label\">Total Techniques</div>\n";
        ss << "</div>\n";

        ss << "<div class=\"stat-box\">\n";
        ss << "<div class=\"stat-value\">" << report_.detectedTechniques << "</div>\n";
        ss << "<div class=\"stat-label\">Detected</div>\n";
        ss << "</div>\n";

        ss << "<div class=\"stat-box\">\n";
        ss << "<div class=\"stat-value\">" << std::fixed << std::setprecision(2) << (report_.overallDetectionRate * 100) << "%</div>\n";
        ss << "<div class=\"stat-label\">Detection Rate</div>\n";
        ss << "</div>\n";

        ss << "<div class=\"stat-box\">\n";
        ss << "<div class=\"stat-value\">" << report_.averageDetectionLatency.count() << " ms</div>\n";
        ss << "<div class=\"stat-label\">Avg. Latency</div>\n";
        ss << "</div>\n";

        ss << "</div>\n";
        return ss.str();
    }

    std::string ReportGenerator::GenerateChartsSection() {
        std::stringstream ss;
        ss << "<div id=\"chartContainer\" style=\"margin: 30px 0;\">\n";
        ss << "<canvas id=\"detectionChart\" width=\"800\" height=\"400\"></canvas>\n";
        ss << "</div>\n";
        return ss.str();
    }

    std::string ReportGenerator::GenerateTechniquesSection() {
        std::stringstream ss;
        ss << "<h2>Technique Details</h2>\n";
        for (const auto& result : report_.results) {
            ss << "<div class=\"technique " << (result.detected ? "detected" : "not-detected") << "\">\n";
            ss << "<h3>" << result.technique << " - " << result.techniqueName << "</h3>\n";
            ss << "<span class=\"badge " << (result.detected ? "badge-success" : "badge-danger") << "\">";
            ss << (result.detected ? "DETECTED" : "NOT DETECTED") << "</span>\n";
            if (result.detected) {
                ss << "<p><strong>Detection Score:</strong> " << std::fixed << std::setprecision(2) << (result.detectionScore * 100) << "%</p>\n";
                ss << "<p><strong>Latency:</strong> " << result.detectionLatency.count() << " ms</p>\n";
                ss << "<p><strong>Detection Methods:</strong> ";
                for (size_t i = 0; i < result.detectionMethods.size(); ++i) {
                    ss << "<span class=\"badge badge-info\">" << result.detectionMethods[i] << "</span>";
                }
                ss << "</p>\n";
                ss << "<p><strong>Events:</strong> ETW(" << result.etwEvents.size() << ") Sysmon(" << result.sysmonEvents.size() << ") Windows(" << result.windowsEvents.size() << ")</p>\n";
            }
            ss << "</div>\n";
        }
        return ss.str();
    }

    std::string ReportGenerator::GenerateTimelineSection() {
        std::stringstream ss;
        ss << "<h2>Detection Timeline</h2>\n";
        ss << "<div style=\"border-left: 3px solid #667eea; padding-left: 20px;\">\n";
        std::vector<DetectionResult> detectedResults;
        for (const auto& r : report_.results) if (r.detected) detectedResults.push_back(r);
        std::sort(detectedResults.begin(), detectedResults.end(), [](const DetectionResult& a, const DetectionResult& b){ return a.detectionLatency < b.detectionLatency; });
        for (const auto& r : detectedResults) {
            ss << "<div style=\"margin: 15px 0;\">\n";
            ss << "<strong>+" << r.detectionLatency.count() << " ms</strong><br>\n";
            ss << r.technique << " (" << r.techniqueName << ") detected<br>\n";
            ss << "<small>Methods: ";
            for (size_t i = 0; i < r.detectionMethods.size(); ++i) { ss << r.detectionMethods[i]; if (i + 1 < r.detectionMethods.size()) ss << ", "; }
            ss << "</small>\n";
            ss << "</div>\n";
        }
        ss << "</div>\n";
        return ss.str();
    }

    std::string ReportGenerator::GenerateDetailsSection() {
        std::stringstream ss;
        ss << "<h2>Event Distribution</h2>\n";
        ss << "<table style=\"width: 100%; border-collapse: collapse; margin: 20px 0;\">\n";
        ss << "<tr style=\"background: #f8f9fa; border-bottom: 2px solid #667eea;\">\n";
        ss << "<th style=\"padding: 10px; text-align: left;\">Event Source</th>\n";
        ss << "<th style=\"padding: 10px; text-align: center;\">Count</th>\n";
        ss << "<th style=\"padding: 10px; text-align: center;\">Percentage</th>\n";
        ss << "</tr>\n";

        int totalEtw = 0, totalSysmon = 0, totalWin = 0;
        for (const auto& r : report_.results) {
            totalEtw += static_cast<int>(r.etwEvents.size());
            totalSysmon += static_cast<int>(r.sysmonEvents.size());
            totalWin += static_cast<int>(r.windowsEvents.size());
        }
        int totalEvents = totalEtw + totalSysmon + totalWin;
        auto pct = [&](int n) { return totalEvents > 0 ? (n * 100.0 / totalEvents) : 0.0; };

        ss << "<tr><td style=\"padding: 10px;\">ETW</td><td style=\"padding: 10px; text-align: center;\">" << totalEtw << "</td><td style=\"padding: 10px; text-align: center;\">" << std::fixed << std::setprecision(1) << pct(totalEtw) << "%</td></tr>\n";
        ss << "<tr><td style=\"padding: 10px;\">Sysmon</td><td style=\"padding: 10px; text-align: center;\">" << totalSysmon << "</td><td style=\"padding: 10px; text-align: center;\">" << pct(totalSysmon) << "%</td></tr>\n";
        ss << "<tr><td style=\"padding: 10px;\">Windows Event Log</td><td style=\"padding: 10px; text-align: center;\">" << totalWin << "</td><td style=\"padding: 10px; text-align: center;\">" << pct(totalWin) << "%</td></tr>\n";
        ss << "</table>\n";
        return ss.str();
    }

    std::string ReportGenerator::GenerateJavaScriptData() {
        std::stringstream ss;
        json reportJson;
        reportJson["summary"] = {
            {"totalTechniques", report_.totalTechniques},
            {"detectedTechniques", report_.detectedTechniques},
            {"overallDetectionRate", report_.overallDetectionRate},
            {"averageDetectionLatencyMs", report_.averageDetectionLatency.count()}
        };
        json results = json::array();
        for (const auto& result : report_.results) {
            json r;
            r["technique"] = result.technique;
            r["techniqueName"] = result.techniqueName;
            r["detected"] = result.detected;
            r["detectionMethods"] = result.detectionMethods;
            r["detectionLatencyMs"] = result.detectionLatency.count();
            r["detectionScore"] = result.detectionScore;
            r["etwEventCount"] = result.etwEvents.size();
            r["sysmonEventCount"] = result.sysmonEvents.size();
            r["windowsEventCount"] = result.windowsEvents.size();
            results.push_back(r);
        }
        reportJson["results"] = results;
        ss << "<script>\n";
        ss << "const reportData = " << reportJson.dump(2) << ";\n";
        ss << "console.log('Report data loaded:', reportData);\n";
        ss << "</script>\n";
        return ss.str();
    }

    std::string ReportGenerator::GenerateHTMLFooter() {
        return R"(
<footer style="text-align: center; margin-top: 50px; padding: 20px; color: #666; border-top: 1px solid #ddd;">
    <p>EDR Testing Tools 2025 | Advanced Detection Validation Framework</p>
</footer>
</div>
</body>
</html>
)";
    }

    bool ReportGenerator::GenerateSummaryReport() {
        try {
            std::string filepath = outputDir_ + "\\summary.txt";
            std::ofstream file(filepath);
            if (!file.is_open()) return false;

            file << "===================================================================\n";
            file << "              EDR DETECTION VALIDATION SUMMARY                     \n";
            file << "===================================================================\n\n";

            file << "Generated: " << GetCurrentTimestamp() << "\n\n";

            file << "OVERALL STATISTICS:\n";
            file << "-------------------------------------------------------------------\n";
            file << "Total Techniques Tested:  " << report_.totalTechniques << "\n";
            file << "Successfully Detected:    " << report_.detectedTechniques << "\n";
            file << "Detection Rate:           " << std::fixed << std::setprecision(2) << (report_.overallDetectionRate * 100) << "%\n";
            file << "Average Detection Latency:" << report_.averageDetectionLatency.count() << "ms\n\n";

            int totalEtw = 0, totalSysmon = 0, totalWin = 0;
            for (const auto& r : report_.results) { totalEtw += static_cast<int>(r.etwEvents.size()); totalSysmon += static_cast<int>(r.sysmonEvents.size()); totalWin += static_cast<int>(r.windowsEvents.size()); }
            file << "EVENT SOURCES:\n";
            file << "-------------------------------------------------------------------\n";
            file << "ETW Events:               " << totalEtw << "\n";
            file << "Sysmon Events:            " << totalSysmon << "\n";
            file << "Windows Event Log:        " << totalWin << "\n\n";

            file << "TECHNIQUE DETAILS:\n";
            file << "===================================================================\n\n";
            for (const auto& result : report_.results) {
                file << result.technique << " - " << result.techniqueName << "\n";
                file << "Status: " << (result.detected ? "[DETECTED]" : "[NOT DETECTED]") << "\n";
                if (result.detected) {
                    file << "Detection Score: " << (result.detectionScore * 100) << "%\n";
                    file << "Latency: " << result.detectionLatency.count() << "ms\n";
                    file << "Methods: ";
                    for (size_t i = 0; i < result.detectionMethods.size(); ++i) { file << result.detectionMethods[i]; if (i + 1 < result.detectionMethods.size()) file << ", "; }
                    file << "\n";
                }
                file << "\n";
            }
            file.close();
            Logger::Instance().Info("Summary report generated: " + filepath);
            return true;
        } catch (const std::exception& e) {
            Logger::Instance().Error(std::string("Failed to generate summary report: ") + e.what());
            return false;
        }
    }

    std::string ReportGenerator::GetCurrentTimestamp() {
        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &time);
        std::stringstream ss;
        ss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }
} // namespace EDR
