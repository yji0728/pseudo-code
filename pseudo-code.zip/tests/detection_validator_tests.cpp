#include <gtest/gtest.h>
#include "../include/detection_validator.hpp"

using namespace EDR;

TEST(DetectionValidatorTest, StartStopMonitoringRequiresElevation)
{
    // We don't assert true/false because it depends on environment; just call and ensure no crash
    bool elevated = DetectionValidator::IsElevated();
    DetectionValidator v;
    if (elevated) {
        EXPECT_TRUE(v.StartMonitoring());
        EXPECT_TRUE(v.StopMonitoring());
    } else {
        EXPECT_FALSE(v.StartMonitoring());
        EXPECT_FALSE(v.IsMonitoring());
    }
}

TEST(DetectionValidatorTest, GenerateEmptyReport)
{
    DetectionValidator v;
    DetectionReport r = v.GenerateReport();
    // Report should be structurally valid even if not monitoring
    EXPECT_GE(r.totalTechniques, 0);
    EXPECT_GE(r.detectedTechniques, 0);
    EXPECT_GE(r.overallDetectionRate, 0.0);
}