#include <gtest/gtest.h>
#include "../include/test_customizer.hpp"

using namespace EDR;

TEST(TestCustomizerTest, RegisterAndExecuteSimpleTest)
{
    auto& c = TestCustomizer::Instance();

    CustomTest t;
    t.id = "unit_dummy";
    t.name = "Unit Dummy Test";
    t.description = "A minimal test for unit testing";
    t.techniqueId = "T0000";
    t.executionMode = ExecutionMode::SEQUENTIAL;
    t.parameters.push_back(TestParameter("arg", ParameterType::STRING, "x"));
    t.executeFunction = [](const std::map<std::string, json>& params){
        TestResult r; r.techniqueId = "T0000"; r.techniqueName = "Unit"; r.success = true; r.duration = std::chrono::milliseconds(1); r.output = "ok"; return r; };

    // Register should succeed
    EXPECT_NO_THROW(c.RegisterTest(t));

    // Execute should not throw and should succeed
    std::map<std::string, json> args; args["arg"] = "y";
    TestResult res = c.ExecuteTest(t.id, args);
    EXPECT_TRUE(res.success);
    EXPECT_EQ(res.output, "ok");
}