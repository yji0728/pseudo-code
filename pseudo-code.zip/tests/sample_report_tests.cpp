#include <gtest/gtest.h>
#include "../include/detection_validator.hpp"
#include "../include/report_generator.hpp"
#include "test_utils.hpp"

using namespace EDR;

TEST(DetectionReportTest, ExportJSONAndCSV)
{
    DetectionReport report;
    report.totalTechniques = 2;
    report.detectedTechniques = 1;
    report.overallDetectionRate = 0.5;
    report.averageDetectionLatency = std::chrono::milliseconds(100);

    DetectionResult r1; r1.technique="T0001"; r1.techniqueName="Alpha"; r1.detected=true; r1.detectionLatency=std::chrono::milliseconds(120); r1.detectionScore=0.9; report.results.push_back(r1);
    DetectionResult r2; r2.technique="T0002"; r2.techniqueName="Beta"; r2.detected=false; r2.detectionLatency=std::chrono::milliseconds(0); r2.detectionScore=0.0; report.results.push_back(r2);

    std::string json = report.ExportToJSON();
    ASSERT_FALSE(json.empty());
    ASSERT_NE(std::string::npos, json.find("\"totalTechniques\""));

    // CSV: just ensure it writes without throwing
    EXPECT_NO_THROW(report.ExportToCSV("test_output_report.csv"));
}

TEST(ReportGeneratorTest, GenerateAllReports)
{
    DetectionReport report;
    DetectionResult r; r.technique="T1055.001"; r.techniqueName="DLL Injection"; r.detected=true; r.detectionLatency=std::chrono::milliseconds(1000); r.detectionScore=0.8; report.results.push_back(r);
    report.totalTechniques = 1; report.detectedTechniques = 1; report.overallDetectionRate=1.0; report.averageDetectionLatency=std::chrono::milliseconds(1000);

    ReportGenerator gen(report, "test_reports");
    EXPECT_TRUE(gen.GenerateAllReports());
    EXPECT_TRUE(TestUtils::FileExists("test_reports\\dashboard.html"));
    EXPECT_TRUE(TestUtils::FileExists("test_reports\\attack_navigator.json"));
    EXPECT_TRUE(TestUtils::FileExists("test_reports\\detection_report.json"));
    EXPECT_TRUE(TestUtils::FileExists("test_reports\\detection_report.csv"));
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}