#pragma once
#include <string>
#include <fstream>
#include <sys/stat.h>

namespace TestUtils {
    inline bool FileExists(const std::string& path) {
        struct _stat64 s; return _stat64(path.c_str(), &s) == 0 && (s.st_mode & _S_IFREG);
    }
    inline size_t FileSize(const std::string& path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        return f ? static_cast<size_t>(f.tellg()) : 0u;
    }
}