# Fix remaining ErrorCode issues in v3 files

$files = @(
    "samples\process_injection\process_hollowing_v3.cpp",
    "demos\performance_demo.cpp"
)

$replacements = @{
    'ErrorCode::INVALID_PE_FORMAT' = 'ErrorCode::FILE_INVALID_FORMAT'
    'ErrorCode::PROCESS_CREATION_FAILED' = 'ErrorCode::PROCESS_NOT_FOUND'
    'ErrorCode::CONTEXT_RETRIEVAL_FAILED' = 'ErrorCode::SYSTEM_CALL_FAILED'
    'ErrorCode::CONTEXT_SET_FAILED' = 'ErrorCode::SYSTEM_CALL_FAILED'
    'ErrorCode::THREAD_RESUME_FAILED' = 'ErrorCode::THREAD_CREATION_FAILED'
}

foreach ($file in $files) {
    if (Test-Path $file) {
        Write-Host "[*] Processing $file..."
        $content = Get-Content $file -Raw
        
        foreach ($key in $replacements.Keys) {
            $content = $content -replace [regex]::Escape($key), $replacements[$key]
        }
        
        Set-Content $file -Value $content -NoNewline
        Write-Host "[OK] Fixed $file"
    }
}

Write-Host "[+] All ErrorCode issues fixed!"
