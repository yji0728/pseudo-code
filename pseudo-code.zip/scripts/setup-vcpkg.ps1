param(
    [string]$InstallPath = "$env:LOCALAPPDATA\vcpkg",
    [switch]$Force
)

$ErrorActionPreference = "Stop"
Write-Host "[setup-vcpkg] Installing vcpkg and GoogleTest..." -ForegroundColor Cyan

if (-not (Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath | Out-Null
}

$vcpkgExe = Join-Path $InstallPath 'vcpkg.exe'
if ($Force -and (Test-Path $vcpkgExe)) { Remove-Item $vcpkgExe -Force }

if (-not (Test-Path $vcpkgExe)) {
    Write-Host "Downloading vcpkg bootstrap..." -ForegroundColor Yellow
    $zip = Join-Path $env:TEMP 'vcpkg.zip'
    Invoke-WebRequest -Uri https://github.com/microsoft/vcpkg/archive/refs/heads/master.zip -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath $InstallPath -Force
    Remove-Item $zip -Force
    $srcDir = Get-ChildItem -Path $InstallPath -Directory | Where-Object { $_.Name -like 'vcpkg-*' } | Select-Object -First 1
    if ($null -eq $srcDir) { throw "Failed to download vcpkg sources." }
    Push-Location $srcDir.FullName
    .\bootstrap-vcpkg.bat
    Move-Item .\vcpkg.exe $InstallPath -Force
    Pop-Location
}

# Set environment for this session
$env:VCPKG_ROOT = $InstallPath
Write-Host "VCPKG_ROOT = $env:VCPKG_ROOT" -ForegroundColor Green

Write-Host "Integrating vcpkg with MSBuild..." -ForegroundColor Yellow
& $vcpkgExe integrate install | Out-Null

Write-Host "Installing Google Test (x64-windows)..." -ForegroundColor Yellow
& $vcpkgExe install gtest:x64-windows

Write-Host "[setup-vcpkg] Completed." -ForegroundColor Green