# Fix all remaining errors in v3 files  
# Author: GitHub Copilot
# Date: 2025-06-01

$files = @(
    "samples\process_injection\apc_injection_v3.cpp",
    "samples\process_injection\dll_injection_v3.cpp",
    "samples\process_injection\process_hollowing_v3.cpp",
    "demos\performance_demo.cpp"
)

foreach ($file in $files) {
    $fullPath = Join-Path $PSScriptRoot "..\$file"
    
    if (Test-Path $fullPath) {
        Write-Host "Processing: $file" -ForegroundColor Cyan
        $content = Get-Content $fullPath -Raw -Encoding UTF8
        
        # Fix ErrorCode enum values
        $content = $content -replace 'ErrorCode::ACCESS_DENIED', 'ErrorCode::PROCESS_ACCESS_DENIED'
        $content = $content -replace 'ErrorCode::MODULE_NOT_FOUND', 'ErrorCode::DLL_NOT_FOUND'
        $content = $content -replace 'ErrorCode::ALLOCATION_FAILED', 'ErrorCode::MEMORY_ALLOCATION_FAILED'
        
        # Fix dll_injection_v3 MemoryGuard call (2 params → 3 params with PAGE_READWRITE)
        if ($file -like "*dll_injection_v3.cpp") {
            # Pattern: AllocateMemoryGuard(process, size) → AllocateMemoryGuard(process, size, PAGE_READWRITE)
            $content = $content -replace 'AllocateMemoryGuard\(([^,]+),\s*([^)]+)\)', 'AllocateMemoryGuard($1, $2, PAGE_READWRITE)'
        }
        
        # Save with UTF-8 BOM
        [System.IO.File]::WriteAllText($fullPath, $content, [System.Text.UTF8Encoding]::new($true))
        Write-Host "  [OK] Fixed errors in $file" -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] File not found: $file" -ForegroundColor Yellow
    }
}

Write-Host "`nAll files processed successfully!" -ForegroundColor Green
