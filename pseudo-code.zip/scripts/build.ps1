# Build Script for EDR Testing Tools
# Compiles all C++ samples

param(
    [switch]$Clean,
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "    EDR Testing Tools - Build Script" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

# Check for Visual Studio environment
$vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vsWhere) {
    Write-Host "[*] Detecting Visual Studio installation..." -ForegroundColor Yellow
    $vsPath = & $vsWhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    
    if ($vsPath) {
        Write-Host "[+] Visual Studio found at: $vsPath" -ForegroundColor Green
        
        # Find vcvarsall.bat
        $vcvarsall = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
        if (Test-Path $vcvarsall) {
            Write-Host "[+] Setting up Visual Studio environment..." -ForegroundColor Green
            
            # Setup VS environment in this session
            $tempFile = [System.IO.Path]::GetTempFileName()
            cmd /c "`"$vcvarsall`" x64 && set" > $tempFile
            Get-Content $tempFile | ForEach-Object {
                if ($_ -match "^(.*?)=(.*)$") {
                    Set-Content "env:\$($matches[1])" $matches[2]
                }
            }
            Remove-Item $tempFile
        }
    } else {
        Write-Host "[-] Visual Studio not found. Please install Visual Studio with C++ tools." -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "[*] Checking if cl.exe is in PATH..." -ForegroundColor Yellow
    $clExists = Get-Command cl.exe -ErrorAction SilentlyContinue
    if (-not $clExists) {
        Write-Host "[-] cl.exe not found. Please run this from a Visual Studio Developer Command Prompt" -ForegroundColor Red
        Write-Host "    or install Visual Studio with C++ tools." -ForegroundColor Red
        exit 1
    }
    Write-Host "[+] Compiler found in PATH" -ForegroundColor Green
}

# Clean if requested
if ($Clean) {
    Write-Host "`n[*] Cleaning previous builds..." -ForegroundColor Yellow
    Get-ChildItem -Path "samples" -Recurse -Include "*.exe", "*.obj", "*.pdb", "*.ilk" | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem -Path "demos" -Recurse -Include "*.exe", "*.obj", "*.pdb", "*.ilk" | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem -Path "src" -Recurse -Include "*.exe", "*.obj", "*.pdb", "*.ilk" | Remove-Item -Force -ErrorAction SilentlyContinue
    # Also remove any stray object files in repo root
    Get-ChildItem -Path "." -File -Include "*.obj", "*.pdb", "*.ilk" | Remove-Item -Force -ErrorAction SilentlyContinue
    Write-Host "[+] Clean completed" -ForegroundColor Green
}

# Find all C++ source files
Write-Host "`n[*] Finding C++ source files..." -ForegroundColor Yellow
$sampleFiles = Get-ChildItem -Path "samples" -Recurse -Filter "*.cpp" -ErrorAction SilentlyContinue
$demoFiles = Get-ChildItem -Path "demos" -Recurse -Filter "*.cpp" -ErrorAction SilentlyContinue
$allSrcFiles = Get-ChildItem -Path "src" -Filter "*.cpp" -ErrorAction SilentlyContinue

# Split core sources (to be archived into static lib) and app entry points
$coreSources = @()
$appSources = @()
foreach ($sf in $allSrcFiles) {
    if ($sf.Name -ieq "edr_cli.cpp") { $appSources += $sf }
    else { $coreSources += $sf }
}

$cppFiles = @($sampleFiles) + @($demoFiles) + @($appSources)
Write-Host "[+] Found $($cppFiles.Count) C++ files ($($sampleFiles.Count) samples, $($demoFiles.Count) demos, $($appSources.Count) tools)" -ForegroundColor Green

# Show found directories
Write-Host "`n[*] Detected technique categories:" -ForegroundColor Cyan
$categories = Get-ChildItem -Path "samples" -Directory -ErrorAction SilentlyContinue
foreach ($cat in $categories) {
    $fileCount = (Get-ChildItem -Path $cat.FullName -Filter "*.cpp" -ErrorAction SilentlyContinue).Count
    if ($fileCount -gt 0) {
        Write-Host "    - $($cat.Name): $fileCount file(s)" -ForegroundColor Gray
    }
}

# Show demos
if ($demoFiles.Count -gt 0) {
    Write-Host "    - demos: $($demoFiles.Count) file(s)" -ForegroundColor Gray
}

# Show tools
if ($appSources.Count -gt 0) {
    Write-Host "    - tools: $($appSources.Count) file(s)" -ForegroundColor Gray
}

# Prepare build directories
$buildDir = Join-Path $PWD "build"
$libDir = Join-Path $buildDir "lib"
$coreObjDir = Join-Path $buildDir "obj_core"
if (-not (Test-Path $buildDir)) { New-Item -ItemType Directory -Path $buildDir | Out-Null }
if (-not (Test-Path $libDir)) { New-Item -ItemType Directory -Path $libDir | Out-Null }
if (-not (Test-Path $coreObjDir)) { New-Item -ItemType Directory -Path $coreObjDir | Out-Null }

# Build static library from core sources
Write-Host "`n[*] Building static library (edr_core.lib) from src/*.cpp ..." -ForegroundColor Yellow
$flagsCommon = "/EHsc /W4 /std:c++17 /nologo /I`"$PWD\include`""
if ($Verbose) { $flagsCommon += " /Wall" } else { $flagsCommon += " /D_CRT_SECURE_NO_WARNINGS" }

$coreObjs = @()
foreach ($file in $coreSources) {
    $objPath = Join-Path $coreObjDir (([System.IO.Path]::GetFileNameWithoutExtension($file.Name)) + ".obj")
    $compileCmd = "cl.exe $flagsCommon /c /Fo:`"$objPath`" `"$($file.FullName)`""
    if ($Verbose) { Write-Host "  Compiling (lib): $($file.Name)" -ForegroundColor Cyan }
    $null = Invoke-Expression "$compileCmd 2>&1"
    if (Test-Path $objPath) { $coreObjs += $objPath }
    else { Write-Host "  [FAILED] $($file.Name)" -ForegroundColor Red }
}

$libPath = Join-Path $libDir "edr_core.lib"
if ($coreObjs.Count -gt 0) {
    $objArgs = ($coreObjs | ForEach-Object { '"' + $_ + '"' }) -join ' '
    $libCmd = "lib.exe /nologo /OUT:`"$libPath`" $objArgs"
    $null = Invoke-Expression $libCmd
    if (Test-Path $libPath) { Write-Host "[+] Created: $libPath" -ForegroundColor Green }
    else { Write-Host "[-] Failed to create static library" -ForegroundColor Red }
} else {
    Write-Host "[-] No core objects compiled; skipping static library creation" -ForegroundColor Red
}

# Compile each file
$successCount = 0
$failCount = 0

Write-Host "`n[*] Starting compilation..." -ForegroundColor Yellow
Write-Host "==================================================`n" -ForegroundColor Cyan

foreach ($file in $cppFiles) {
    $fileName = $file.Name
    $outputName = [System.IO.Path]::GetFileNameWithoutExtension($fileName) + ".exe"
    $outputPath = Join-Path $file.DirectoryName $outputName
    
    # Ensure per-file object directory to avoid cross-target .obj collisions in root
    $objDir = Join-Path $file.DirectoryName "obj"
    if (-not (Test-Path $objDir)) { New-Item -ItemType Directory -Path $objDir | Out-Null }
    $objPath = Join-Path $objDir ([System.IO.Path]::GetFileNameWithoutExtension($fileName) + ".obj")
    
    Write-Host "Compiling: $fileName" -ForegroundColor Cyan
    Write-Host "  Location: $($file.DirectoryName)" -ForegroundColor Gray
    Write-Host "  Output: $outputName" -ForegroundColor Gray
    
    # Compilation flags (use workspace include folder)
    $flags = $flagsCommon
    
    # Additional libraries
    # Always link core Windows libs needed across samples and our static lib
    $libPathLocal = Join-Path $libDir "edr_core.lib"
    $additionalLibs = "`"$libPathLocal`" advapi32.lib wevtapi.lib"
    # plus performance monitoring deps for specific files
    if ($file.Name -match "_v3\.cpp$" -or $file.Name -eq "performance_demo.cpp") {
        $additionalLibs += " pdh.lib psapi.lib"
    }
    
    # Build command (explicit object output path to isolate .obj files)
    $compileCmd = "cl.exe $flags /Fo:`"$objPath`" `"$($file.FullName)`" /Fe:`"$outputPath`" /link /SUBSYSTEM:CONSOLE $additionalLibs"
    
    try {
        # Create a temp file for compilation output
        $tempOutput = [System.IO.Path]::GetTempFileName()
        
        # Execute compilation
    Invoke-Expression "$compileCmd 2>&1" | Out-File $tempOutput
        
        # Check if exe was created
        if (Test-Path $outputPath) {
            Write-Host "  [SUCCESS] Compiled successfully" -ForegroundColor Green
            $successCount++
            
            # Get file size
            $fileSize = (Get-Item $outputPath).Length
            Write-Host "  Size: $([math]::Round($fileSize/1KB, 2)) KB" -ForegroundColor Gray
        } else {
            Write-Host "  [FAILED] Compilation failed" -ForegroundColor Red
            $failCount++
            
            if ($Verbose) {
                Write-Host "  Error details:" -ForegroundColor Red
                Get-Content $tempOutput | Write-Host -ForegroundColor DarkRed
            }
        }
        
        Remove-Item $tempOutput -ErrorAction SilentlyContinue
        
    } catch {
        Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
        $failCount++
    }
    
    # Clean up intermediate files
    if (Test-Path $objPath) { Remove-Item $objPath -Force -ErrorAction SilentlyContinue }
    
    Write-Host ""
}

# Summary
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "    Build Summary" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Total files: $($cppFiles.Count)" -ForegroundColor White
Write-Host "Successful: $successCount" -ForegroundColor Green
Write-Host "Failed: $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })
Write-Host "==================================================" -ForegroundColor Cyan

if ($successCount -eq $cppFiles.Count) {
    Write-Host "`n[+] All files compiled successfully!" -ForegroundColor Green
    Write-Host "You can now run the workflow script to execute tests." -ForegroundColor Cyan
    exit 0
} else {
    Write-Host "`n[-] Some files failed to compile. Check errors above." -ForegroundColor Red
    exit 1
}
