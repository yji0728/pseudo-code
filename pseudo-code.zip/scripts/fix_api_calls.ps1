# Fix API calls in v2 and v3 files
# Author: GitHub Copilot
# Date: 2025-06-01

$files = @(
    "samples\process_injection\dll_injection_v2.cpp",
    "samples\process_injection\dll_injection_v3.cpp",
    "samples\process_injection\process_hollowing_v2.cpp",
    "samples\process_injection\process_hollowing_v3.cpp",
    "samples\process_injection\apc_injection_v3.cpp",
    "demos\performance_demo.cpp"
)

foreach ($file in $files) {
    $fullPath = Join-Path $PSScriptRoot "..\$file"
    
    if (Test-Path $fullPath) {
        Write-Host "Processing: $file" -ForegroundColor Cyan
        $content = Get-Content $fullPath -Raw -Encoding UTF8
        
        # Fix 1: GetWhatW() → EDR::StringToWString(e.what())
        $content = $content -replace 'e\.GetWhatW\(\)', 'EDR::StringToWString(e.what())'
        
        # Fix 2: GetCode() → code()
        $content = $content -replace 'e\.GetCode\(\)', 'e.code()'
        
        # Fix 3: Logger::StringToWString → EDR::StringToWString
        $content = $content -replace 'Logger::StringToWString', 'EDR::StringToWString'
        
        # Fix 4: Logger::WStringToString → EDR::WStringToString
        $content = $content -replace 'Logger::WStringToString', 'EDR::WStringToString'
        
        # Fix 5: Logger::Level::INFO → EDRLOG_INFO
        $content = $content -replace 'Logger::Level::INFO', 'EDRLOG_INFO'
        $content = $content -replace 'Logger::Level::DEBUG', 'EDRLOG_DEBUG'
        $content = $content -replace 'Logger::Level::WARN', 'EDRLOG_WARN'
        $content = $content -replace 'Logger::Level::ERROR', 'EDRLOG_ERROR'
        
        # Fix 6: v3 files include path (only for v3 and performance_demo in demos/)
        if ($file -match 'v3\.cpp$' -or $file -match 'demos\\') {
            $content = $content -replace '#include\s+"\.\.\/include\/', '#include "../../include/'
        }
        
        # Save with UTF-8 BOM
        [System.IO.File]::WriteAllText($fullPath, $content, [System.Text.UTF8Encoding]::new($true))
        Write-Host "  [OK] Fixed API calls in $file" -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] File not found: $file" -ForegroundColor Yellow
    }
}

Write-Host "`nAll files processed successfully!" -ForegroundColor Green
