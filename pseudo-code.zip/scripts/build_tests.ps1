param(
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "    EDR Testing Tools - Test Build Script" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

# Ensure VS environment
$vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vsWhere) {
    $vsPath = & $vsWhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($vsPath) {
        $vcvarsall = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
        if (Test-Path $vcvarsall) {
            $tempFile = [System.IO.Path]::GetTempFileName()
            cmd /c "`"$vcvarsall`" x64 && set" > $tempFile
            Get-Content $tempFile | ForEach-Object { if ($_ -match "^(.*?)=(.*)$") { Set-Content "env:$($matches[1])" $matches[2] } }
            Remove-Item $tempFile
        }
    }
}

# Build core library first
powershell -ExecutionPolicy Bypass -File (Join-Path $PWD 'scripts/build.ps1') | Out-Null

$buildDir = Join-Path $PWD 'build_tests'
$objDir = Join-Path $buildDir 'obj'
$binDir = Join-Path $buildDir 'bin'
New-Item -ItemType Directory -Path $buildDir -ErrorAction SilentlyContinue | Out-Null
New-Item -ItemType Directory -Path $objDir -ErrorAction SilentlyContinue | Out-Null
New-Item -ItemType Directory -Path $binDir -ErrorAction SilentlyContinue | Out-Null

# Locate GoogleTest via vcpkg (multiple strategies)
$triplet = 'x64-windows'
$candidateRoots = @()
if ($env:VCPKG_ROOT) { $candidateRoots += $env:VCPKG_ROOT }
if ($vsPath) { $candidateRoots += (Join-Path $vsPath 'VC\vcpkg') }
if (Test-Path (Join-Path $env:LOCALAPPDATA 'vcpkg')) { $candidateRoots += (Join-Path $env:LOCALAPPDATA 'vcpkg') }

$gtestInclude = $null
$gtestLibDir = $null
foreach ($root in $candidateRoots) {
    $inc = Join-Path $root (Join-Path 'installed' (Join-Path $triplet 'include'))
    $lib = Join-Path $root (Join-Path 'installed' (Join-Path $triplet 'lib'))
    if ((Test-Path $inc) -and (Test-Path (Join-Path $lib 'gtest.lib'))) {
        $gtestInclude = $inc
        $gtestLibDir = $lib
        break
    }
}

if (-not $gtestInclude) {
    Write-Host "[-] GoogleTest not found. Please install via vcpkg:" -ForegroundColor Yellow
    Write-Host "    1) Install vcpkg: https://github.com/microsoft/vcpkg#quick-start" -ForegroundColor Yellow
    Write-Host "    2) vcpkg integrate install" -ForegroundColor Yellow
    Write-Host "    3) vcpkg install gtest:$triplet" -ForegroundColor Yellow
    Write-Host "    4) Set VCPKG_ROOT env var or open a VS Dev Prompt" -ForegroundColor Yellow
    exit 1
}
$gtestLib = Join-Path $env:LOCALAPPDATA "vcpkg\installed\x64-windows\lib\gtest.lib"
$gtestMainLib = Join-Path $env:LOCALAPPDATA "vcpkg\installed\x64-windows\lib\gtest_main.lib"
$gtestInclude = Join-Path $env:LOCALAPPDATA "vcpkg\installed\x64-windows\include"
if (-not (Test-Path $gtestLib) -or -not (Test-Path $gtestMainLib) -or -not (Test-Path $gtestInclude)) {
    Write-Warning "GoogleTest not found under $env:LOCALAPPDATA\\vcpkg. Running scripts/setup-vcpkg.ps1 to install..."
    $setupScript = Join-Path $PSScriptRoot 'setup-vcpkg.ps1'
    if (-not (Test-Path $setupScript)) {
        Write-Error "Missing setup script at $setupScript"
        exit 1
    }
    & $setupScript
    # Re-evaluate paths after installation
    if (-not (Test-Path $gtestLib) -or -not (Test-Path $gtestMainLib) -or -not (Test-Path $gtestInclude)) {
        Write-Error "GoogleTest still not found after setup. Please check vcpkg installation."
        exit 1
    }
}

$flags = "/EHsc /W4 /std:c++17 /nologo /I`"$PWD\include`" /I`"$gtestInclude`""

$testSources = Get-ChildItem -Path (Join-Path $PWD 'tests') -Filter "*.cpp"
$objs = @()
foreach ($t in $testSources) {
    $obj = Join-Path $objDir (([System.IO.Path]::GetFileNameWithoutExtension($t.Name)) + '.obj')
    $cmd = "cl.exe $flags /c /Fo:`"$obj`" `"$($t.FullName)`""
    if ($Verbose) { Write-Host "Compiling test: $($t.Name)" -ForegroundColor Cyan }
    Invoke-Expression "$cmd 2>&1" | Out-Null
    if (Test-Path $obj) { $objs += $obj } else { Write-Host "  [FAILED] $($t.Name)" -ForegroundColor Red }
}

$libPath = Join-Path $PWD 'build\lib\edr_core.lib'
$exe = Join-Path $binDir 'edr_tests.exe'
$libs = "`"$libPath`" advapi32.lib wevtapi.lib `"$gtestLibDir\gtest.lib`" `"$gtestLibDir\gtest_main.lib`""

$linkCmd = "link.exe /nologo /OUT:`"$exe`" " + (($objs | ForEach-Object { '"' + $_ + '"' }) -join ' ') + " $libs"
if ($Verbose) { Write-Host $linkCmd -ForegroundColor DarkGray }
Invoke-Expression $linkCmd

if (Test-Path $exe) {
    Write-Host "[+] Tests built: $exe" -ForegroundColor Green
    Write-Host "[*] Running tests..." -ForegroundColor Yellow
    & $exe
} else {
    Write-Host "[-] Failed to build tests." -ForegroundColor Red
}