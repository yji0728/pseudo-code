param(
    [string]$Root = ".",
    [switch]$WhatIf
)

Write-Host "[normalize-encoding] Ensuring UTF-8 with BOM for text files..." -ForegroundColor Cyan

$extensions = @('*.cpp','*.hpp','*.h','*.c','*.cc','*.ps1','*.md','*.json')
$files = @()
foreach ($ext in $extensions) {
    $files += Get-ChildItem -Path $Root -Recurse -File -Filter $ext -ErrorAction SilentlyContinue
}

function Get-Encoding($path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { return 'utf8-bom' }
    return 'unknown'
}

$converted = 0
foreach ($f in $files) {
    $enc = Get-Encoding $f.FullName
    if ($enc -ne 'utf8-bom') {
        if ($WhatIf) {
            Write-Host "Would convert: $($f.FullName) -> UTF-8 BOM" -ForegroundColor Yellow
            continue
        }
        $text = Get-Content -Path $f.FullName -Raw -ErrorAction SilentlyContinue
        if ($null -ne $text) {
            $utf8bom = New-Object System.Text.UTF8Encoding($true)
            [System.IO.File]::WriteAllText($f.FullName, $text, $utf8bom)
            $converted++
            Write-Host "Converted: $($f.FullName)" -ForegroundColor Green
        }
    }
}

Write-Host "[normalize-encoding] Converted $converted file(s) to UTF-8 with BOM." -ForegroundColor Green