# Fix all ErrorCode issues in v3 files
# Author: GitHub Copilot
# Date: 2025-06-01

$files = @(
    "samples\process_injection\apc_injection_v3.cpp",
    "samples\process_injection\dll_injection_v3.cpp",
    "samples\process_injection\process_hollowing_v3.cpp",
    "demos\performance_demo.cpp"
)

foreach ($file in $files) {
    $fullPath = Join-Path $PSScriptRoot "..\$file"
    
    if (Test-Path $fullPath) {
        Write-Host "Processing: $file" -ForegroundColor Cyan
        $content = Get-Content $fullPath -Raw -Encoding UTF8
        
        # Fix ALL ErrorCode enum values
        $content = $content -replace 'ErrorCode::FUNCTION_NOT_FOUND', 'ErrorCode::API_NOT_AVAILABLE'
        $content = $content -replace 'ErrorCode::APC_QUEUE_FAILED', 'ErrorCode::INJECTION_FAILED'
        $content = $content -replace 'ErrorCode::QUERY_FAILED', 'ErrorCode::SYSTEM_CALL_FAILED'
        $content = $content -replace 'ErrorCode::WRITE_FAILED', 'ErrorCode::MEMORY_WRITE_FAILED'
        $content = $content -replace 'ErrorCode::MAP_FAILED', 'ErrorCode::MEMORY_ALLOCATION_FAILED'
        $content = $content -replace 'ErrorCode::UNMAPPING_FAILED', 'ErrorCode::SYSTEM_CALL_FAILED'
        $content = $content -replace 'ErrorCode::CONTEXT_FAILED', 'ErrorCode::SYSTEM_CALL_FAILED'
        $content = $content -replace 'ErrorCode::RESUME_FAILED', 'ErrorCode::THREAD_CREATION_FAILED'
        $content = $content -replace 'ErrorCode::LIBRARY_LOAD_FAILED', 'ErrorCode::DLL_NOT_FOUND'
        $content = $content -replace 'ErrorCode::REMOTE_CALL_FAILED', 'ErrorCode::REMOTE_THREAD_FAILED'
        
        # Fix VirtualMemoryGuard with 2 params → AllocateMemoryGuard with 3 params
        # Match patterns like: VirtualMemoryGuard xxx(process, size)
        # Replace with: VirtualMemoryGuard xxx = AllocateMemoryGuard(process, size, PAGE_EXECUTE_READWRITE)
        $content = $content -replace 'VirtualMemoryGuard\s+(\w+)\(([^,]+),\s*([^)]+)\)', 'VirtualMemoryGuard $1 = AllocateMemoryGuard($2, $3, PAGE_EXECUTE_READWRITE)'
        
        # Save with UTF-8 BOM
        [System.IO.File]::WriteAllText($fullPath, $content, [System.Text.UTF8Encoding]::new($true))
        Write-Host "  [OK] Fixed all errors in $file" -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] File not found: $file" -ForegroundColor Yellow
    }
}

Write-Host "`nAll files processed successfully!" -ForegroundColor Green
