# Fix MemoryGuard constructor calls in v2 files
# Author: GitHub Copilot
# Date: 2025-06-01

$files = @(
    "samples\process_injection\apc_injection_v2.cpp",
    "samples\process_injection\dll_injection_v2.cpp",
    "samples\process_injection\process_hollowing_v2.cpp"
)

foreach ($file in $files) {
    $fullPath = Join-Path $PSScriptRoot "..\$file"
    
    if (Test-Path $fullPath) {
        Write-Host "Processing: $file" -ForegroundColor Cyan
        $content = Get-Content $fullPath -Raw -Encoding UTF8
        
        # Fix MemoryGuard constructor calls
        # Pattern: MemoryGuard remoteXXX(process, size, protection) → AllocateMemoryGuard(...)
        $content = $content -replace 'MemoryGuard\s+(\w+)\(([^,]+),\s*([^,]+),\s*([^)]+)\)', 'MemoryGuard $1 = AllocateMemoryGuard($2, $3, $4)'
        
        # Save with UTF-8 BOM
        [System.IO.File]::WriteAllText($fullPath, $content, [System.Text.UTF8Encoding]::new($true))
        Write-Host "  [OK] Fixed MemoryGuard calls in $file" -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] File not found: $file" -ForegroundColor Yellow
    }
}

Write-Host "`nAll files processed successfully!" -ForegroundColor Green
