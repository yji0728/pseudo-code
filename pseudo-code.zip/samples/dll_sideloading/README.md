# DLL Side-Loading (DLL 사이드 로딩)

## MITRE ATT&CK
**Technique ID**: T1574.002  
**Tactic**: Persistence, Privilege Escalation, Defense Evasion  
**Platform**: Windows

---

## 개요 (Overview)

DLL Side-Loading은 정상적인 애플리케이션이 DLL을 로드할 때 Windows의 DLL 검색 순서를 악용하여 악성 DLL을 로드하게 만드는 기법입니다.

DLL Side-Loading exploits the Windows DLL search order mechanism to load malicious DLLs by legitimate applications.

---

## 기법 설명 (Technique Description)

### DLL 검색 순서 (DLL Search Order)

Windows는 다음 순서로 DLL을 검색합니다:

1. **애플리케이션이 로드된 디렉토리**
2. System 디렉토리 (C:\Windows\System32)
3. 16-bit System 디렉토리 (C:\Windows\System)
4. Windows 디렉토리 (C:\Windows)
5. 현재 작업 디렉토리
6. PATH 환경 변수에 나열된 디렉토리

공격자는 정상 실행 파일과 동일한 디렉토리에 악성 DLL을 배치하여 시스템 DLL보다 먼저 로드되게 만듭니다.

---

## 샘플 코드 (Sample Code)

### 1. dll_search_order.cpp
DLL 검색 순서를 시뮬레이션하고 EDR이 비정상적인 DLL 로드를 탐지할 수 있는지 테스트합니다.

**주요 기능**:
- DLL 검색 경로 확인
- 다양한 위치에서 DLL 로드 시도
- LoadLibrary API 호출 모니터링

### 2. phantom_dll_hollowing.cpp
Phantom DLL Hollowing 기법을 시뮬레이션합니다. 정상 DLL을 로드한 후 메모리에서 악성 코드로 교체합니다.

**주요 기능**:
- 정상 DLL 로드
- 메모리 섹션 언매핑
- 새로운 코드 주입
- 실행 권한 변경

---

## 탐지 포인트 (Detection Points)

EDR 솔루션이 탐지해야 하는 주요 지표:

### 1. 파일 시스템 모니터링
- ✅ 비정상적인 위치의 DLL 생성
- ✅ 정상 애플리케이션 디렉토리에 알려지지 않은 DLL 추가
- ✅ DLL 파일의 디지털 서명 확인

### 2. 프로세스 행동 분석
- ✅ `LoadLibrary` / `LoadLibraryEx` 호출 모니터링
- ✅ 비정상적인 경로에서 DLL 로드
- ✅ 시스템 DLL 이름을 가진 비시스템 위치의 DLL

### 3. 메모리 분석
- ✅ 로드된 DLL의 서명 검증
- ✅ 메모리 내 DLL 이미지와 디스크 이미지 불일치
- ✅ 실행 가능한 메모리 영역의 비정상적인 패턴

### 4. API 호출 패턴
- ✅ `SetDllDirectory` API 호출
- ✅ `AddDllDirectory` API 호출
- ✅ 동적 DLL 검색 경로 변경 시도

---

## 사용 방법 (Usage)

### 컴파일 (Compilation)
```powershell
# dll_search_order.cpp 컴파일
cd samples\dll_sideloading
cl /EHsc /W4 dll_search_order.cpp /Fe:dll_search_order.exe

# phantom_dll_hollowing.cpp 컴파일
cl /EHsc /W4 phantom_dll_hollowing.cpp /Fe:phantom_dll_hollowing.exe
```

### 실행 (Execution)
```powershell
# DLL 검색 순서 테스트
.\dll_search_order.exe

# Phantom DLL Hollowing 테스트
.\phantom_dll_hollowing.exe
```

---

## 예상 EDR 동작 (Expected EDR Behavior)

### 탐지 시나리오
1. **비정상 DLL 로드 경고**
   ```
   [ALERT] Suspicious DLL loaded from non-system location
   Process: legitimate_app.exe
   DLL: C:\Users\test\malicious.dll
   Expected Location: C:\Windows\System32\
   ```

2. **DLL 검색 경로 조작 탐지**
   ```
   [ALERT] DLL search order manipulation detected
   Process: test.exe
   API: SetDllDirectory
   New Path: C:\temp\suspicious\
   ```

3. **메모리 불일치 탐지**
   ```
   [ALERT] Memory/Disk image mismatch detected
   Module: legitimate.dll
   Process: victim.exe
   Reason: Code section modified in memory
   ```

---

## 방어 전략 (Defense Strategies)

### 1. 애플리케이케이션 측면
- **SafeDllSearchMode 활성화**: 현재 디렉토리보다 시스템 디렉토리 우선 검색
- **DLL 경로 명시**: `LoadLibraryEx`에 전체 경로 지정
- **DLL 서명 검증**: 로드 전 디지털 서명 확인

### 2. EDR/보안 제품
- **화이트리스트 기반 DLL 검증**
- **행위 기반 탐지**: 비정상적인 LoadLibrary 호출 패턴
- **메모리 무결성 검사**: 주기적인 메모리-디스크 비교

### 3. 시스템 설정
- **DLL Safe Search Mode 레지스트리 설정**
  ```
  HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager
  SafeDllSearchMode = 1
  ```

---

## 실제 사례 (Real-world Examples)

### 주요 APT 그룹의 사용 사례
- **APT10**: DLL side-loading을 통한 지속성 확보
- **Lazarus Group**: 정상 애플리케이션을 이용한 악성코드 실행
- **APT41**: Supply chain 공격과 결합한 DLL side-loading

### 악용된 정상 애플리케이션
- Microsoft-signed binaries
- Adobe 제품
- Hardware vendor utilities
- Security software components

---

## 관련 기법 (Related Techniques)

- **T1574.001**: DLL Search Order Hijacking
- **T1574.007**: Path Interception by PATH Environment Variable
- **T1574.008**: Path Interception by Search Order Hijacking
- **T1574.009**: Path Interception by Unquoted Path

---

## 참고 자료 (References)

1. [MITRE ATT&CK - T1574.002](https://attack.mitre.org/techniques/T1574/002/)
2. [Microsoft - Dynamic-Link Library Search Order](https://docs.microsoft.com/windows/win32/dlls/dynamic-link-library-search-order)
3. [OWASP - DLL Hijacking](https://owasp.org/www-community/vulnerabilities/DLL_Hijacking)

---

## 경고 (Warning)

⚠️ **이 코드는 오직 합법적인 EDR 테스트 목적으로만 사용되어야 합니다.**

⚠️ **승인된 테스트 환경에서만 실행하세요.**

⚠️ **무단 사용은 법적 책임을 초래할 수 있습니다.**

---

**Last Updated**: 2025-10-14
**Version**: 1.0
