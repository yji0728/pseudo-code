/*
 * Phantom DLL Hollowing Test - EDR Detection Test
 * 
 * 목적: DLL 메모리 내용을 교체하는 Phantom DLL Hollowing 기법 시뮬레이션
 * Purpose: Test EDR's ability to detect Phantom DLL Hollowing technique
 * 
 * MITRE ATT&CK: T1574.002 (related)
 * 
 * 탐지 포인트 (Detection Points):
 * - DLL loaded but memory contents differ from disk
 * - VirtualProtect changes on DLL memory sections
 * - WriteProcessMemory to DLL memory space
 * - Memory/Disk image mismatch detection
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <vector>

// Structure to hold module information
struct ModuleInfo {
    HMODULE handle;
    std::wstring name;
    PVOID baseAddress;
    SIZE_T size;
    DWORD protection;
};

// Get information about loaded module
ModuleInfo GetModuleInfo(const wchar_t* moduleName) {
    ModuleInfo info = {};
    
    HMODULE hModule = GetModuleHandleW(moduleName);
    if (hModule) {
        info.handle = hModule;
        info.name = moduleName;
        info.baseAddress = (PVOID)hModule;
        
        // Get module size using VirtualQuery
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery(hModule, &mbi, sizeof(mbi))) {
            info.size = mbi.RegionSize;
            info.protection = mbi.Protect;
        }
        
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(hModule, path, MAX_PATH);
    }
    
    return info;
}

// Test 1: Demonstrate memory-disk mismatch detection
void TestMemoryDiskMismatch() {
    std::wcout << L"\n[Test 1] Memory-Disk Image Mismatch Detection" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Phantom DLL Hollowing Technique:" << std::endl;
    std::wcout << L"    1. Load legitimate DLL" << std::endl;
    std::wcout << L"    2. Unmap DLL from memory (NtUnmapViewOfSection)" << std::endl;
    std::wcout << L"    3. Allocate new memory at same address" << std::endl;
    std::wcout << L"    4. Write malicious code to memory" << std::endl;
    std::wcout << L"    5. Adjust memory protections" << std::endl;
    std::wcout << L"    [!] Result: DLL appears legitimate but executes malicious code" << std::endl;
    
    // Get info about a system DLL
    const wchar_t* targetDll = L"version.dll";  // Small, commonly available DLL
    
    std::wcout << L"\n[*] Target DLL: " << targetDll << std::endl;
    
    // Load the DLL
    HMODULE hModule = LoadLibraryW(targetDll);
    if (hModule) {
        wchar_t dllPath[MAX_PATH];
        GetModuleFileNameW(hModule, dllPath, MAX_PATH);
        
        std::wcout << L"    [+] DLL Loaded from: " << dllPath << std::endl;
        std::wcout << L"    [+] Base Address: 0x" << std::hex << (DWORD_PTR)hModule << std::dec << std::endl;
        
        // Get memory info
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery(hModule, &mbi, sizeof(mbi))) {
            std::wcout << L"    [+] Memory Size: " << mbi.RegionSize << L" bytes" << std::endl;
            std::wcout << L"    [+] Protection: 0x" << std::hex << mbi.Protect << std::dec << std::endl;
        }
        
        std::wcout << L"\n[*] EDR Detection Points:" << std::endl;
        std::wcout << L"    - Hash memory image of DLL" << std::endl;
        std::wcout << L"    - Hash disk image of DLL" << std::endl;
        std::wcout << L"    - Compare hashes (should match for legitimate DLL)" << std::endl;
        std::wcout << L"    - Alert if hashes differ (indicates hollowing)" << std::endl;
        
        FreeLibrary(hModule);
    } else {
        std::wcout << L"    [-] Failed to load DLL" << std::endl;
    }
}

// Test 2: Demonstrate VirtualProtect on DLL memory
void TestDllMemoryProtection() {
    std::wcout << L"\n[Test 2] DLL Memory Protection Changes" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    const wchar_t* targetDll = L"version.dll";
    
    HMODULE hModule = LoadLibraryW(targetDll);
    if (hModule) {
        std::wcout << L"[*] Testing memory protection changes on DLL sections..." << std::endl;
        
        // Enumerate memory sections
        MEMORY_BASIC_INFORMATION mbi;
        PVOID address = hModule;
        
        std::wcout << L"\n[*] Memory Sections:" << std::endl;
        
        int sectionCount = 0;
        while (VirtualQuery(address, &mbi, sizeof(mbi)) && sectionCount < 5) {
            if (mbi.AllocationBase == hModule) {
                std::wcout << L"\n    Section " << (sectionCount + 1) << L":" << std::endl;
                std::wcout << L"    Address: 0x" << std::hex << (DWORD_PTR)mbi.BaseAddress << std::dec << std::endl;
                std::wcout << L"    Size: " << mbi.RegionSize << L" bytes" << std::endl;
                std::wcout << L"    Protection: ";
                
                // Decode protection flags
                if (mbi.Protect & PAGE_EXECUTE_READWRITE) std::wcout << L"PAGE_EXECUTE_READWRITE ";
                else if (mbi.Protect & PAGE_EXECUTE_READ) std::wcout << L"PAGE_EXECUTE_READ ";
                else if (mbi.Protect & PAGE_EXECUTE) std::wcout << L"PAGE_EXECUTE ";
                else if (mbi.Protect & PAGE_READWRITE) std::wcout << L"PAGE_READWRITE ";
                else if (mbi.Protect & PAGE_READONLY) std::wcout << L"PAGE_READONLY ";
                std::wcout << std::endl;
                
                std::wcout << L"    State: ";
                if (mbi.State == MEM_COMMIT) std::wcout << L"MEM_COMMIT";
                else if (mbi.State == MEM_RESERVE) std::wcout << L"MEM_RESERVE";
                else if (mbi.State == MEM_FREE) std::wcout << L"MEM_FREE";
                std::wcout << std::endl;
                
                sectionCount++;
            }
            
            address = (PVOID)((DWORD_PTR)mbi.BaseAddress + mbi.RegionSize);
        }
        
        std::wcout << L"\n[!] EDR Should Monitor:" << std::endl;
        std::wcout << L"    - VirtualProtect calls on DLL memory" << std::endl;
        std::wcout << L"    - Especially PAGE_EXECUTE_READWRITE on code sections" << std::endl;
        std::wcout << L"    - WriteProcessMemory to DLL address space" << std::endl;
        std::wcout << L"    - Unexpected modifications to .text sections" << std::endl;
        
        FreeLibrary(hModule);
    }
}

// Test 3: Simulate hollowing detection scenario
void TestHollowingDetectionScenario() {
    std::wcout << L"\n[Test 3] Hollowing Detection Scenario" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Simulating attacker's perspective..." << std::endl;
    std::wcout << L"\n[Attacker Step 1] Load legitimate DLL" << std::endl;
    std::wcout << L"    API: LoadLibrary(\"legitimate.dll\")" << std::endl;
    std::wcout << L"    [EDR] Normal behavior, no alert" << std::endl;
    
    std::wcout << L"\n[Attacker Step 2] Unmap DLL sections" << std::endl;
    std::wcout << L"    API: NtUnmapViewOfSection(hProcess, dllBaseAddress)" << std::endl;
    std::wcout << L"    [EDR] ALERT! Unmapping loaded DLL is highly suspicious" << std::endl;
    
    std::wcout << L"\n[Attacker Step 3] Allocate new memory" << std::endl;
    std::wcout << L"    API: VirtualAllocEx(hProcess, dllBaseAddress, size, MEM_COMMIT, PAGE_EXECUTE_READWRITE)" << std::endl;
    std::wcout << L"    [EDR] ALERT! Allocating RWX memory at previous DLL address" << std::endl;
    
    std::wcout << L"\n[Attacker Step 4] Write malicious code" << std::endl;
    std::wcout << L"    API: WriteProcessMemory(hProcess, dllBaseAddress, maliciousCode, size)" << std::endl;
    std::wcout << L"    [EDR] ALERT! Writing to DLL address space" << std::endl;
    
    std::wcout << L"\n[Attacker Step 5] Execute malicious code" << std::endl;
    std::wcout << L"    Method: Call function address in hollowed DLL" << std::endl;
    std::wcout << L"    [EDR] ALERT! Code execution from modified DLL" << std::endl;
    
    std::wcout << L"\n[*] Detection Strategy:" << std::endl;
    std::wcout << L"    1. Track all NtUnmapViewOfSection calls" << std::endl;
    std::wcout << L"    2. Monitor memory allocations at unmapped addresses" << std::endl;
    std::wcout << L"    3. Verify DLL integrity periodically" << std::endl;
    std::wcout << L"    4. Compare memory hash with file hash" << std::endl;
    std::wcout << L"    5. Alert on any mismatch" << std::endl;
}

// Test 4: Check current process for hollowing indicators
void TestProcessIntegrityCheck() {
    std::wcout << L"\n[Test 4] Process DLL Integrity Check" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Checking current process for DLL integrity..." << std::endl;
    std::wcout << L"[*] EDR should perform similar checks on all processes" << std::endl;
    
    // Get list of loaded modules
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        MODULEENTRY32W me32;
        me32.dwSize = sizeof(MODULEENTRY32W);
        
        std::wcout << L"\n[*] Loaded Modules Analysis:" << std::endl;
        
        int count = 0;
        if (Module32FirstW(hSnapshot, &me32)) {
            do {
                if (count < 5) {  // Check first 5 modules
                    std::wcout << L"\n    Module: " << me32.szModule << std::endl;
                    std::wcout << L"    Base Address: 0x" << std::hex << (DWORD_PTR)me32.modBaseAddr << std::dec << std::endl;
                    std::wcout << L"    Size: " << me32.modBaseSize << L" bytes" << std::endl;
                    std::wcout << L"    Path: " << me32.szExePath << std::endl;
                    
                    // Check memory characteristics
                    MEMORY_BASIC_INFORMATION mbi;
                    if (VirtualQuery(me32.modBaseAddr, &mbi, sizeof(mbi))) {
                        std::wcout << L"    Memory State: ";
                        if (mbi.State == MEM_COMMIT) {
                            std::wcout << L"COMMITTED (Normal)" << std::endl;
                        } else {
                            std::wcout << L"SUSPICIOUS! (Not committed)" << std::endl;
                        }
                    }
                    
                    std::wcout << L"    [Check] Hash memory image" << std::endl;
                    std::wcout << L"    [Check] Hash file image" << std::endl;
                    std::wcout << L"    [Check] Compare hashes" << std::endl;
                    std::wcout << L"    [Expected] Hashes should match" << std::endl;
                    
                    count++;
                }
            } while (Module32NextW(hSnapshot, &me32));
        }
        
        CloseHandle(hSnapshot);
    }
    
    std::wcout << L"\n[!] EDR Best Practices:" << std::endl;
    std::wcout << L"    - Periodic integrity checks of all loaded DLLs" << std::endl;
    std::wcout << L"    - Real-time monitoring of NtUnmapViewOfSection" << std::endl;
    std::wcout << L"    - Memory forensics on suspicious processes" << std::endl;
    std::wcout << L"    - Behavioral analysis of DLL loading patterns" << std::endl;
}

// Test 5: Alternative hollowing methods
void TestAlternativeHollowingMethods() {
    std::wcout << L"\n[Test 5] Alternative DLL Hollowing Methods" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Various DLL Hollowing Techniques:" << std::endl;
    
    std::wcout << L"\n1. Classic Phantom DLL Hollowing:" << std::endl;
    std::wcout << L"   - Unmap entire DLL" << std::endl;
    std::wcout << L"   - Allocate new memory" << std::endl;
    std::wcout << L"   - Write malicious code" << std::endl;
    
    std::wcout << L"\n2. Section Hollowing:" << std::endl;
    std::wcout << L"   - Keep DLL header intact" << std::endl;
    std::wcout << L"   - Hollow only .text section" << std::endl;
    std::wcout << L"   - Less likely to be detected" << std::endl;
    
    std::wcout << L"\n3. Module Stomping:" << std::endl;
    std::wcout << L"   - Load legitimate DLL" << std::endl;
    std::wcout << L"   - Overwrite unused sections" << std::endl;
    std::wcout << L"   - Redirect execution flow" << std::endl;
    
    std::wcout << L"\n4. Transacted Hollowing:" << std::endl;
    std::wcout << L"   - Use NTFS transactions" << std::endl;
    std::wcout << L"   - Create hollow file" << std::endl;
    std::wcout << L"   - Load from transaction" << std::endl;
    std::wcout << L"   - Rollback transaction" << std::endl;
    
    std::wcout << L"\n[!] EDR Must Detect All Variants:" << std::endl;
    std::wcout << L"    - API hooking (NtMapViewOfSection, etc.)" << std::endl;
    std::wcout << L"    - Memory scanning" << std::endl;
    std::wcout << L"    - Behavioral analysis" << std::endl;
    std::wcout << L"    - Transaction monitoring (TxF)" << std::endl;
}

int main() {
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: Phantom DLL Hollowing" << std::endl;
    std::wcout << L"    MITRE ATT&CK: T1574.002 (Related)" << std::endl;
    std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    std::wcout << L"\n[*] This test demonstrates how EDR should detect" << std::endl;
    std::wcout << L"    DLL hollowing techniques without performing actual" << std::endl;
    std::wcout << L"    malicious operations." << std::endl;
    
    // Run tests
    TestMemoryDiskMismatch();
    TestDllMemoryProtection();
    TestHollowingDetectionScenario();
    TestProcessIntegrityCheck();
    TestAlternativeHollowingMethods();
    
    // Summary
    std::wcout << L"\n==================================================" << std::endl;
    std::wcout << L"    Test Summary" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"[+] All tests completed successfully" << std::endl;
    std::wcout << L"\n[!] Critical EDR Detection Points:" << std::endl;
    std::wcout << L"    1. NtUnmapViewOfSection API calls" << std::endl;
    std::wcout << L"    2. Memory allocation at unmapped DLL addresses" << std::endl;
    std::wcout << L"    3. WriteProcessMemory to DLL memory regions" << std::endl;
    std::wcout << L"    4. Memory-disk image hash mismatches" << std::endl;
    std::wcout << L"    5. Suspicious memory protection changes" << std::endl;
    std::wcout << L"    6. Code execution from modified DLL sections" << std::endl;
    std::wcout << L"\n[*] Check your EDR console for alerts!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    return 0;
}
