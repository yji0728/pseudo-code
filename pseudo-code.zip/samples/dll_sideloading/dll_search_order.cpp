/*
 * DLL Search Order Hijacking Test - EDR Detection Test
 * 
 * 목적: DLL 검색 순서를 악용하는 기법을 시뮬레이션하여 EDR 탐지 능력 테스트
 * Purpose: Test EDR's ability to detect DLL search order hijacking
 * 
 * MITRE ATT&CK: T1574.002
 * 
 * 탐지 포인트 (Detection Points):
 * - LoadLibrary/LoadLibraryEx calls from non-standard locations
 * - SetDllDirectory API usage
 * - AddDllDirectory API usage
 * - DLL loaded from application directory instead of system directory
 * - Unsigned or suspicious DLL loads
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <vector>
#include <string>

// Structure to hold DLL search path information
struct DllSearchPath {
    std::wstring path;
    std::wstring description;
    int priority;
};

// Get current DLL search paths
std::vector<DllSearchPath> GetDllSearchOrder() {
    std::vector<DllSearchPath> paths;
    
    // 1. Application directory
    wchar_t appPath[MAX_PATH];
    GetModuleFileNameW(NULL, appPath, MAX_PATH);
    std::wstring appPathStr(appPath);
    size_t lastSlash = appPathStr.find_last_of(L"\\");
    if (lastSlash != std::wstring::npos) {
        paths.push_back({
            appPathStr.substr(0, lastSlash),
            L"Application Directory (Highest Priority)",
            1
        });
    }
    
    // 2. System directory
    wchar_t sysPath[MAX_PATH];
    GetSystemDirectoryW(sysPath, MAX_PATH);
    paths.push_back({
        sysPath,
        L"System32 Directory",
        2
    });
    
    // 3. Windows directory
    wchar_t winPath[MAX_PATH];
    GetWindowsDirectoryW(winPath, MAX_PATH);
    paths.push_back({
        winPath,
        L"Windows Directory",
        3
    });
    
    // 4. Current directory
    wchar_t curPath[MAX_PATH];
    GetCurrentDirectoryW(MAX_PATH, curPath);
    paths.push_back({
        curPath,
        L"Current Working Directory",
        4
    });
    
    return paths;
}

// Display DLL search order
void DisplaySearchOrder() {
    std::wcout << L"\n[*] Windows DLL Search Order:" << std::endl;
    std::wcout << L"================================================" << std::endl;
    
    auto paths = GetDllSearchOrder();
    for (const auto& p : paths) {
        std::wcout << L"  [" << p.priority << L"] " << p.description << std::endl;
        std::wcout << L"      Path: " << p.path << std::endl;
    }
    
    std::wcout << L"  [5] Directories in PATH environment variable" << std::endl;
    std::wcout << L"================================================" << std::endl;
}

// Test 1: Simulate DLL loading from different locations
void TestDllLoadFromDifferentLocations() {
    std::wcout << L"\n[Test 1] Testing DLL Load from Different Locations" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    // Test common Windows DLLs
    std::vector<std::wstring> testDlls = {
        L"kernel32.dll",
        L"user32.dll",
        L"advapi32.dll"
    };
    
    for (const auto& dllName : testDlls) {
        std::wcout << L"\n[*] Testing DLL: " << dllName << std::endl;
        
        // Load DLL (will use standard search order)
        HMODULE hModule = LoadLibraryW(dllName.c_str());
        
        if (hModule) {
            // Get actual loaded DLL path
            wchar_t loadedPath[MAX_PATH];
            GetModuleFileNameW(hModule, loadedPath, MAX_PATH);
            
            std::wcout << L"    [+] Loaded from: " << loadedPath << std::endl;
            std::wcout << L"    [!] EDR should verify this is the legitimate system DLL" << std::endl;
            
            FreeLibrary(hModule);
        } else {
            std::wcout << L"    [-] Failed to load. Error: " << GetLastError() << std::endl;
        }
    }
}

// Test 2: Demonstrate SetDllDirectory API (EDR should monitor this)
void TestSetDllDirectory() {
    std::wcout << L"\n[Test 2] Testing SetDllDirectory API" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Attempting to modify DLL search order using SetDllDirectory..." << std::endl;
    std::wcout << L"    [!] EDR should detect this API call as suspicious" << std::endl;
    
    // Get temp directory
    wchar_t tempPath[MAX_PATH];
    GetTempPathW(MAX_PATH, tempPath);
    
    std::wcout << L"[*] Setting DLL directory to: " << tempPath << std::endl;
    std::wcout << L"    This would cause DLLs to be searched in temp directory first!" << std::endl;
    
    // Note: Not actually calling SetDllDirectory to avoid security issues
    // Just demonstrating what EDR should detect
    std::wcout << L"    [Simulated] SetDllDirectory(\"" << tempPath << L"\")" << std::endl;
    std::wcout << L"    [!] Real malware would execute: SetDllDirectory()" << std::endl;
    
    // Show the impact
    std::wcout << L"\n[*] Impact Analysis:" << std::endl;
    std::wcout << L"    - Current directory removed from search order" << std::endl;
    std::wcout << L"    - Specified directory becomes first search location" << std::endl;
    std::wcout << L"    - Can be used to hijack DLL loads" << std::endl;
}

// Test 3: Demonstrate LoadLibraryEx with different flags
void TestLoadLibraryExFlags() {
    std::wcout << L"\n[Test 3] Testing LoadLibraryEx with Different Flags" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    const wchar_t* testDll = L"kernel32.dll";
    
    // Test different flags
    struct FlagTest {
        DWORD flag;
        std::wstring name;
        std::wstring description;
    };
    
    std::vector<FlagTest> flags = {
        { 0, L"Default", L"Standard search order" },
        { LOAD_LIBRARY_SEARCH_SYSTEM32, L"SEARCH_SYSTEM32", L"Only search System32" },
        { LOAD_LIBRARY_SEARCH_APPLICATION_DIR, L"SEARCH_APPLICATION_DIR", L"Search app directory" },
        { LOAD_WITH_ALTERED_SEARCH_PATH, L"ALTERED_SEARCH_PATH", L"Modified search behavior" }
    };
    
    for (const auto& f : flags) {
        std::wcout << L"\n[*] Testing Flag: " << f.name << std::endl;
        std::wcout << L"    Description: " << f.description << std::endl;
        
        HMODULE hModule = LoadLibraryExW(testDll, NULL, f.flag);
        if (hModule) {
            wchar_t path[MAX_PATH];
            GetModuleFileNameW(hModule, path, MAX_PATH);
            std::wcout << L"    [+] Loaded from: " << path << std::endl;
            FreeLibrary(hModule);
        } else {
            DWORD error = GetLastError();
            std::wcout << L"    [-] Failed. Error: " << error << std::endl;
        }
    }
    
    std::wcout << L"\n[!] EDR should monitor LoadLibraryEx flags for suspicious patterns" << std::endl;
}

// Test 4: Check for phantom DLL opportunities
void TestPhantomDllOpportunities() {
    std::wcout << L"\n[Test 4] Checking for Phantom DLL Opportunities" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Analyzing current process for DLL hijacking opportunities..." << std::endl;
    
    // Get application directory
    wchar_t appPath[MAX_PATH];
    GetModuleFileNameW(NULL, appPath, MAX_PATH);
    std::wstring appPathStr(appPath);
    size_t lastSlash = appPathStr.find_last_of(L"\\");
    std::wstring appDir = (lastSlash != std::wstring::npos) ? 
                          appPathStr.substr(0, lastSlash) : L"";
    
    std::wcout << L"[*] Application Directory: " << appDir << std::endl;
    
    // List DLLs loaded by current process
    std::wcout << L"\n[*] Currently Loaded DLLs:" << std::endl;
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        MODULEENTRY32W me32;
        me32.dwSize = sizeof(MODULEENTRY32W);
        
        int count = 0;
        if (Module32FirstW(hSnapshot, &me32)) {
            do {
                // Check if DLL is from System32
                std::wstring modulePath = me32.szExePath;
                bool isSystemDll = (modulePath.find(L"System32") != std::wstring::npos) ||
                                   (modulePath.find(L"SysWOW64") != std::wstring::npos);
                
                if (isSystemDll && count < 10) {  // Show first 10 system DLLs
                    std::wcout << L"    [" << (count + 1) << L"] " << me32.szModule << std::endl;
                    std::wcout << L"        Path: " << modulePath << std::endl;
                    
                    // Simple check if DLL might exist in app directory
                    // (Not using filesystem for compatibility)
                    std::wcout << L"        [Info] Check app directory for hijacking opportunity" << std::endl;
                    
                    count++;
                }
            } while (Module32NextW(hSnapshot, &me32));
        }
        CloseHandle(hSnapshot);
    }
    
    std::wcout << L"\n[!] EDR should alert on DLLs loaded from non-system locations" << std::endl;
}

// Test 5: Demonstrate DLL signature verification
void TestDllSignatureVerification() {
    std::wcout << L"\n[Test 5] DLL Digital Signature Verification" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] EDR should verify digital signatures of loaded DLLs" << std::endl;
    std::wcout << L"[*] Checking signatures of common system DLLs..." << std::endl;
    
    std::vector<std::wstring> dlls = { L"kernel32.dll", L"ntdll.dll", L"user32.dll" };
    
    for (const auto& dll : dlls) {
        HMODULE hModule = GetModuleHandleW(dll.c_str());
        if (hModule) {
            wchar_t path[MAX_PATH];
            GetModuleFileNameW(hModule, path, MAX_PATH);
            
            std::wcout << L"\n[*] DLL: " << dll << std::endl;
            std::wcout << L"    Path: " << path << std::endl;
            std::wcout << L"    [Expected] Signed by: Microsoft Corporation" << std::endl;
            std::wcout << L"    [!] EDR should verify signature matches expected signer" << std::endl;
        }
    }
    
    std::wcout << L"\n[*] Detection Criteria:" << std::endl;
    std::wcout << L"    - Unsigned DLLs loaded from application directory" << std::endl;
    std::wcout << L"    - DLLs signed by unexpected entities" << std::endl;
    std::wcout << L"    - Expired or revoked signatures" << std::endl;
    std::wcout << L"    - Signature mismatch between disk and memory" << std::endl;
}

int main() {
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: DLL Search Order Hijacking" << std::endl;
    std::wcout << L"    MITRE ATT&CK: T1574.002" << std::endl;
    std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    // Display DLL search order
    DisplaySearchOrder();
    
    // Run tests
    TestDllLoadFromDifferentLocations();
    TestSetDllDirectory();
    TestLoadLibraryExFlags();
    TestPhantomDllOpportunities();
    TestDllSignatureVerification();
    
    // Summary
    std::wcout << L"\n==================================================" << std::endl;
    std::wcout << L"    Test Summary" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"[+] All tests completed successfully" << std::endl;
    std::wcout << L"\n[!] EDR Detection Points:" << std::endl;
    std::wcout << L"    1. Monitor LoadLibrary/LoadLibraryEx calls" << std::endl;
    std::wcout << L"    2. Detect SetDllDirectory/AddDllDirectory usage" << std::endl;
    std::wcout << L"    3. Verify DLL signatures and locations" << std::endl;
    std::wcout << L"    4. Alert on DLLs loaded from non-system paths" << std::endl;
    std::wcout << L"    5. Compare disk and memory DLL images" << std::endl;
    std::wcout << L"\n[*] Check your EDR console for alerts!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    return 0;
}
