# Error Handling System

## 개요 (Overview)

EDR Testing Tools의 통합 에러 처리 시스템입니다. RAII 패턴 기반의 자동 리소스 관리와 체계적인 에러 코드 계층을 제공합니다.

This is the unified error handling system for EDR Testing Tools. It provides RAII-based automatic resource management and a systematic error code hierarchy.

## 주요 기능 (Key Features)

### 1. 에러 코드 계층 (Error Code Hierarchy)

체계적인 에러 코드 분류:
- **1xxx**: 프로세스 관련 (Process-related)
- **2xxx**: 메모리 관련 (Memory-related)
- **3xxx**: 인젝션 관련 (Injection-related)
- **4xxx**: 파일/리소스 관련 (File/Resource-related)
- **5xxx**: 권한 관련 (Permission-related)
- **6xxx**: 파라미터 관련 (Parameter-related)
- **7xxx**: 시스템 관련 (System-related)

### 2. RAII 리소스 가드 (RAII Resource Guards)

자동 리소스 관리를 위한 가드 클래스:
- `HandleGuard`: Windows 핸들 자동 해제
- `VirtualMemoryGuard`: 가상 메모리 자동 해제
- `LibraryGuard`: DLL 자동 언로드
- `FileHandleGuard`: 파일 핸들 자동 해제
- `ScopeGuard`: 일반 정리 작업

### 3. 예외 클래스 (Exception Class)

`EDR::Exception` 클래스 제공:
- 에러 코드와 메시지
- 컨텍스트 정보
- 시스템 에러 코드 캡처
- 파일/라인 정보
- 자동 포맷팅된 에러 메시지

## 사용 방법 (Usage)

### 기본 에러 처리 (Basic Error Handling)

```cpp
#include "error_handling.hpp"

try {
    HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!h) {
        THROW_EDR_ERROR(
            ErrorCode::PROCESS_NOT_FOUND,
            "Failed to open process"
        );
    }
    // ... use handle ...
} catch (const EDR::Exception& e) {
    std::cerr << "Error: " << e.what() << "\n";
    LOG_ERROR(e.what());
}
```

### RAII 핸들 관리 (RAII Handle Management)

```cpp
// 자동으로 핸들이 해제됨
HandleGuard hProcess(OpenProcess(...));

if (!hProcess) {
    THROW_EDR_ERROR(ErrorCode::PROCESS_NOT_FOUND, "Process not found");
}

// hProcess 사용
DWORD exitCode = 0;
GetExitCodeProcess(hProcess, &exitCode);

// 스코프 종료 시 자동으로 CloseHandle 호출
```

### 메모리 관리 (Memory Management)

```cpp
HANDLE hProcess = OpenProcess(...);
LPVOID pMem = VirtualAllocEx(hProcess, NULL, 4096, ...);

// 자동으로 메모리가 해제됨
VirtualMemoryGuard memGuard(hProcess, pMem, 4096);

if (!memGuard) {
    THROW_EDR_ERROR(ErrorCode::MEMORY_ALLOCATION_FAILED, "Allocation failed");
}

// 메모리 사용
WriteProcessMemory(hProcess, memGuard.get(), ...);

// 스코프 종료 시 자동으로 VirtualFreeEx 호출
```

### 스코프 가드 (Scope Guard)

```cpp
// 스코프 종료 시 자동 실행
auto cleanup = MakeScopeGuard([&]() {
    std::cout << "Cleanup executed\n";
});

// 조건부 해제
if (success) {
    cleanup.dismiss();  // 정리 작업 취소
}
```

### 컨텍스트와 함께 에러 발생 (Error with Context)

```cpp
try {
    // 작업 수행
} catch (const std::exception& e) {
    THROW_EDR_ERROR_CTX(
        ErrorCode::INJECTION_FAILED,
        "DLL injection failed",
        std::string("Target PID: ") + std::to_string(pid)
    );
}
```

### 핸들 유효성 검사 (Handle Validation)

```cpp
HANDLE h = CreateFileA(...);

// 자동으로 예외 발생
CHECK_HANDLE(h, "Failed to create file");

// 포인터 검사
void* ptr = malloc(1024);
CHECK_POINTER(ptr, "Memory allocation failed");
```

## 실전 예제 (Real-World Examples)

### 예제 1: 프로세스 인젝션 (Process Injection)

```cpp
void InjectDLL(DWORD targetPid, const std::string& dllPath) {
    try {
        LOG_INFO("Starting DLL injection");

        // 1. 프로세스 열기 (자동 핸들 관리)
        HandleGuard hProcess(OpenProcess(
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_CREATE_THREAD,
            FALSE,
            targetPid
        ));

        CHECK_HANDLE(hProcess, "Failed to open target process");
        LOG_INFO("Process opened successfully");

        // 2. 메모리 할당 (자동 메모리 관리)
        SIZE_T size = dllPath.size() + 1;
        LPVOID pRemote = VirtualAllocEx(
            hProcess, NULL, size,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE
        );

        VirtualMemoryGuard memGuard(hProcess, pRemote, size);
        
        if (!memGuard) {
            THROW_EDR_ERROR(
                ErrorCode::MEMORY_ALLOCATION_FAILED,
                "VirtualAllocEx failed"
            );
        }
        LOG_INFO("Memory allocated");

        // 3. DLL 경로 쓰기
        SIZE_T written = 0;
        if (!WriteProcessMemory(hProcess, memGuard.get(), 
                                dllPath.c_str(), size, &written)) {
            THROW_EDR_ERROR_CTX(
                ErrorCode::MEMORY_WRITE_FAILED,
                "WriteProcessMemory failed",
                "DLL: " + dllPath
            );
        }
        LOG_INFO("DLL path written");

        // 4. LoadLibrary 주소 가져오기
        HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
        if (!hKernel32) {
            THROW_EDR_ERROR(ErrorCode::DLL_NOT_FOUND, "kernel32.dll not found");
        }

        LPVOID pLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
        if (!pLoadLibrary) {
            THROW_EDR_ERROR(ErrorCode::API_NOT_AVAILABLE, "LoadLibraryA not found");
        }

        // 5. 원격 스레드 생성
        HandleGuard hThread(CreateRemoteThread(
            hProcess,
            NULL,
            0,
            (LPTHREAD_START_ROUTINE)pLoadLibrary,
            memGuard.get(),
            0,
            NULL
        ));

        CHECK_HANDLE(hThread, "CreateRemoteThread failed");
        LOG_INFO("Remote thread created");

        // 6. 스레드 완료 대기
        WaitForSingleObject(hThread, INFINITE);

        LOG_INFO("DLL injection completed successfully");
        LOG_EVENT("dll_injection", {
            {"status", "success"},
            {"target_pid", std::to_string(targetPid)},
            {"dll_path", dllPath}
        });

        // 모든 리소스 자동 해제 (hThread, memGuard, hProcess)

    } catch (const EDR::Exception& e) {
        LOG_ERROR(std::string("Injection failed: ") + e.what());
        LOG_EVENT("dll_injection", {
            {"status", "failed"},
            {"target_pid", std::to_string(targetPid)},
            {"error_code", e.GetErrorCodeName()},
            {"error_message", e.message()}
        });
        throw;  // 재발생
    }
}
```

### 예제 2: 에러 복구 (Error Recovery)

```cpp
HandleGuard OpenProcessWithFallback(DWORD pid) {
    // 1차 시도: 모든 권한
    HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (h) {
        LOG_INFO("Opened with PROCESS_ALL_ACCESS");
        return HandleGuard(h);
    }

    LOG_WARN("PROCESS_ALL_ACCESS failed, trying limited access");

    // 2차 시도: 제한된 권한
    h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (h) {
        LOG_INFO("Opened with limited access (graceful degradation)");
        return HandleGuard(h);
    }

    // 실패
    THROW_EDR_ERROR_CTX(
        ErrorCode::PROCESS_ACCESS_DENIED,
        "Failed to open process with any privileges",
        "PID: " + std::to_string(pid)
    );
}
```

### 예제 3: 트랜잭션 패턴 (Transaction Pattern)

```cpp
void ComplexOperation() {
    HandleGuard hProcess;
    VirtualMemoryGuard memGuard;
    bool phase1Complete = false;
    bool phase2Complete = false;

    // 정리 작업 설정
    auto rollback = MakeScopeGuard([&]() {
        if (phase2Complete && !phase1Complete) {
            LOG_WARN("Rolling back phase 2");
            // Phase 2 rollback
        }
        if (phase1Complete) {
            LOG_WARN("Rolling back phase 1");
            // Phase 1 rollback
        }
    });

    try {
        // Phase 1
        LOG_INFO("Starting phase 1");
        hProcess.reset(OpenProcess(...));
        CHECK_HANDLE(hProcess, "Phase 1 failed");
        phase1Complete = true;

        // Phase 2
        LOG_INFO("Starting phase 2");
        LPVOID pMem = VirtualAllocEx(hProcess, ...);
        memGuard.reset(hProcess, pMem, 4096);
        CHECK_POINTER(memGuard.get(), "Phase 2 failed");
        phase2Complete = true;

        // 성공 - 롤백 취소
        rollback.dismiss();
        LOG_INFO("Transaction completed successfully");

    } catch (const EDR::Exception& e) {
        LOG_ERROR(std::string("Transaction failed: ") + e.what());
        // rollback이 자동으로 실행됨
        throw;
    }
}
```

## 데모 프로그램 (Demo Program)

### 컴파일 (Compilation)

```powershell
cd samples\error_handling
cl /EHsc /std:c++17 /I..\..\include error_demo.cpp
```

또는 빌드 스크립트 사용:

```powershell
.\scripts\build.ps1
```

### 실행 (Execution)

```powershell
# 전체 데모 실행
.\error_demo.exe --all

# 특정 데모 실행
.\error_demo.exe 1    # Basic Error Handling
.\error_demo.exe 2    # RAII Handle Guard
.\error_demo.exe 3    # RAII Memory Guard
.\error_demo.exe 4    # Exception Hierarchy
.\error_demo.exe 5    # Error Recovery
.\error_demo.exe 6    # Scope Guard
.\error_demo.exe 7    # Real World Scenario
.\error_demo.exe 8    # Multiple Resources
```

### 데모 설명 (Demo Descriptions)

1. **Basic Error Handling**: 기본 에러 코드와 예외 처리
2. **RAII Handle Guard**: 자동 핸들 관리 및 이동 시맨틱
3. **RAII Memory Guard**: 자동 메모리 관리
4. **Exception Hierarchy**: 에러 코드 계층 구조
5. **Error Recovery**: 재시도 및 우아한 성능 저하
6. **Scope Guard**: 일반 정리 작업 자동화
7. **Real World Scenario**: 프로세스 인젝션 시뮬레이션
8. **Multiple Resources**: 다중 리소스 관리

## 통합 로깅 (Integration with Logging)

에러 처리 시스템은 로깅 시스템과 완벽하게 통합됩니다:

```cpp
#include "logger.hpp"
#include "error_handling.hpp"

try {
    // 작업 수행
} catch (const EDR::Exception& e) {
    // 자동으로 포맷된 에러 로그
    LOG_ERROR(e.what());
    
    // 구조화된 이벤트 로깅
    LOG_EVENT("operation_failed", {
        {"error_code", e.GetErrorCodeName()},
        {"error_message", e.message()},
        {"context", e.context()},
        {"system_error", std::to_string(e.systemError())}
    });
}
```

## 베스트 프랙티스 (Best Practices)

### 1. 항상 RAII 사용 (Always Use RAII)

❌ **나쁜 예**:
```cpp
HANDLE h = OpenProcess(...);
// ... 작업 수행 ...
CloseHandle(h);  // 예외 발생 시 누락될 수 있음
```

✅ **좋은 예**:
```cpp
HandleGuard h(OpenProcess(...));
// ... 작업 수행 ...
// 자동으로 해제됨
```

### 2. 명확한 에러 컨텍스트 제공 (Provide Clear Error Context)

❌ **나쁜 예**:
```cpp
THROW_EDR_ERROR(ErrorCode::INJECTION_FAILED, "Failed");
```

✅ **좋은 예**:
```cpp
THROW_EDR_ERROR_CTX(
    ErrorCode::INJECTION_FAILED,
    "DLL injection failed",
    "PID: " + std::to_string(pid) + ", DLL: " + dllPath
);
```

### 3. 조기 검증 (Validate Early)

```cpp
void ProcessData(void* data, size_t size) {
    // 파라미터 검증
    CHECK_POINTER(data, "Data pointer is null");
    
    if (size == 0) {
        THROW_EDR_ERROR(ErrorCode::INVALID_PARAMETER, "Size is zero");
    }
    
    // 실제 작업
    // ...
}
```

### 4. 예외 안전성 보장 (Exception Safety)

```cpp
void SafeOperation() {
    // Strong exception safety guarantee
    
    // 1. 임시 데이터로 작업
    std::vector<int> temp = currentData;
    
    // 2. 위험한 작업 (예외 가능)
    ProcessData(temp);
    
    // 3. 성공 시에만 커밋
    currentData = std::move(temp);
}
```

### 5. 리소스 누출 방지 (Prevent Resource Leaks)

```cpp
void MultipleResources() {
    HandleGuard h1(OpenProcess(...));
    
    // h1이 성공해도, h2가 실패하면 h1은 자동 해제됨
    HandleGuard h2(OpenProcess(...));
    
    // 모든 리소스 자동 관리
}
```

## 성능 고려사항 (Performance Considerations)

### 오버헤드 (Overhead)

- RAII 가드: 거의 제로 오버헤드 (인라인 최적화)
- 예외 발생: 일반적으로 느리지만, 오류 경로에서만 사용
- 에러 메시지 포맷팅: 예외 생성 시 한 번만 수행

### 최적화 팁 (Optimization Tips)

```cpp
// Hot path에서는 예외 대신 에러 코드 사용
ErrorCode FastOperation() {
    if (!condition) {
        return ErrorCode::INVALID_PARAMETER;  // 빠름
    }
    return ErrorCode::SUCCESS;
}

// Cold path에서는 예외 사용 (가독성 우선)
void SlowOperation() {
    if (!condition) {
        THROW_EDR_ERROR(ErrorCode::INVALID_PARAMETER, "...");
    }
}
```

## 문제 해결 (Troubleshooting)

### 컴파일 오류: "missing header"

```powershell
# include 디렉토리 경로 지정
cl /EHsc /std:c++17 /I..\..\include your_file.cpp
```

### 링크 오류: logger.hpp 관련

`error_handling.hpp`는 `logger.hpp`를 include하므로, 로깅 시스템도 함께 사용해야 합니다.

### 예외가 캡처되지 않음

C++ 예외를 활성화했는지 확인: `/EHsc` 플래그 필요

## 참고 자료 (References)

- [RAII in C++](https://en.cppreference.com/w/cpp/language/raii)
- [Exception Safety](https://en.cppreference.com/w/cpp/language/exceptions)
- [Windows Error Handling](https://docs.microsoft.com/en-us/windows/win32/debug/error-handling)
- ENHANCEMENT_SPEC.md - Category 2.2

## 라이선스 (License)

이 코드는 교육 목적으로만 사용되어야 합니다.
This code should only be used for educational purposes.
