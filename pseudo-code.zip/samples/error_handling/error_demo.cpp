/*
 * EDR Testing Tools - Error Handling Demonstration
 * 
 * Demonstrates:
 * 1. RAII resource management
 * 2. Exception handling
 * 3. Error code hierarchy
 * 4. Automatic cleanup
 * 5. Error context tracking
 * 6. Integration with logging system
 * 
 * Compilation:
 *   cl /EHsc /std:c++17 /I..\..\include error_demo.cpp
 * 
 * Usage:
 *   error_demo.exe [demo_number]
 *   error_demo.exe --all
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include "../../include/logger.hpp"
#include "../../include/error_handling.hpp"

using namespace EDR;

// Demo function declarations
void Demo1_BasicErrorHandling();
void Demo2_RAIIHandleGuard();
void Demo3_RAIIMemoryGuard();
void Demo4_ExceptionHierarchy();
void Demo5_ErrorRecovery();
void Demo6_ScopeGuard();
void Demo7_RealWorldScenario();
void Demo8_MultipleResources();

// Helper function to print demo header
void PrintDemoHeader(int num, const std::string& title) {
    std::cout << "\n========================================\n";
    std::cout << "Demo " << num << ": " << title << "\n";
    std::cout << "========================================\n\n";
}

int main(int argc, char* argv[]) {
    // Initialize logger
    Logger::Instance().SetOutputFile("logs/error_demo.log");
    Logger::Instance().SetLevel(EDRLOG_DEBUG);
    Logger::Instance().EnableConsole(true);
    LOG_INFO("Error handling demo started");

    bool runAll = false;
    int demoNum = 0;

    if (argc > 1) {
        std::string arg = argv[1];
        if (arg == "--all" || arg == "-a") {
            runAll = true;
        } else {
            demoNum = std::stoi(arg);
        }
    } else {
        std::cout << "Usage: error_demo.exe [demo_number | --all]\n";
        std::cout << "Available demos:\n";
        std::cout << "  1 - Basic Error Handling\n";
        std::cout << "  2 - RAII Handle Guard\n";
        std::cout << "  3 - RAII Memory Guard\n";
        std::cout << "  4 - Exception Hierarchy\n";
        std::cout << "  5 - Error Recovery\n";
        std::cout << "  6 - Scope Guard\n";
        std::cout << "  7 - Real World Scenario\n";
        std::cout << "  8 - Multiple Resources\n";
        return 0;
    }

    try {
        if (runAll || demoNum == 1) Demo1_BasicErrorHandling();
        if (runAll || demoNum == 2) Demo2_RAIIHandleGuard();
        if (runAll || demoNum == 3) Demo3_RAIIMemoryGuard();
        if (runAll || demoNum == 4) Demo4_ExceptionHierarchy();
        if (runAll || demoNum == 5) Demo5_ErrorRecovery();
        if (runAll || demoNum == 6) Demo6_ScopeGuard();
        if (runAll || demoNum == 7) Demo7_RealWorldScenario();
        if (runAll || demoNum == 8) Demo8_MultipleResources();

        std::cout << "\n✅ All demos completed successfully!\n";
        LOG_INFO("All error handling demos completed");
    }
    catch (const Exception& e) {
        std::cerr << "\n❌ Demo failed with exception:\n" << e.what() << "\n";
        LOG_ERROR(std::string("Demo failed: ") + e.what());
        return 1;
    }
    catch (const std::exception& e) {
        std::cerr << "\n❌ Unexpected exception: " << e.what() << "\n";
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        return 1;
    }

    return 0;
}

// Demo 1: Basic error handling
void Demo1_BasicErrorHandling() {
    PrintDemoHeader(1, "Basic Error Handling");

    LOG_INFO("Testing basic error codes and exceptions");

    try {
        // Test 1: Success case
        std::cout << "Test 1: Normal operation (no error)\n";
        DWORD processId = GetCurrentProcessId();
        std::cout << "✓ Current process ID: " << processId << "\n";

        // Test 2: Error with context
        std::cout << "\nTest 2: Throwing error with context\n";
        try {
            THROW_EDR_ERROR_CTX(
                ErrorCode::PROCESS_NOT_FOUND,
                "Failed to find target process",
                "PID: 99999"
            );
        }
        catch (const Exception& e) {
            std::cout << "✓ Caught exception:\n";
            std::cout << "  Code: " << e.GetErrorCodeName() << "\n";
            std::cout << "  Message: " << e.message() << "\n";
            std::cout << "  Context: " << e.context() << "\n";
            LOG_ERROR(e.what());
        }

        // Test 3: System error integration
        std::cout << "\nTest 3: System error capture\n";
        HANDLE hInvalid = CreateFileA(
            "C:\\NonExistent\\Path\\File.txt",
            GENERIC_READ,
            0,
            NULL,
            OPEN_EXISTING,
            0,
            NULL
        );
        if (hInvalid == INVALID_HANDLE_VALUE) {
            THROW_EDR_ERROR(ErrorCode::FILE_NOT_FOUND, "File does not exist");
        }
    }
    catch (const Exception& e) {
        std::cout << "✓ System error captured:\n";
        std::cout << "  System Error Code: " << e.systemError() << "\n";
        std::cout << "  Full Message: " << e.what() << "\n";
        LOG_ERROR(e.what());
    }

    std::cout << "\n✅ Demo 1 completed\n";
}

// Demo 2: RAII Handle Guard
void Demo2_RAIIHandleGuard() {
    PrintDemoHeader(2, "RAII Handle Guard");

    LOG_INFO("Testing RAII handle management");

    std::cout << "Test 1: Automatic handle cleanup\n";
    {
        // Handle is automatically closed when scope exits
        HandleGuard hProcess(OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId()));
        
        if (!hProcess) {
            std::cout << "✗ Failed to open process\n";
            return;
        }

        std::cout << "✓ Process handle opened: " << hProcess.get() << "\n";
        std::cout << "  (Handle will be automatically closed at scope exit)\n";
        
        // Use the handle
        DWORD exitCode = 0;
        GetExitCodeProcess(hProcess, &exitCode);
        std::cout << "  Exit code: " << exitCode << " (STILL_ACTIVE=" << STILL_ACTIVE << ")\n";
    }
    std::cout << "✓ Handle automatically closed\n";

    std::cout << "\nTest 2: Handle move semantics\n";
    {
        HandleGuard handle1(OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId()));
        std::cout << "✓ Handle1 created: " << handle1.get() << "\n";

        // Move handle1 to handle2
        HandleGuard handle2(std::move(handle1));
        std::cout << "✓ Handle moved to handle2: " << handle2.get() << "\n";
        std::cout << "✓ Handle1 after move: " << handle1.get() << " (NULL)\n";
    }

    std::cout << "\nTest 3: Handle with exception\n";
    try {
        HandleGuard hProcess(OpenProcess(PROCESS_ALL_ACCESS, FALSE, 99999));
        
        if (!hProcess) {
            THROW_EDR_ERROR_CTX(
                ErrorCode::PROCESS_NOT_FOUND,
                "Failed to open process",
                "PID: 99999"
            );
        }
    }
    catch (const Exception& e) {
        std::cout << "✓ Exception caught, handle cleaned up automatically\n";
        std::cout << "  Error: " << e.message() << "\n";
        LOG_ERROR(e.what());
    }

    std::cout << "\n✅ Demo 2 completed\n";
}

// Demo 3: RAII Memory Guard
void Demo3_RAIIMemoryGuard() {
    PrintDemoHeader(3, "RAII Memory Guard");

    LOG_INFO("Testing RAII memory management");

    std::cout << "Test 1: Automatic memory cleanup\n";
    {
        HANDLE hProcess = GetCurrentProcess();
        
        // Allocate memory - automatically freed when scope exits
        LPVOID pMem = VirtualAllocEx(
            hProcess,
            NULL,
            4096,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE
        );

        VirtualMemoryGuard memGuard(hProcess, pMem, 4096);
        
        if (!memGuard) {
            std::cout << "✗ Failed to allocate memory\n";
            return;
        }

        std::cout << "✓ Memory allocated: " << memGuard.get() << "\n";
        std::cout << "  Size: " << memGuard.size() << " bytes\n";
        std::cout << "  (Memory will be automatically freed at scope exit)\n";

        // Write to memory
        const char* testData = "Hello, EDR!";
        SIZE_T written = 0;
        WriteProcessMemory(hProcess, memGuard.get(), testData, strlen(testData) + 1, &written);
        std::cout << "✓ Wrote " << written << " bytes to memory\n";
    }
    std::cout << "✓ Memory automatically freed\n";

    std::cout << "\nTest 2: Memory with exception handling\n";
    try {
        HANDLE hProcess = GetCurrentProcess();
        LPVOID pMem = VirtualAllocEx(hProcess, NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        VirtualMemoryGuard memGuard(hProcess, pMem, 4096);

        if (!memGuard) {
            THROW_EDR_ERROR(ErrorCode::MEMORY_ALLOCATION_FAILED, "VirtualAllocEx failed");
        }

        std::cout << "✓ Memory allocated: " << memGuard.get() << "\n";

        // Simulate error
        THROW_EDR_ERROR_CTX(
            ErrorCode::MEMORY_WRITE_FAILED,
            "Simulated write error",
            "Address: " + std::to_string((uintptr_t)memGuard.get())
        );
    }
    catch (const Exception& e) {
        std::cout << "✓ Exception caught, memory cleaned up automatically\n";
        std::cout << "  Error: " << e.message() << "\n";
        LOG_ERROR(e.what());
    }

    std::cout << "\n✅ Demo 3 completed\n";
}

// Demo 4: Exception Hierarchy
void Demo4_ExceptionHierarchy() {
    PrintDemoHeader(4, "Exception Hierarchy");

    LOG_INFO("Testing exception hierarchy and error codes");

    std::cout << "Test 1: Process-related errors (1xxx)\n";
    try {
        THROW_EDR_ERROR(ErrorCode::PROCESS_NOT_FOUND, "Process not found");
    }
    catch (const Exception& e) {
        std::cout << "✓ Caught: " << e.GetErrorCodeName() 
                  << " (Code: " << static_cast<int>(e.code()) << ")\n";
    }

    std::cout << "\nTest 2: Memory-related errors (2xxx)\n";
    try {
        THROW_EDR_ERROR(ErrorCode::MEMORY_ALLOCATION_FAILED, "Memory allocation failed");
    }
    catch (const Exception& e) {
        std::cout << "✓ Caught: " << e.GetErrorCodeName() 
                  << " (Code: " << static_cast<int>(e.code()) << ")\n";
    }

    std::cout << "\nTest 3: Injection-related errors (3xxx)\n";
    try {
        THROW_EDR_ERROR(ErrorCode::INJECTION_FAILED, "Injection failed");
    }
    catch (const Exception& e) {
        std::cout << "✓ Caught: " << e.GetErrorCodeName() 
                  << " (Code: " << static_cast<int>(e.code()) << ")\n";
    }

    std::cout << "\nTest 4: File-related errors (4xxx)\n";
    try {
        THROW_EDR_ERROR(ErrorCode::FILE_NOT_FOUND, "File not found");
    }
    catch (const Exception& e) {
        std::cout << "✓ Caught: " << e.GetErrorCodeName() 
                  << " (Code: " << static_cast<int>(e.code()) << ")\n";
    }

    std::cout << "\nTest 5: Permission-related errors (5xxx)\n";
    try {
        THROW_EDR_ERROR(ErrorCode::ELEVATION_REQUIRED, "Administrator privileges required");
    }
    catch (const Exception& e) {
        std::cout << "✓ Caught: " << e.GetErrorCodeName() 
                  << " (Code: " << static_cast<int>(e.code()) << ")\n";
    }

    std::cout << "\n✅ Demo 4 completed\n";
}

// Demo 5: Error Recovery
void Demo5_ErrorRecovery() {
    PrintDemoHeader(5, "Error Recovery");

    LOG_INFO("Testing error recovery patterns");

    std::cout << "Test 1: Retry with fallback\n";
    
    std::vector<DWORD> targetPids = {99999, 88888, GetCurrentProcessId()};
    HandleGuard hProcess;

    for (DWORD pid : targetPids) {
        std::cout << "  Attempting to open PID " << pid << "... ";
        
        HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
        if (h) {
            hProcess.reset(h);
            std::cout << "✓ Success!\n";
            LOG_INFO("Successfully opened process PID: " + std::to_string(pid));
            break;
        } else {
            std::cout << "✗ Failed (Error: " << GetLastError() << ")\n";
            LOG_WARN("Failed to open PID " + std::to_string(pid));
        }
    }

    if (hProcess) {
        std::cout << "✓ Recovered successfully with fallback PID\n";
    } else {
        std::cout << "✗ All attempts failed\n";
    }

    std::cout << "\nTest 2: Graceful degradation\n";
    try {
        // Try high privilege operation
        std::cout << "  Attempting high-privilege operation... ";
        HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, GetCurrentProcessId());
        if (!h) {
            throw Exception(ErrorCode::PERMISSION_DENIED, "Full access denied", "", __FILE__, __LINE__);
        }
        HandleGuard hFullAccess(h);
        std::cout << "✓ Full access granted\n";
    }
    catch (const Exception& e) {
        std::cout << "✗ Failed\n";
        std::cout << "  Falling back to limited privileges... ";
        
        // Fallback to lower privilege
        HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
        if (h) {
            HandleGuard hLimitedAccess(h);
            std::cout << "✓ Limited access granted (graceful degradation)\n";
            LOG_INFO("Gracefully degraded to limited access");
        }
    }

    std::cout << "\n✅ Demo 5 completed\n";
}

// Demo 6: Scope Guard
void Demo6_ScopeGuard() {
    PrintDemoHeader(6, "Scope Guard");

    LOG_INFO("Testing scope guard for generic cleanup");

    std::cout << "Test 1: Basic scope guard\n";
    {
        int counter = 0;
        std::cout << "  Counter before: " << counter << "\n";

        {
            auto guard = MakeScopeGuard([&counter]() {
                counter++;
                std::cout << "  Scope guard executed, counter incremented\n";
            });

            std::cout << "  Inside scope, counter: " << counter << "\n";
        }

        std::cout << "  Counter after scope exit: " << counter << "\n";
    }

    std::cout << "\nTest 2: Scope guard with dismissal\n";
    {
        bool cleanupExecuted = false;

        {
            auto guard = MakeScopeGuard([&cleanupExecuted]() {
                cleanupExecuted = true;
            });

            std::cout << "  Dismissing guard...\n";
            guard.dismiss();
        }

        std::cout << "  Cleanup executed: " << (cleanupExecuted ? "Yes" : "No (dismissed)") << "\n";
    }

    std::cout << "\nTest 3: Multiple scope guards (LIFO order)\n";
    {
        auto guard1 = MakeScopeGuard([]() { std::cout << "  Cleanup 1 executed\n"; });
        auto guard2 = MakeScopeGuard([]() { std::cout << "  Cleanup 2 executed\n"; });
        auto guard3 = MakeScopeGuard([]() { std::cout << "  Cleanup 3 executed\n"; });
        
        std::cout << "  Exiting scope (guards execute in reverse order)...\n";
    }

    std::cout << "\n✅ Demo 6 completed\n";
}

// Demo 7: Real World Scenario
void Demo7_RealWorldScenario() {
    PrintDemoHeader(7, "Real World Scenario - Process Injection");

    LOG_INFO("Testing real-world scenario: process injection with error handling");

    try {
        std::cout << "Step 1: Opening target process...\n";
        DWORD targetPid = GetCurrentProcessId(); // Use current process for demo
        
        HandleGuard hProcess(OpenProcess(
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_CREATE_THREAD,
            FALSE,
            targetPid
        ));

        CHECK_HANDLE(hProcess, "Failed to open target process");
        std::cout << "✓ Process opened (PID: " << targetPid << ")\n";
        LOG_INFO("Process opened successfully");

        std::cout << "\nStep 2: Allocating memory in target process...\n";
        SIZE_T allocSize = 4096;
        LPVOID pRemote = VirtualAllocEx(
            hProcess,
            NULL,
            allocSize,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE
        );

        VirtualMemoryGuard memGuard(hProcess, pRemote, allocSize);
        
        if (!memGuard) {
            THROW_EDR_ERROR(
                ErrorCode::MEMORY_ALLOCATION_FAILED,
                "VirtualAllocEx failed"
            );
        }
        std::cout << "✓ Memory allocated (Address: " << memGuard.get() 
                  << ", Size: " << memGuard.size() << ")\n";
        LOG_INFO("Memory allocated successfully");

        std::cout << "\nStep 3: Writing payload to remote process...\n";
        const char* payload = "NOP sled: \x90\x90\x90\x90";
        SIZE_T written = 0;
        
        if (!WriteProcessMemory(hProcess, memGuard.get(), payload, strlen(payload), &written)) {
            THROW_EDR_ERROR_CTX(
                ErrorCode::MEMORY_WRITE_FAILED,
                "WriteProcessMemory failed",
                "Address: " + std::to_string((uintptr_t)memGuard.get())
            );
        }
        std::cout << "✓ Payload written (" << written << " bytes)\n";
        LOG_INFO("Payload written successfully");

        std::cout << "\nStep 4: Simulating thread creation (skipped for demo safety)...\n";
        std::cout << "✓ Would create remote thread here in real scenario\n";
        LOG_INFO("Thread creation step skipped (demo mode)");

        std::cout << "\n✅ Injection simulation completed successfully\n";
        std::cout << "   (All resources will be automatically cleaned up)\n";
        
        Logger::Instance().LogEvent("injection_simulation", EDRLOG_INFO, {
            {"status", "success"},
            {"target_pid", std::to_string(targetPid)},
            {"memory_allocated", std::to_string(allocSize)},
            {"bytes_written", std::to_string(written)}
        });
    }
    catch (const Exception& e) {
        std::cout << "\n❌ Injection failed: " << e.message() << "\n";
        std::cout << "   (Cleanup performed automatically by RAII guards)\n";
        LOG_ERROR(std::string("Injection failed: ") + e.what());
        
        Logger::Instance().LogEvent("injection_simulation", EDRLOG_ERROR, {
            {"status", "failed"},
            {"error_code", e.GetErrorCodeName()},
            {"error_message", e.message()}
        });
    }

    std::cout << "\n✅ Demo 7 completed\n";
}

// Demo 8: Multiple Resources
void Demo8_MultipleResources() {
    PrintDemoHeader(8, "Multiple Resources Management");

    LOG_INFO("Testing multiple resource management");

    std::cout << "Managing multiple resources simultaneously:\n";

    try {
        // Resource 1: Process handle
        std::cout << "\n1. Opening process handle...\n";
        HandleGuard hProcess(OpenProcess(
            PROCESS_QUERY_INFORMATION,
            FALSE,
            GetCurrentProcessId()
        ));
        CHECK_HANDLE(hProcess, "Failed to open process");
        std::cout << "✓ Process handle: " << hProcess.get() << "\n";

        // Resource 2: Memory allocation
        std::cout << "\n2. Allocating memory...\n";
        LPVOID pMem = VirtualAllocEx(
            hProcess,
            NULL,
            4096,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE
        );
        VirtualMemoryGuard memGuard(hProcess, pMem, 4096);
        CHECK_POINTER(memGuard.get(), "Memory allocation failed");
        std::cout << "✓ Memory allocated: " << memGuard.get() << "\n";

        // Resource 3: File handle
        std::cout << "\n3. Creating temporary file...\n";
        FileHandleGuard hFile(CreateFileA(
            "temp_test.txt",
            GENERIC_WRITE,
            0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_TEMPORARY,
            NULL
        ));
        CHECK_HANDLE(hFile, "Failed to create file");
        std::cout << "✓ File created: temp_test.txt\n";

        // Resource 4: Library
        std::cout << "\n4. Loading library...\n";
        LibraryGuard hLib(LoadLibraryA("kernel32.dll"));
        CHECK_HANDLE(hLib, "Failed to load library");
        std::cout << "✓ Library loaded: kernel32.dll\n";

        std::cout << "\n✅ All 4 resources acquired successfully\n";
        std::cout << "   Resources will be released in reverse order:\n";
        std::cout << "   4 → 3 → 2 → 1 (LIFO/Stack order)\n";

        LOG_INFO("Multiple resources managed successfully");

    } catch (const Exception& e) {
        std::cout << "\n❌ Resource management failed: " << e.message() << "\n";
        std::cout << "   Partial resources will be automatically cleaned up\n";
        LOG_ERROR(std::string("Resource management failed: ") + e.what());
    }

    // Cleanup temp file
    DeleteFileA("temp_test.txt");

    std::cout << "\n✅ Demo 8 completed\n";
}
