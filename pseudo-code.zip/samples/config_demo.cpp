/**
 * @file config_demo.cpp
 * @brief ConfigManager 사용 예제 및 데모
 * @details
 * ConfigManager의 모든 기능을 시연하는 데모 프로그램
 * - 설정 로드/저장
 * - 프로파일 전환
 * - 설정 값 읽기/쓰기
 * - 환경 변수 오버라이드
 * - 대화형 설정 관리
 */

#include <iostream>
#include <windows.h>
#include "../include/config_manager.hpp"
#include "../include/logger.hpp"

using namespace EDR;

// 콘솔 색상 유틸리티
void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void PrintSection(const std::string& title) {
    SetColor(14); // Yellow
    std::cout << "\n+--------------------------------------------------------------+" << std::endl;
    std::cout << "|  " << title;
    for (size_t i = title.length(); i < 58; ++i) std::cout << " ";
    std::cout << "|" << std::endl;
    std::cout << "+--------------------------------------------------------------+" << std::endl;
    SetColor(7);
}

void PrintSuccess(const std::string& message) {
    SetColor(10); // Green
    std::cout << "[OK] " << message << std::endl;
    SetColor(7);
}

void PrintInfo(const std::string& message) {
    SetColor(11); // Cyan
    std::cout << "[i] " << message << std::endl;
    SetColor(7);
}

void PrintError(const std::string& message) {
    SetColor(12); // Red
    std::cout << "[X] " << message << std::endl;
    SetColor(7);
}

// Demo 1: 기본 설정 로드 및 표시
void Demo1_BasicConfiguration() {
    PrintSection("Demo 1: Basic Configuration Loading");
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 기본 설정 로드
    PrintInfo("Loading default configuration from config.json...");
    if (config.LoadFromFile("config.json")) {
        PrintSuccess("Configuration loaded successfully");
    } else {
        PrintError("Failed to load configuration");
        return;
    }
    
    // 현재 프로파일 표시
    std::cout << "\nCurrent Profile: " << config.GetProfile() << std::endl;
    
    // 주요 설정 값 표시
    std::cout << "\nExecution Settings:" << std::endl;
    std::cout << "  - Timeout: " << config.GetExecutionTimeout() << " seconds" << std::endl;
    std::cout << "  - Retry Count: " << config.GetRetryCount() << std::endl;
    std::cout << "  - Delay: " << config.GetDelayBetweenTests() << " ms" << std::endl;
    
    std::cout << "\nLogging Settings:" << std::endl;
    std::cout << "  - Level: " << config.GetLoggingLevel() << std::endl;
    std::cout << "  - Output: " << config.GetLogOutputFile() << std::endl;
    std::cout << "  - Format: " << config.GetLogFormat() << std::endl;
    
    std::cout << "\nSafety Settings:" << std::endl;
    std::cout << "  - Require Confirmation: " << (config.GetRequireConfirmation() ? "Yes" : "No") << std::endl;
    std::cout << "  - Sandbox Check: " << (config.GetSandboxCheck() ? "Yes" : "No") << std::endl;
    
    PrintSuccess("Basic configuration demo complete");
}

// Demo 2: 프로파일 전환
void Demo2_ProfileSwitching() {
    PrintSection("Demo 2: Profile Switching");
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 현재 프로파일 표시
    PrintInfo("Current profile: " + config.GetProfile());
    std::cout << "  - Timeout: " << config.GetExecutionTimeout() << "s" << std::endl;
    std::cout << "  - Retry: " << config.GetRetryCount() << std::endl;
    
    // Aggressive 프로파일로 전환
    PrintInfo("\nSwitching to 'aggressive' profile...");
    if (config.LoadFromFile("config_aggressive.json")) {
        config.SetProfile("aggressive");
        PrintSuccess("Switched to aggressive profile");
        
        std::cout << "\nNew Settings:" << std::endl;
        std::cout << "  - Timeout: " << config.GetExecutionTimeout() << "s (increased)" << std::endl;
        std::cout << "  - Retry: " << config.GetRetryCount() << " (increased)" << std::endl;
        std::cout << "  - Concurrent Tests: " << config.GetMaxConcurrentTests() << std::endl;
        std::cout << "  - Require Confirmation: " << (config.GetRequireConfirmation() ? "Yes" : "No") << " (disabled)" << std::endl;
    } else {
        PrintError("Failed to load aggressive profile");
    }
    
    // 다시 기본 프로파일로 복귀
    PrintInfo("\nRestoring default profile...");
    config.LoadFromFile("config.json");
    config.SetProfile("default");
    PrintSuccess("Restored to default profile");
}

// Demo 3: 시나리오 및 기법 관리
void Demo3_ScenarioManagement() {
    PrintSection("Demo 3: Scenario and Technique Management");
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 활성화된 시나리오 표시
    PrintInfo("Checking enabled scenarios...");
    
    std::vector<std::string> scenarios = {"process_injection", "fileless", "shellcode"};
    
    for (const auto& scenario : scenarios) {
        bool enabled = config.IsScenarioEnabled(scenario);
        auto techniques = config.GetEnabledTechniques(scenario);
        
        std::cout << "\n" << scenario << ": ";
        if (enabled) {
            SetColor(10);
            std::cout << "ENABLED";
            SetColor(7);
            std::cout << " (" << techniques.size() << " techniques)" << std::endl;
            
            for (const auto& tech : techniques) {
                std::cout << "  - " << tech << std::endl;
            }
        } else {
            SetColor(12);
            std::cout << "DISABLED";
            SetColor(7);
            std::cout << std::endl;
        }
    }
    
    // 모든 활성화된 기법 가져오기
    PrintInfo("\nGetting all enabled techniques...");
    auto allTechniques = config.GetAllEnabledTechniques();
    std::cout << "Total enabled techniques: " << allTechniques.size() << std::endl;
    
    // 새로운 기법 추가
    PrintInfo("\nAdding new technique to process_injection scenario...");
    config.AddTechnique("process_injection", "T1055.013");
    PrintSuccess("Technique added: T1055.013");
    
    auto updatedTechniques = config.GetEnabledTechniques("process_injection");
    std::cout << "Updated technique count: " << updatedTechniques.size() << std::endl;
}

// Demo 4: 설정 값 읽기/쓰기
void Demo4_ConfigurationReadWrite() {
    PrintSection("Demo 4: Configuration Read/Write Operations");
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 기존 값 읽기
    PrintInfo("Reading configuration values...");
    int timeout = config.GetExecutionTimeout();
    std::string logLevel = config.GetLoggingLevel();
    
    std::cout << "Current Values:" << std::endl;
    std::cout << "  - Timeout: " << timeout << "s" << std::endl;
    std::cout << "  - Log Level: " << logLevel << std::endl;
    
    // 값 수정
    PrintInfo("\nModifying configuration values...");
    config.SetValue("execution.timeout_seconds", 90);
    config.SetValue("logging.level", "DEBUG");
    
    PrintSuccess("Configuration modified");
    
    // 수정된 값 확인
    std::cout << "\nNew Values:" << std::endl;
    std::cout << "  - Timeout: " << config.GetExecutionTimeout() << "s" << std::endl;
    std::cout << "  - Log Level: " << config.GetLoggingLevel() << std::endl;
    
    // JSON 경로를 사용한 복잡한 값 접근
    PrintInfo("\nAccessing nested configuration using JSON paths...");
    auto rawValue = config.GetValue("detection.etw_providers");
    if (rawValue.is_array()) {
        std::cout << "ETW Providers:" << std::endl;
        for (const auto& provider : rawValue) {
            std::cout << "  - " << provider.get<std::string>() << std::endl;
        }
    }
    
    // 파일로 저장
    PrintInfo("\nSaving configuration to file...");
    if (config.SaveToFile("config_custom.json")) {
        PrintSuccess("Configuration saved to config_custom.json");
    } else {
        PrintError("Failed to save configuration");
    }
}

// Demo 5: 환경 변수 오버라이드
void Demo5_EnvironmentVariables() {
    PrintSection("Demo 5: Environment Variable Overrides");
    
    ConfigManager& config = ConfigManager::Instance();
    
    PrintInfo("Setting environment variables...");
    
    // 환경 변수 설정
    SetEnvironmentVariableA("EDR_CONFIG_TIMEOUT", "180");
    SetEnvironmentVariableA("EDR_CONFIG_LOG_LEVEL", "TRACE");
    SetEnvironmentVariableA("EDR_CONFIG_REQUIRE_CONFIRM", "false");
    
    std::cout << "Set environment variables:" << std::endl;
    std::cout << "  - EDR_CONFIG_TIMEOUT=180" << std::endl;
    std::cout << "  - EDR_CONFIG_LOG_LEVEL=TRACE" << std::endl;
    std::cout << "  - EDR_CONFIG_REQUIRE_CONFIRM=false" << std::endl;
    
    // 환경 변수 적용
    PrintInfo("\nApplying environment variable overrides...");
    config.ApplyEnvironmentVariableOverrides();
    PrintSuccess("Environment variables applied");
    
    // 오버라이드된 값 확인
    std::cout << "\nOverridden Values:" << std::endl;
    std::cout << "  - Timeout: " << config.GetExecutionTimeout() << "s" << std::endl;
    std::cout << "  - Log Level: " << config.GetLoggingLevel() << std::endl;
    std::cout << "  - Require Confirmation: " << (config.GetRequireConfirmation() ? "Yes" : "No") << std::endl;
    
    // 환경 변수 제거
    SetEnvironmentVariableA("EDR_CONFIG_TIMEOUT", nullptr);
    SetEnvironmentVariableA("EDR_CONFIG_LOG_LEVEL", nullptr);
    SetEnvironmentVariableA("EDR_CONFIG_REQUIRE_CONFIRM", nullptr);
}

// Demo 6: 설정 요약 출력
void Demo6_ConfigurationSummary() {
    PrintSection("Demo 6: Configuration Summary");
    
    ConfigManager& config = ConfigManager::Instance();
    
    // 기본 설정 로드
    config.LoadFromFile("config.json");
    
    PrintInfo("Printing complete configuration summary...");
    std::cout << std::endl;
    
    config.PrintSummary();
}

// 대화형 메뉴
void InteractiveMenu() {
    PrintSection("Interactive Configuration Manager");
    
    ConfigManager& config = ConfigManager::Instance();
    config.LoadFromFile("config.json");
    
    while (true) {
        std::cout << "\n+---------------------------------------+" << std::endl;
        std::cout << "|       Configuration Manager           |" << std::endl;
        std::cout << "+---------------------------------------+" << std::endl;
        std::cout << "|  1. Show Current Configuration        |" << std::endl;
        std::cout << "|  2. Switch Profile                    |" << std::endl;
        std::cout << "|  3. List Scenarios                    |" << std::endl;
        std::cout << "|  4. Modify Setting                    |" << std::endl;
        std::cout << "|  5. Save Configuration                |" << std::endl;
        std::cout << "|  6. Run All Demos                     |" << std::endl;
        std::cout << "|  0. Exit                              |" << std::endl;
        std::cout << "+---------------------------------------+" << std::endl;
        std::cout << "\nSelect option: ";
        
        int choice;
        std::cin >> choice;
        
        switch (choice) {
            case 1:
                config.PrintSummary();
                break;
                
            case 2: {
                std::cout << "\nAvailable profiles:" << std::endl;
                std::cout << "  1. default" << std::endl;
                std::cout << "  2. aggressive" << std::endl;
                std::cout << "Select profile: ";
                
                int profileChoice;
                std::cin >> profileChoice;
                
                std::string profile = (profileChoice == 2) ? "aggressive" : "default";
                std::string configFile = (profileChoice == 2) ? "config_aggressive.json" : "config.json";
                
                if (config.LoadFromFile(configFile)) {
                    config.SetProfile(profile);
                    PrintSuccess("Switched to " + profile + " profile");
                } else {
                    PrintError("Failed to load profile");
                }
                break;
            }
            
            case 3: {
                std::vector<std::string> scenarios = {"process_injection", "fileless", "shellcode"};
                std::cout << "\nEnabled Scenarios:" << std::endl;
                
                for (const auto& scenario : scenarios) {
                    bool enabled = config.IsScenarioEnabled(scenario);
                    auto techniques = config.GetEnabledTechniques(scenario);
                    
                    SetColor(enabled ? 10 : 12);
                    std::cout << "  - " << scenario << " [" << (enabled ? "ON" : "OFF") << "]";
                    SetColor(7);
                    std::cout << " (" << techniques.size() << " techniques)" << std::endl;
                }
                break;
            }
            
            case 4: {
                std::cout << "\nCommon settings:" << std::endl;
                std::cout << "  1. execution.timeout_seconds" << std::endl;
                std::cout << "  2. logging.level" << std::endl;
                std::cout << "  3. safety.require_confirmation" << std::endl;
                std::cout << "Enter JSON path: ";
                
                std::string path;
                std::cin.ignore();
                std::getline(std::cin, path);
                
                std::cout << "Enter value: ";
                std::string value;
                std::getline(std::cin, value);
                
                try {
                    // 값 타입 추론
                    json jsonValue;
                    if (value == "true" || value == "false") {
                        jsonValue = (value == "true");
                    } else if (value.find_first_not_of("0123456789") == std::string::npos) {
                        jsonValue = std::stoi(value);
                    } else {
                        jsonValue = value;
                    }
                    
                    config.SetValue(path, jsonValue);
                    PrintSuccess("Configuration updated");
                } catch (const std::exception& e) {
                    PrintError(std::string("Failed to update: ") + e.what());
                }
                break;
            }
            
            case 5: {
                std::cout << "\nEnter filename (default: config_custom.json): ";
                std::string filename;
                std::cin.ignore();
                std::getline(std::cin, filename);
                
                if (filename.empty()) {
                    filename = "config_custom.json";
                }
                
                if (config.SaveToFile(filename)) {
                    PrintSuccess("Configuration saved to " + filename);
                } else {
                    PrintError("Failed to save configuration");
                }
                break;
            }
            
            case 6:
                Demo1_BasicConfiguration();
                std::cout << "\nPress Enter to continue...";
                std::cin.ignore();
                std::cin.get();
                
                Demo2_ProfileSwitching();
                std::cout << "\nPress Enter to continue...";
                std::cin.get();
                
                Demo3_ScenarioManagement();
                std::cout << "\nPress Enter to continue...";
                std::cin.get();
                
                Demo4_ConfigurationReadWrite();
                std::cout << "\nPress Enter to continue...";
                std::cin.get();
                
                Demo5_EnvironmentVariables();
                std::cout << "\nPress Enter to continue...";
                std::cin.get();
                
                Demo6_ConfigurationSummary();
                std::cout << "\nPress Enter to continue...";
                std::cin.get();
                break;
                
            case 0:
                PrintInfo("Exiting configuration manager...");
                return;
                
            default:
                PrintError("Invalid option. Please try again.");
        }
    }
}

int main(int argc, char* argv[]) {
    // 로거 초기화
    Logger::Instance().SetLevel(Logger::Level::INFO);
    
    std::cout << R"(
+--------------------------------------------------------------+
|        ConfigManager Demonstration Program v1.0             |
|                                                              |
|  This program demonstrates all features of ConfigManager:   |
|  - Configuration loading and saving                         |
|  - Profile switching (default, aggressive)                  |
|  - Scenario and technique management                        |
|  - Configuration value read/write                           |
|  - Environment variable overrides                           |
|  - Interactive configuration editor                         |
+--------------------------------------------------------------+
)" << std::endl;
    
    if (argc > 1 && std::string(argv[1]) == "--interactive") {
        InteractiveMenu();
    } else {
        std::cout << "\nRunning all demos..." << std::endl;
        std::cout << "\nPress Enter to start...";
        std::cin.get();
        
        Demo1_BasicConfiguration();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo2_ProfileSwitching();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo3_ScenarioManagement();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo4_ConfigurationReadWrite();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo5_EnvironmentVariables();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo6_ConfigurationSummary();
        
        std::cout << "\n\n";
        PrintSuccess("All demos completed!");
        std::cout << "\nTip: Run with --interactive flag for interactive mode:" << std::endl;
        std::cout << "     config_demo.exe --interactive" << std::endl;
    }
    
    return 0;
}
