# Evasion Techniques (회피 기법)

## MITRE ATT&CK
**Technique IDs**: T1497 (Virtualization/Sandbox Evasion), T1622 (Debugger Evasion)  
**Tactic**: Defense Evasion, Discovery  
**Platform**: Windows

---

## 개요 (Overview)

악성코드가 분석 환경(샌드박스, 가상머신, 디버거)을 탐지하고 회피하는 기법들을 테스트합니다.

Tests malware techniques to detect and evade analysis environments (sandboxes, VMs, debuggers).

---

## 회피 기법 분류 (Evasion Categories)

### 1. 샌드박스 탐지 (Sandbox Detection)
- 제한된 리소스 확인
- 사용자 활동 부재 감지
- 분석 도구 탐지
- 환경 아티팩트 확인

### 2. 가상머신 탐지 (VM Detection)
- CPUID 명령어 사용
- 특정 레지스트리 키 확인
- VM 관련 파일/프로세스 탐지
- 하드웨어 정보 분석

### 3. 디버거 탐지 (Anti-Debugging)
- IsDebuggerPresent API
- PEB 플래그 확인
- 타이밍 체크
- 예외 처리 기법

### 4. 타이밍 공격 (Timing Attacks)
- Sleep 가속화 탐지
- 명령어 실행 시간 측정
- RDTSC 명령어 사용

---

## 샘플 코드 (Sample Code)

### 1. sandbox_detection.cpp
다양한 샌드박스 탐지 기법 구현

### 2. anti_debugging.cpp
여러 안티 디버깅 기법 테스트

### 3. timing_attacks.cpp
타이밍 기반 탐지 우회 기법

---

## 사용 방법 (Usage)

```powershell
cd samples\evasion

# 컴파일
cl /EHsc /W4 sandbox_detection.cpp /Fe:sandbox_detection.exe
cl /EHsc /W4 anti_debugging.cpp /Fe:anti_debugging.exe
cl /EHsc /W4 timing_attacks.cpp /Fe:timing_attacks.exe

# 실행
.\sandbox_detection.exe
.\anti_debugging.exe
.\timing_attacks.exe
```

---

## 탐지 포인트 (Detection Points)

### EDR이 탐지해야 할 행위
- ✅ IsDebuggerPresent 호출
- ✅ PEB 접근 시도
- ✅ CPUID 명령어 실행
- ✅ 레지스트리 분석 환경 키 확인
- ✅ 특정 프로세스/파일 검색
- ✅ 비정상적인 Sleep 패턴

---

**Last Updated**: 2025-10-14
