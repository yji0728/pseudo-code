﻿/*
 * Process Hollowing Test - EDR Detection Test (Enhanced Version)
 * 
 * 목적: Process Hollowing 기법을 통해 정상 프로세스를 생성 후 악성 코드로 교체
 * Purpose: Test EDR's ability to detect process hollowing technique
 * 
 * 탐지 포인트 (Detection Points):
 * - CreateProcess with CREATE_SUSPENDED flag
 * - NtUnmapViewOfSection to unmap original executable
 * - VirtualAllocEx to allocate new memory
 * - WriteProcessMemory to write new code
 * - SetThreadContext to modify entry point
 * - ResumeThread to execute injected code
 * 
 * Enhancements:
 * - error_handling.hpp integration
 * - RAII pattern for resource management
 * - Structured error handling
 * - logger.hpp integration
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <winternl.h>
#include <iostream>
#include "../../include/error_handling.hpp"
#include "../../include/logger.hpp"

using namespace EDR;

// Function pointer types for NT APIs
typedef NTSTATUS(NTAPI* pNtUnmapViewOfSection)(HANDLE, PVOID);
typedef NTSTATUS(NTAPI* pNtQueryInformationProcess)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);

void SimulateProcessHollowing() {
    try {
        LOG_INFO("=== Process Hollowing Test Started ===");
        
        std::wcout << L"==================================================" << std::endl;
        std::wcout << L"    EDR Test: Process Hollowing Technique" << std::endl;
        std::wcout << L"    Enhanced with Error Handling & Logging" << std::endl;
        std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
        std::wcout << L"==================================================" << std::endl;
        std::wcout << std::endl;

        // Step 1: Create target process in suspended state
        LOG_INFO("[1] Creating suspended process (calc.exe)");
        std::wcout << L"[1] Creating suspended process (calc.exe)..." << std::endl;
        
        STARTUPINFOW si = { sizeof(si) };
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        ZeroMemory(&pi, sizeof(pi));

        wchar_t targetPath[] = L"C:\\Windows\\System32\\calc.exe";
        
        if (!CreateProcessW(
            targetPath,
            NULL,
            NULL,
            NULL,
            FALSE,
            CREATE_SUSPENDED,  // Critical: Process created in suspended state
            NULL,
            NULL,
            &si,
            &pi)) {
            throw Exception(ErrorCode::PROCESS_NOT_FOUND, 
                           "Failed to create suspended process",
                           "CreateProcessW", __FILE__, __LINE__);
        }

        // Use RAII for process/thread handles
        HandleGuard hProcess(pi.hProcess);
        HandleGuard hThread(pi.hThread);

        LOG_INFO("[+] Process created in suspended state");
        LOG_INFO("PID: " + std::to_string(pi.dwProcessId));
        LOG_INFO("Thread ID: " + std::to_string(pi.dwThreadId));
        
        std::wcout << L"[+] Process created in suspended state" << std::endl;
        std::wcout << L"    PID: " << pi.dwProcessId << std::endl;
        std::wcout << L"    Thread ID: " << pi.dwThreadId << std::endl;

        // Step 2: Get process context
        LOG_INFO("\n[2] Getting thread context");
        std::wcout << L"\n[2] Getting thread context..." << std::endl;
        
        CONTEXT ctx;
        ctx.ContextFlags = CONTEXT_FULL;
        
        if (!GetThreadContext(hThread.get(), &ctx)) {
            throw Exception(ErrorCode::SYSTEM_CALL_FAILED, 
                           "Failed to get thread context",
                           "GetThreadContext", __FILE__, __LINE__);
        }
        
        LOG_INFO("[+] Thread context retrieved");
        std::wcout << L"[+] Thread context retrieved" << std::endl;

        // Step 3: Simulate unmapping of original image
        LOG_INFO("\n[3] Demonstrating NtUnmapViewOfSection call");
        std::wcout << L"\n[3] Demonstrating NtUnmapViewOfSection call..." << std::endl;
        std::wcout << L"    (This would unmap the original executable from memory)" << std::endl;
        std::wcout << L"    API: NtUnmapViewOfSection()" << std::endl;
        
        // Load ntdll for demonstration
        HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
        if (!hNtdll) {
            LOG_WARN("Failed to get ntdll.dll handle");
        } else {
            pNtUnmapViewOfSection NtUnmapViewOfSection = 
                (pNtUnmapViewOfSection)GetProcAddress(hNtdll, "NtUnmapViewOfSection");
            
            if (NtUnmapViewOfSection) {
                std::stringstream ss;
                ss << "[+] NtUnmapViewOfSection address: 0x" << std::hex 
                   << (DWORD_PTR)NtUnmapViewOfSection << std::dec;
                LOG_INFO(ss.str());
                std::wcout << EDR::StringToWString(ss.str()) << std::endl;
            }
        }

        // Step 4: Simulate memory allocation with RAII
        LOG_INFO("\n[4] Simulating VirtualAllocEx for new image");
        std::wcout << L"\n[4] Simulating VirtualAllocEx for new image..." << std::endl;
        std::wcout << L"    (This would allocate memory for malicious payload)" << std::endl;
        
        SIZE_T imageSize = 0x10000; // Example size
        MemoryGuard remoteImage = AllocateMemoryGuard(hProcess.get(), imageSize, PAGE_EXECUTE_READWRITE);

        if (remoteImage) {
            std::stringstream ss;
            ss << "[+] Memory allocated at: 0x" << std::hex 
               << (DWORD_PTR)remoteImage.get() << std::dec;
            LOG_INFO(ss.str());
            std::wcout << EDR::StringToWString(ss.str()) << std::endl;
        } else {
            LOG_WARN("Memory allocation simulation failed (expected for demonstration)");
        }

        // Step 5: Demonstrate WriteProcessMemory
        LOG_INFO("\n[5] Demonstrating WriteProcessMemory");
        std::wcout << L"\n[5] Demonstrating WriteProcessMemory..." << std::endl;
        std::wcout << L"    (This would write malicious code to process memory)" << std::endl;
        std::wcout << L"    API: WriteProcessMemory()" << std::endl;

        // Step 6: Demonstrate SetThreadContext
        LOG_INFO("\n[6] Demonstrating SetThreadContext");
        std::wcout << L"\n[6] Demonstrating SetThreadContext..." << std::endl;
        std::wcout << L"    (This would modify entry point to malicious code)" << std::endl;
        std::wcout << L"    API: SetThreadContext()" << std::endl;

        // Step 7: Explain ResumeThread
        LOG_INFO("\n[7] ResumeThread explanation");
        std::wcout << L"\n[7] ResumeThread would execute the hollowed process..." << std::endl;
        std::wcout << L"    (Not executing to prevent actual code injection)" << std::endl;

        // Cleanup (automatic via RAII, but we terminate the process)
        LOG_INFO("\n[*] Cleaning up test process");
        std::wcout << L"\n[*] Cleaning up test process..." << std::endl;
        
        if (!TerminateProcess(hProcess.get(), 0)) {
            LOG_WARN("Failed to terminate test process");
        }

        LOG_INFO("\n[+] Test completed successfully!");
        std::wcout << L"\n[+] Test completed!" << std::endl;
        
        std::wcout << L"\nEDR Detection Points:" << std::endl;
        std::wcout << L"  - CreateProcess with CREATE_SUSPENDED flag" << std::endl;
        std::wcout << L"  - NtUnmapViewOfSection API call" << std::endl;
        std::wcout << L"  - VirtualAllocEx with PAGE_EXECUTE_READWRITE" << std::endl;
        std::wcout << L"  - WriteProcessMemory to suspended process" << std::endl;
        std::wcout << L"  - SetThreadContext modification" << std::endl;
        std::wcout << L"  - ResumeThread on modified process" << std::endl;

        LOG_INFO("=== Process Hollowing Test Completed Successfully ===");

    } catch (const Exception& e) {
        LOG_ERROR(std::string("Process hollowing test failed: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] " << EDR::StringToWString(e.what()) << std::endl;
        std::wcerr << L"Error Code: " << static_cast<int>(e.code()) << std::endl;
        throw;
        
    } catch (const std::exception& e) {
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] Unexpected: " 
                   << EDR::StringToWString(e.what()) << std::endl;
        throw;
    }
}

int main() {
    // Initialize logger
    try {
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.EnableConsole(false);  // Avoid duplicate console output
        logger.SetOutputFile("process_hollowing.log");
        
        // Run the test
        SimulateProcessHollowing();
        return 0;
        
    } catch (const Exception& e) {
        std::wcerr << L"[ERROR] Test failed with code: " 
                   << static_cast<int>(e.code()) << std::endl;
        return 1;
        
    } catch (const std::exception& e) {
        std::wcerr << L"[ERROR] Unexpected error occurred" << std::endl;
        return 1;
        
    } catch (...) {
        std::wcerr << L"[ERROR] Unknown error occurred" << std::endl;
        return 1;
    }
}
