﻿/*
 * APC Queue Injection Test - EDR Detection Test (Enhanced Version)
 * 
 * 목적: Asynchronous Procedure Call을 이용한 코드 실행 테스트
 * Purpose: Test EDR's ability to detect APC injection technique
 * 
 * 탐지 포인트 (Detection Points):
 * - OpenProcess with specific access rights
 * - OpenThread to get thread handle
 * - VirtualAllocEx for shellcode allocation
 * - WriteProcessMemory to write shellcode
 * - QueueUserAPC to queue malicious APC
 * 
 * Enhancements:
 * - error_handling.hpp integration
 * - RAII pattern for resource management
 * - Structured error handling
 * - logger.hpp integration
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include "../../include/error_handling.hpp"
#include "../../include/logger.hpp"

using namespace EDR;

// Enumerate threads of a process
DWORD GetThreadId(DWORD processId) {
    LOG_INFO("Enumerating threads for PID: " + std::to_string(processId));
    
    HandleGuard hSnapshot(CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0));
    if (!hSnapshot) {
        throw Exception(ErrorCode::SYSTEM_CALL_FAILED, 
                       "Failed to create thread snapshot",
                       "CreateToolhelp32Snapshot", __FILE__, __LINE__);
    }

    THREADENTRY32 te;
    te.dwSize = sizeof(THREADENTRY32);

    if (Thread32First(hSnapshot.get(), &te)) {
        do {
            if (te.th32OwnerProcessID == processId) {
                LOG_INFO("Thread found with TID: " + std::to_string(te.th32ThreadID));
                return te.th32ThreadID;
            }
        } while (Thread32Next(hSnapshot.get(), &te));
    }

    throw Exception(ErrorCode::PROCESS_NOT_FOUND, 
                   "No threads found for process",
                   "GetThreadId", __FILE__, __LINE__);
}

void SimulateApcInjection() {
    try {
        LOG_INFO("=== APC Injection Test Started ===");
        
        std::wcout << L"==================================================" << std::endl;
        std::wcout << L"    EDR Test: APC Queue Injection Technique" << std::endl;
        std::wcout << L"    Enhanced with Error Handling & Logging" << std::endl;
        std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
        std::wcout << L"==================================================" << std::endl;
        std::wcout << std::endl;

        // Step 1: Create target process
        LOG_INFO("[1] Creating target process (notepad.exe)");
        std::wcout << L"[1] Creating target process (notepad.exe)..." << std::endl;
        
        STARTUPINFOW si = { sizeof(si) };
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        ZeroMemory(&pi, sizeof(pi));

        if (!CreateProcessW(
            L"C:\\Windows\\System32\\notepad.exe",
            NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            throw Exception(ErrorCode::PROCESS_NOT_FOUND, 
                           "Failed to create target process",
                           "CreateProcessW", __FILE__, __LINE__);
        }

        // Use RAII for process/thread handles
        HandleGuard hProcess(pi.hProcess);
        HandleGuard hMainThread(pi.hThread);

        LOG_INFO("[+] Process created successfully");
        LOG_INFO("PID: " + std::to_string(pi.dwProcessId));
        
        std::wcout << L"[+] Process created" << std::endl;
        std::wcout << L"    PID: " << pi.dwProcessId << std::endl;

        Sleep(1000); // Let process initialize

        // Step 2: Get thread handle
        LOG_INFO("\n[2] Getting thread ID");
        std::wcout << L"\n[2] Getting thread ID..." << std::endl;
        
        DWORD threadId = GetThreadId(pi.dwProcessId);
        
        LOG_INFO("[+] Thread ID: " + std::to_string(threadId));
        std::wcout << L"[+] Thread ID: " << threadId << std::endl;

        // Step 3: Open thread handle with RAII
        LOG_INFO("\n[3] Opening thread handle");
        std::wcout << L"\n[3] Opening thread handle..." << std::endl;
        
        HandleGuard hThread(OpenThread(THREAD_SET_CONTEXT, FALSE, threadId));
        if (!hThread) {
            throw Exception(ErrorCode::THREAD_CREATION_FAILED, 
                           "Failed to open thread",
                           "OpenThread", __FILE__, __LINE__);
        }

        LOG_INFO("[+] Thread handle obtained");
        std::wcout << L"[+] Thread handle obtained" << std::endl;

        // Step 4: Allocate memory for shellcode with RAII
        LOG_INFO("\n[4] Allocating memory in target process");
        std::wcout << L"\n[4] Allocating memory in target process..." << std::endl;
        
        // Example shellcode (non-functional, for demonstration)
        unsigned char shellcode[] = {
            0x90, 0x90, 0x90, 0x90,  // NOP sled
            0xC3                      // RET
        };
        SIZE_T shellcodeSize = sizeof(shellcode);

        MemoryGuard remoteMemory = AllocateMemoryGuard(hProcess.get(), shellcodeSize, PAGE_EXECUTE_READWRITE);
        if (!remoteMemory) {
            throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED, 
                           "Failed to allocate memory in target process",
                           "VirtualAllocEx", __FILE__, __LINE__);
        }

        std::stringstream ss;
        ss << "[+] Memory allocated at: 0x" << std::hex 
           << (DWORD_PTR)remoteMemory.get() << std::dec;
        LOG_INFO(ss.str());
        std::wcout << EDR::StringToWString(ss.str()) << std::endl;

        // Step 5: Write shellcode
        LOG_INFO("\n[5] Writing shellcode to target process");
        std::wcout << L"\n[5] Writing shellcode to target process..." << std::endl;
        
        if (!WriteProcessMemory(hProcess.get(), remoteMemory.get(), 
                               shellcode, shellcodeSize, NULL)) {
            throw Exception(ErrorCode::MEMORY_WRITE_FAILED, 
                           "Failed to write shellcode to target process",
                           "WriteProcessMemory", __FILE__, __LINE__);
        }

        LOG_INFO("[+] Shellcode written successfully");
        std::wcout << L"[+] Shellcode written" << std::endl;

        // Step 6: Demonstrate QueueUserAPC
        LOG_INFO("\n[6] Demonstrating QueueUserAPC");
        std::wcout << L"\n[6] Demonstrating QueueUserAPC..." << std::endl;
        std::wcout << L"    (This would queue the shellcode for execution)" << std::endl;
        std::wcout << L"    API: QueueUserAPC((PAPCFUNC)shellcode_addr, hThread, 0)" << std::endl;
        
        // Log the addresses that would be used
        ss.str("");
        ss << "    Shellcode address: 0x" << std::hex << remoteMemory.get() << std::dec;
        LOG_INFO(ss.str());
        std::wcout << EDR::StringToWString(ss.str()) << std::endl;
        
        // Note: Not actually queuing APC to avoid execution
        LOG_INFO("[+] APC queue simulation complete (not executed for safety)");
        std::wcout << L"[+] APC queue simulation complete" << std::endl;

        // Cleanup - terminate process before handles are released
        LOG_INFO("\n[*] Cleaning up test process");
        std::wcout << L"\n[*] Cleaning up..." << std::endl;
        
        if (!TerminateProcess(hProcess.get(), 0)) {
            LOG_WARN("Failed to terminate test process");
        }

        LOG_INFO("\n[+] Test completed successfully!");
        std::wcout << L"\n[+] Test completed!" << std::endl;
        
        std::wcout << L"\nEDR Detection Points:" << std::endl;
        std::wcout << L"  - OpenProcess with write/execute permissions" << std::endl;
        std::wcout << L"  - OpenThread with THREAD_SET_CONTEXT" << std::endl;
        std::wcout << L"  - VirtualAllocEx with PAGE_EXECUTE_READWRITE" << std::endl;
        std::wcout << L"  - WriteProcessMemory to executable memory" << std::endl;
        std::wcout << L"  - QueueUserAPC call to inject code" << std::endl;
        std::wcout << L"  - Unusual APC queue behavior" << std::endl;

        LOG_INFO("=== APC Injection Test Completed Successfully ===");

    } catch (const Exception& e) {
        LOG_ERROR(std::string("APC injection test failed: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] " << EDR::StringToWString(e.what()) << std::endl;
        std::wcerr << L"Error Code: " << static_cast<int>(e.code()) << std::endl;
        throw;
        
    } catch (const std::exception& e) {
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        std::wcerr << L"\n[FATAL ERROR] Unexpected: " 
                   << EDR::StringToWString(e.what()) << std::endl;
        throw;
    }
}

int main() {
    // Initialize logger
    try {
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.EnableConsole(false);  // Avoid duplicate console output
        logger.SetOutputFile("apc_injection.log");
        
        // Run the test
        SimulateApcInjection();
        return 0;
        
    } catch (const Exception& e) {
        std::wcerr << L"[ERROR] Test failed with code: " 
                   << static_cast<int>(e.code()) << std::endl;
        return 1;
        
    } catch (const std::exception& e) {
        std::wcerr << L"[ERROR] Unexpected error occurred" << std::endl;
        return 1;
        
    } catch (...) {
        std::wcerr << L"[ERROR] Unknown error occurred" << std::endl;
        return 1;
    }
}
