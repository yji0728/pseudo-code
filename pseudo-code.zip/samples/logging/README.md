# 통합 로깅 시스템 (Unified Logging System)

## 개요
EDR Testing Tools를 위한 구조화된 로깅 프레임워크입니다.

## 주요 기능

### 1. 다중 로그 레벨
- **DEBUG**: 상세한 디버깅 정보
- **INFO**: 일반 정보 메시지
- **WARN**: 경고 메시지
- **ERROR**: 오류 메시지
- **CRITICAL**: 심각한 오류 메시지

### 2. 출력 옵션
- 콘솔 출력 (색상 지원)
- 파일 출력
- JSON 형식 지원

### 3. 고급 기능
- 타임스탬프 자동 추가
- 스레드 ID 추적
- 소스 파일 및 라인 번호
- 로그 파일 순환(Rotation)
- 스레드 안전성(Thread-safe)

## 사용법

### 기본 사용
```cpp
#include "../../include/logger.hpp"

// 간단한 로깅
LOG_INFO("Application started");
LOG_WARN("Low memory warning");
LOG_ERROR("Failed to open file");
LOG_CRITICAL("System crash imminent");
```

### 설정
```cpp
// 로그 파일 설정
Logger::Instance().SetOutputFile("logs/app.log");

// 최소 로그 레벨 설정
Logger::Instance().SetLevel(Logger::Level::WARN);

// JSON 형식 활성화
Logger::Instance().EnableJSON(true);

// 로그 순환 설정
Logger::Instance().SetMaxFileSize(10);  // 10MB
Logger::Instance().SetMaxFiles(5);      // 최대 5개 파일
```

### 구조화된 이벤트 로깅
```cpp
// 이벤트 로깅 (자동으로 JSON 형식)
LOG_EVENT("process_injection", Logger::Level::INFO,
    {"technique", "T1055.001"},
    {"target_process", "notepad.exe"},
    {"target_pid", "1234"},
    {"status", "success"}
);
```

## 출력 형식

### 텍스트 형식
```
[2025-10-14 15:30:45.123] [INFO] [TID:1234] [main.cpp:42] Application started
[2025-10-14 15:30:45.456] [ERROR] [TID:1234] [main.cpp:55] Failed to open file
```

### JSON 형식
```json
{"timestamp":"2025-10-14 15:30:45.123","level":"INFO","thread_id":1234,"file":"main.cpp","line":42,"message":"Application started"}
```

### 구조화된 이벤트 (JSON)
```json
{
  "timestamp":"2025-10-14 15:30:45.123",
  "level":"INFO",
  "thread_id":1234,
  "event_type":"process_injection",
  "attributes":{
    "technique":"T1055.001",
    "target_process":"notepad.exe",
    "target_pid":"1234",
    "status":"success"
  }
}
```

## 데모 프로그램

### 컴파일
```powershell
# Visual Studio 환경에서
cl /EHsc /std:c++17 logging_demo.cpp /Fe:logging_demo.exe
```

### 실행 예제
```powershell
# 모든 데모 실행
.\logging_demo.exe

# 특정 데모만 실행
.\logging_demo.exe --basic        # 기본 로깅
.\logging_demo.exe --filter       # 레벨 필터링
.\logging_demo.exe --file         # 파일 출력
.\logging_demo.exe --json         # JSON 형식
.\logging_demo.exe --structured   # 구조화된 이벤트
.\logging_demo.exe --multithread  # 멀티스레드
.\logging_demo.exe --rotation     # 로그 순환
.\logging_demo.exe --scenario     # 실제 시나리오
```

## 로그 순환

파일 크기가 설정된 최대 크기를 초과하면 자동으로 순환됩니다:

```
logs/
├── app.log        (현재 로그)
├── app.log.1      (이전 로그)
├── app.log.2
├── app.log.3
└── app.log.4
```

## 성능 고려사항

1. **파일 I/O**: 파일 출력은 버퍼링되며 각 로그 후 플러시됩니다
2. **스레드 안전성**: 뮤텍스로 보호되어 멀티스레드 환경에서 안전
3. **최소 로그 레벨**: 불필요한 로그는 조기에 필터링되어 오버헤드 최소화
4. **JSON 파싱**: JSON 형식은 약간의 추가 오버헤드가 있음

## 장점

### ✅ 구조화된 로깅
- 일관된 로그 형식
- 자동 메타데이터 추가
- 파싱 및 분석 용이

### ✅ 유연한 출력
- 다중 출력 대상
- 동적 설정 변경
- 형식 선택 가능

### ✅ 프로덕션 준비
- 스레드 안전
- 로그 순환 지원
- 에러 처리

### ✅ 디버깅 지원
- 소스 위치 추적
- 스레드 ID 추적
- 레벨별 색상 표시

## 통합 가이드

### 기존 코드에 통합
```cpp
// 기존 코드
std::cout << "Process found: " << pid << std::endl;

// 로거 사용
LOG_INFO("Process found: " + std::to_string(pid));

// 구조화된 로깅
LOG_EVENT("process_found", Logger::Level::INFO,
    {"process_name", processName},
    {"pid", std::to_string(pid)}
);
```

### EDR 탐지 이벤트 로깅
```cpp
// 공격 기법 시작
LOG_EVENT("technique_start", Logger::Level::INFO,
    {"technique", "T1055.001"},
    {"target", "notepad.exe"}
);

// 탐지 포인트
LOG_EVENT("detection_point", Logger::Level::WARN,
    {"api", "VirtualAllocEx"},
    {"address", std::to_string(addr)},
    {"size", std::to_string(size)}
);

// EDR 탐지
LOG_EVENT("edr_alert", Logger::Level::CRITICAL,
    {"detection_method", "Suspicious API sequence"},
    {"confidence", "high"}
);
```

## 모범 사례

1. **적절한 로그 레벨 사용**
   - DEBUG: 개발 중 상세 정보
   - INFO: 정상 작동 정보
   - WARN: 주의가 필요한 상황
   - ERROR: 오류 발생
   - CRITICAL: 시스템 장애

2. **구조화된 데이터 사용**
   - 가능하면 `LOG_EVENT` 사용
   - 일관된 키 이름 사용
   - MITRE ATT&CK 기법 ID 포함

3. **민감 정보 주의**
   - 비밀번호, 토큰 등 로깅 금지
   - 필요시 마스킹 처리

4. **성능 고려**
   - 프로덕션에서는 INFO 레벨 이상 사용
   - 대용량 데이터는 요약해서 로깅

## 참고 자료
- [Structured Logging Best Practices](https://www.loggly.com/ultimate-guide/structured-logging/)
- [MITRE ATT&CK Framework](https://attack.mitre.org/)
- [C++ Logging Libraries Comparison](https://github.com/gabime/spdlog)
