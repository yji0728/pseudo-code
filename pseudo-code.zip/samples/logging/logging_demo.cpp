/*
 * EDR Testing Tools - Logging System Demo
 * 
 * 목적: 통합 로깅 시스템 사용 예제
 * Purpose: Demonstrate unified logging system usage
 * 
 * 기능 (Features):
 * 1. 다양한 로그 레벨 데모
 * 2. 파일 출력 데모
 * 3. JSON 형식 로깅 데모
 * 4. 구조화된 이벤트 로깅 데모
 * 5. 로그 순환(Rotation) 데모
 * 
 * MITRE ATT&CK: N/A (Infrastructure/Utility)
 * 
 * 탐지 포인트 (Detection Points):
 * - 파일 생성 (로그 파일)
 * - 파일 쓰기 작업
 * 
 * 사용법:
 *   logging_demo.exe [옵션]
 *   옵션:
 *     --text     : 텍스트 형식 로깅 (기본값)
 *     --json     : JSON 형식 로깅
 *     --file     : 파일 출력 활성화
 *     --rotation : 로그 순환 테스트
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include "../../include/logger.hpp"

using namespace EDR;

// 기본 로깅 데모 / Basic logging demo
void DemoBasicLogging() {
    std::cout << "\n[*] Basic Logging Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    LOG_DEBUG("This is a debug message");
    LOG_INFO("This is an info message");
    LOG_WARN("This is a warning message");
    LOG_ERROR("This is an error message");
    LOG_CRITICAL("This is a critical message");
}

// 레벨 필터링 데모 / Level filtering demo
void DemoLevelFiltering() {
    std::cout << "\n[*] Level Filtering Demo (Minimum Level: WARN)" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().SetLevel(EDRLOG_WARN);

    LOG_DEBUG("This debug message will not appear");
    LOG_INFO("This info message will not appear");
    LOG_WARN("This warning message will appear");
    LOG_ERROR("This error message will appear");
    LOG_CRITICAL("This critical message will appear");

    // Reset to INFO
    Logger::Instance().SetLevel(EDRLOG_INFO);
}

// 파일 출력 데모 / File output demo
void DemoFileOutput() {
    std::cout << "\n[*] File Output Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().SetOutputFile("logs/edr_test.log");
    
    LOG_INFO("Starting file output test");
    LOG_INFO("Writing multiple log entries to file");
    LOG_WARN("Testing warning level");
    LOG_ERROR("Testing error level");
    
    std::cout << "[+] Log file created at: logs/edr_test.log" << std::endl;
}

// JSON 형식 로깅 데모 / JSON format logging demo
void DemoJSONLogging() {
    std::cout << "\n[*] JSON Format Logging Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().EnableJSON(true);
    Logger::Instance().SetOutputFile("logs/edr_test_json.log");

    LOG_INFO("This is a JSON formatted message");
    LOG_ERROR("Error message in JSON format");
    
    std::cout << "[+] JSON log file created at: logs/edr_test_json.log" << std::endl;

    Logger::Instance().EnableJSON(false);
}

// 구조화된 이벤트 로깅 데모 / Structured event logging demo
void DemoStructuredLogging() {
    std::cout << "\n[*] Structured Event Logging Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().EnableJSON(true);
    Logger::Instance().SetOutputFile("logs/edr_events.log");

    // Process injection event
    LOG_EVENT("process_injection", EDRLOG_INFO,
        {"technique", "T1055.001"},
        {"target_process", "notepad.exe"},
        {"target_pid", "1234"},
        {"dll_path", "C:\\test\\malicious.dll"},
        {"status", "success"}
    );

    // Shellcode execution event
    LOG_EVENT("shellcode_execution", EDRLOG_WARN,
        {"technique", "T1055.002"},
        {"method", "CreateRemoteThread"},
        {"shellcode_size", "512"},
        {"status", "detected"}
    );

    // File modification event
    LOG_EVENT("file_modification", EDRLOG_ERROR,
        {"technique", "T1070.004"},
        {"file_path", "C:\\Windows\\System32\\config\\SAM"},
        {"operation", "delete"},
        {"status", "blocked"}
    );

    std::cout << "[+] Structured event log created at: logs/edr_events.log" << std::endl;

    Logger::Instance().EnableJSON(false);
}

// 멀티스레드 로깅 데모 / Multi-threaded logging demo
void DemoMultiThreadedLogging() {
    std::cout << "\n[*] Multi-threaded Logging Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().SetOutputFile("logs/edr_multithread.log");

    auto threadFunc = [](int threadId) {
        for (int i = 0; i < 5; i++) {
            LOG_INFO("Thread " + std::to_string(threadId) + 
                    " - Message " + std::to_string(i));
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    };

    std::thread t1(threadFunc, 1);
    std::thread t2(threadFunc, 2);
    std::thread t3(threadFunc, 3);

    t1.join();
    t2.join();
    t3.join();

    std::cout << "[+] Multi-threaded log created at: logs/edr_multithread.log" << std::endl;
}

// 로그 순환 데모 / Log rotation demo
void DemoLogRotation() {
    std::cout << "\n[*] Log Rotation Demo" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().SetOutputFile("logs/edr_rotation.log");
    Logger::Instance().SetMaxFileSize(1); // 1MB for testing
    Logger::Instance().SetMaxFiles(3);

    std::cout << "[*] Writing large amount of data to trigger rotation..." << std::endl;

    // Write enough data to trigger rotation
    std::string largeMessage(10000, 'X'); // 10KB message
    for (int i = 0; i < 150; i++) {
        LOG_INFO("Large message " + std::to_string(i) + ": " + largeMessage);
        
        if (i % 30 == 0) {
            std::cout << "[*] Written " << i << " messages..." << std::endl;
        }
    }

    std::cout << "[+] Log rotation completed. Check logs/edr_rotation.log.*" << std::endl;
}

// 실제 시나리오 시뮬레이션 / Real scenario simulation
void DemoRealScenario() {
    std::cout << "\n[*] Real Scenario Simulation: DLL Injection" << std::endl;
    std::cout << "====================================\n" << std::endl;

    Logger::Instance().EnableJSON(true);
    Logger::Instance().SetOutputFile("logs/edr_scenario.log");

    // Start of operation
    LOG_EVENT("operation_start", EDRLOG_INFO,
        {"operation_id", "OP-2025-001"},
        {"technique", "DLL Injection"},
        {"operator", "analyst01"}
    );

    // Target process search
    LOG_INFO("Searching for target process: notepad.exe");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    LOG_EVENT("process_found", EDRLOG_INFO,
        {"process_name", "notepad.exe"},
        {"pid", "5432"},
        {"parent_pid", "1234"}
    );

    // Memory allocation attempt
    LOG_INFO("Allocating memory in target process");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    LOG_EVENT("memory_allocated", EDRLOG_INFO,
        {"base_address", "0x12340000"},
        {"size", "4096"},
        {"protection", "PAGE_READWRITE"}
    );

    // DLL path writing
    LOG_INFO("Writing DLL path to allocated memory");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    // CreateRemoteThread attempt
    LOG_INFO("Creating remote thread");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    // EDR detection
    LOG_EVENT("edr_detection", EDRLOG_WARN,
        {"detection_method", "Suspicious API call"},
        {"api_name", "CreateRemoteThread"},
        {"confidence", "high"},
        {"action", "alert_generated"}
    );

    LOG_CRITICAL("Operation detected by EDR!");

    // Operation end
    LOG_EVENT("operation_end", EDRLOG_INFO,
        {"operation_id", "OP-2025-001"},
        {"status", "detected"},
        {"duration_ms", "450"}
    );

    std::cout << "[+] Scenario log created at: logs/edr_scenario.log" << std::endl;

    Logger::Instance().EnableJSON(false);
}

// Print usage
void PrintUsage() {
    std::cout << "Usage: logging_demo.exe [options]" << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  --basic      : Basic logging demo (default)" << std::endl;
    std::cout << "  --filter     : Level filtering demo" << std::endl;
    std::cout << "  --file       : File output demo" << std::endl;
    std::cout << "  --json       : JSON format demo" << std::endl;
    std::cout << "  --structured : Structured event logging demo" << std::endl;
    std::cout << "  --multithread: Multi-threaded logging demo" << std::endl;
    std::cout << "  --rotation   : Log rotation demo" << std::endl;
    std::cout << "  --scenario   : Real scenario simulation" << std::endl;
    std::cout << "  --all        : Run all demos" << std::endl;
    std::cout << "  --help       : Show this help message" << std::endl;
}

int main(int argc, char* argv[]) {
    std::cout << "========================================" << std::endl;
    std::cout << "  EDR Testing Tools - Logging Demo" << std::endl;
    std::cout << "========================================" << std::endl;

    // Create logs directory if it doesn't exist
    CreateDirectoryA("logs", NULL);

    // Parse arguments
    bool runAll = (argc == 1); // No arguments = run all
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "--help" || arg == "-h") {
            PrintUsage();
            return 0;
        }
        else if (arg == "--all") {
            runAll = true;
            break;
        }
    }

    // Run demos
    if (runAll) {
        DemoBasicLogging();
        DemoLevelFiltering();
        DemoFileOutput();
        DemoJSONLogging();
        DemoStructuredLogging();
        DemoMultiThreadedLogging();
        DemoLogRotation();
        DemoRealScenario();
    }
    else {
        for (int i = 1; i < argc; i++) {
            std::string arg = argv[i];
            
            if (arg == "--basic") {
                DemoBasicLogging();
            }
            else if (arg == "--filter") {
                DemoLevelFiltering();
            }
            else if (arg == "--file") {
                DemoFileOutput();
            }
            else if (arg == "--json") {
                DemoJSONLogging();
            }
            else if (arg == "--structured") {
                DemoStructuredLogging();
            }
            else if (arg == "--multithread") {
                DemoMultiThreadedLogging();
            }
            else if (arg == "--rotation") {
                DemoLogRotation();
            }
            else if (arg == "--scenario") {
                DemoRealScenario();
            }
            else {
                std::cout << "Unknown option: " << arg << std::endl;
                PrintUsage();
                return 1;
            }
        }
    }

    std::cout << "\n========================================" << std::endl;
    std::cout << "  All demos completed successfully!" << std::endl;
    std::cout << "========================================" << std::endl;

    return 0;
}
