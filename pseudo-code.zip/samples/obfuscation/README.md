# Obfuscation Techniques (난독화 기법)

## MITRE ATT&CK
**Technique ID**: T1027  
**Tactic**: Defense Evasion  
**Platform**: Windows, Linux, macOS

---

## 개요 (Overview)

코드 난독화는 악성코드가 정적 분석과 탐지를 회피하기 위해 사용하는 기법입니다. EDR과 보안 제품이 이러한 난독화 기법을 탐지할 수 있는지 테스트합니다.

Code obfuscation is a technique used by malware to evade static analysis and detection. This tests whether EDR and security products can detect these obfuscation techniques.

---

## 난독화 기법 분류 (Obfuscation Categories)

### 1. 문자열 난독화 (String Obfuscation)
- XOR 암호화
- Base64 인코딩
- 문자열 분할 및 재조합
- 스택 기반 문자열 구성

### 2. API 난독화 (API Obfuscation)
- API 해싱
- 동적 API 해결
- IAT(Import Address Table) 우회
- 수동 모듈 로딩

### 3. 제어 흐름 난독화 (Control Flow Obfuscation)
- 불필요한 점프 삽입
- 조건부 분기 복잡화
- Opaque 상수 사용
- 코드 평탄화 (Flattening)

---

## 샘플 코드 (Sample Code)

### 1. string_encryption.cpp
문자열 암호화 기법을 시뮬레이션합니다.

**기능**:
- XOR 기반 문자열 암호화/복호화
- 런타임 문자열 복호화
- 난독화된 문자열 탐지 테스트

### 2. api_hashing.cpp
API 호출을 난독화하는 해싱 기법을 구현합니다.

**기능**:
- API 이름 해싱
- 동적 API 주소 해결
- IAT 우회 기법

### 3. control_flow_obfuscation.cpp
제어 흐름을 복잡하게 만드는 기법을 시뮬레이션합니다.

**기능**:
- 불필요한 분기 삽입
- 더미 코드 추가
- 제어 흐름 분석 방해

---

## 탐지 포인트 (Detection Points)

### 1. 정적 분석 (Static Analysis)
- ✅ 높은 엔트로피 섹션 탐지
- ✅ 수상한 문자열 패턴
- ✅ 암호화된 데이터 블록
- ✅ 비정상적인 코드 구조

### 2. 동적 분석 (Dynamic Analysis)
- ✅ 런타임 복호화 행위
- ✅ 메모리 내 문자열 생성
- ✅ 동적 API 해결
- ✅ 자가 수정 코드

### 3. 행위 분석 (Behavioral Analysis)
- ✅ GetProcAddress 과도한 호출
- ✅ LoadLibrary 동적 호출
- ✅ VirtualProtect로 코드 섹션 변경
- ✅ 비정상적인 실행 패턴

---

## 사용 방법 (Usage)

### 컴파일 (Compilation)
```powershell
cd samples\obfuscation

# 문자열 암호화 테스트
cl /EHsc /W4 string_encryption.cpp /Fe:string_encryption.exe

# API 해싱 테스트
cl /EHsc /W4 api_hashing.cpp /Fe:api_hashing.exe

# 제어 흐름 난독화 테스트
cl /EHsc /W4 control_flow_obfuscation.cpp /Fe:control_flow_obfuscation.exe
```

### 실행 (Execution)
```powershell
# 문자열 암호화 테스트
.\string_encryption.exe

# API 해싱 테스트
.\api_hashing.exe

# 제어 흐름 난독화 테스트
.\control_flow_obfuscation.exe
```

---

## 예상 EDR 동작 (Expected EDR Behavior)

### 1. 문자열 복호화 탐지
```
[ALERT] Runtime string decryption detected
Process: test.exe
Method: XOR decryption loop
Entropy: High (7.8/8.0)
```

### 2. API 해싱 탐지
```
[ALERT] Suspicious API resolution pattern
Process: test.exe
API: GetProcAddress called 50+ times
Pattern: Hash-based lookup
```

### 3. 자가 수정 코드 탐지
```
[ALERT] Self-modifying code detected
Process: test.exe
API: VirtualProtect on .text section
Protection: Changed to PAGE_EXECUTE_READWRITE
```

---

## 고급 난독화 기법 (Advanced Techniques)

### 1. 다형성 코드 (Polymorphic Code)
실행할 때마다 코드 형태가 변경되지만 기능은 동일

### 2. 메타모픽 코드 (Metamorphic Code)
실행할 때마다 코드 구조 자체가 완전히 변경

### 3. 패커/크립터 (Packers/Crypters)
전체 실행 파일을 압축 또는 암호화

### 4. 가상화 기반 난독화
커스텀 가상 머신에서 코드 실행

---

## 방어 전략 (Defense Strategies)

### 1. 정적 분석 강화
- 엔트로피 분석
- 패턴 매칭
- YARA 룰 적용
- 시그니처 기반 탐지

### 2. 동적 분석
- 샌드박스 실행
- API 모니터링
- 메모리 스캐닝
- 행위 분석

### 3. 머신러닝
- 난독화 패턴 학습
- 이상 탐지
- 분류 모델 적용

---

## 난독화 탐지 도구 (Detection Tools)

### 상용 도구
- **IDA Pro**: 디스어셈블러 및 디컴파일러
- **x64dbg**: 동적 분석 디버거
- **PE-bear**: PE 파일 분석
- **Detect It Easy**: 패커/난독화 탐지

### 오픈소스 도구
- **Ghidra**: NSA의 리버스 엔지니어링 도구
- **Radare2**: 리버스 엔지니어링 프레임워크
- **YARA**: 패턴 매칭 도구
- **PEiD**: 패커 식별 도구

---

## 실제 사례 (Real-world Examples)

### APT 그룹의 난독화 사용
- **APT29 (Cozy Bear)**: 다층 암호화 및 스테가노그래피
- **APT28 (Fancy Bear)**: 다형성 코드 사용
- **Lazarus Group**: 커스텀 패커 및 난독화 도구

### 악성코드 패밀리
- **Emotet**: 문자열 암호화 및 API 해싱
- **TrickBot**: 제어 흐름 난독화
- **Ryuk**: 다단계 복호화 프로세스

---

## 참고 자료 (References)

1. [MITRE ATT&CK - T1027](https://attack.mitre.org/techniques/T1027/)
2. [OWASP - Code Obfuscation](https://owasp.org/www-community/controls/Code_Obfuscation)
3. [Practical Malware Analysis Book](https://nostarch.com/malware)

---

## 경고 (Warning)

⚠️ **이 코드는 교육 및 EDR 테스트 목적으로만 사용하세요.**

⚠️ **실제 악성코드 개발에 사용하지 마세요.**

⚠️ **통제된 환경에서만 실행하세요.**

---

**Last Updated**: 2025-10-14
**Version**: 1.0
