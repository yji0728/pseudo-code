/*
 * String Encryption Test - EDR Detection Test
 * 
 * 목적: 문자열 암호화/난독화 기법을 시뮬레이션하여 EDR 탐지 능력 테스트
 * Purpose: Test EDR's ability to detect string encryption/obfuscation techniques
 * 
 * MITRE ATT&CK: T1027 (Obfuscated Files or Information)
 * Sub-technique: T1027.007 (Dynamic API Resolution)
 * 
 * 탐지 포인트 (Detection Points):
 * - High entropy data sections
 * - Runtime string decryption
 * - XOR/Caesar cipher patterns
 * - Self-modifying code for decryption
 * - Suspicious memory writes
 * 
 * WARNING: For testing purposes only in isolated environments
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

// Simple XOR encryption/decryption
std::string XorEncryptDecrypt(const std::string& data, char key) {
    std::string result = data;
    for (size_t i = 0; i < result.size(); i++) {
        result[i] ^= key;
    }
    return result;
}

// Multi-byte XOR with key
std::string MultiByteXOR(const std::string& data, const std::string& key) {
    std::string result = data;
    for (size_t i = 0; i < result.size(); i++) {
        result[i] ^= key[i % key.length()];
    }
    return result;
}

// Caesar cipher
std::string CaesarCipher(const std::string& data, int shift) {
    std::string result = data;
    for (size_t i = 0; i < result.size(); i++) {
        if (isalpha(result[i])) {
            char base = isupper(result[i]) ? 'A' : 'a';
            result[i] = (result[i] - base + shift) % 26 + base;
        }
    }
    return result;
}

// Calculate entropy of data
double CalculateEntropy(const std::string& data) {
    int frequency[256] = { 0 };
    for (char c : data) {
        frequency[(unsigned char)c]++;
    }
    
    double entropy = 0.0;
    for (int i = 0; i < 256; i++) {
        if (frequency[i] > 0) {
            double prob = (double)frequency[i] / data.length();
            entropy -= prob * log2(prob);
        }
    }
    return entropy;
}

// Test 1: Simple XOR encryption
void TestSimpleXOREncryption() {
    std::wcout << L"\n[Test 1] Simple XOR String Encryption" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    // Original strings that would be detected
    std::string sensitive1 = "CreateRemoteThread";
    std::string sensitive2 = "VirtualAllocEx";
    std::string sensitive3 = "WriteProcessMemory";
    
    char key = 0x42;
    
    std::wcout << L"[*] Encrypting sensitive API names..." << std::endl;
    std::wcout << L"    XOR Key: 0x" << std::hex << (int)key << std::dec << std::endl;
    
    // Encrypt strings
    auto encrypted1 = XorEncryptDecrypt(sensitive1, key);
    auto encrypted2 = XorEncryptDecrypt(sensitive2, key);
    auto encrypted3 = XorEncryptDecrypt(sensitive3, key);
    
    std::wcout << L"\n[*] Encrypted strings (hex):" << std::endl;
    std::wcout << L"    String 1: ";
    for (unsigned char c : encrypted1) {
        wprintf(L"%02X ", c);
    }
    std::wcout << std::endl;
    
    // Calculate entropy
    double entropy = CalculateEntropy(encrypted1);
    std::wcout << L"\n[*] Data Entropy: " << entropy << L"/8.0" << std::endl;
    std::wcout << L"    [!] High entropy (>7.0) indicates encryption/compression" << std::endl;
    
    // Simulate runtime decryption
    std::wcout << L"\n[*] Runtime decryption (what EDR should detect):" << std::endl;
    auto decrypted1 = XorEncryptDecrypt(encrypted1, key);
    auto decrypted2 = XorEncryptDecrypt(encrypted2, key);
    auto decrypted3 = XorEncryptDecrypt(encrypted3, key);
    
    std::wcout << L"    Decrypted: " << decrypted1.c_str() << std::endl;
    std::wcout << L"    Decrypted: " << decrypted2.c_str() << std::endl;
    std::wcout << L"    Decrypted: " << decrypted3.c_str() << std::endl;
    
    std::wcout << L"\n[!] EDR Detection Points:" << std::endl;
    std::wcout << L"    - Monitor for XOR operations in loops" << std::endl;
    std::wcout << L"    - Detect strings appearing in memory at runtime" << std::endl;
    std::wcout << L"    - Scan for high-entropy data sections" << std::endl;
    std::wcout << L"    - Alert on suspicious string patterns" << std::endl;
}

// Test 2: Multi-byte XOR encryption
void TestMultiByteXOREncryption() {
    std::wcout << L"\n[Test 2] Multi-byte XOR Encryption" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::string plaintext = "This is a hidden payload";
    std::string key = "SECRET_KEY_2025";
    
    std::wcout << L"[*] Original text: " << plaintext.c_str() << std::endl;
    std::wcout << L"[*] XOR Key: " << key.c_str() << std::endl;
    
    // Encrypt
    auto encrypted = MultiByteXOR(plaintext, key);
    
    std::wcout << L"\n[*] Encrypted (hex): ";
    for (unsigned char c : encrypted) {
        wprintf(L"%02X ", c);
    }
    std::wcout << std::endl;
    
    // Entropy analysis
    double plainEntropy = CalculateEntropy(plaintext);
    double encryptedEntropy = CalculateEntropy(encrypted);
    
    std::wcout << L"\n[*] Entropy Comparison:" << std::endl;
    std::wcout << L"    Plaintext: " << plainEntropy << std::endl;
    std::wcout << L"    Encrypted: " << encryptedEntropy << std::endl;
    std::wcout << L"    [!] Significant entropy increase indicates encryption" << std::endl;
    
    // Decrypt
    auto decrypted = MultiByteXOR(encrypted, key);
    std::wcout << L"\n[*] Decrypted: " << decrypted.c_str() << std::endl;
    
    std::wcout << L"\n[!] EDR Should Detect:" << std::endl;
    std::wcout << L"    - Repetitive XOR patterns" << std::endl;
    std::wcout << L"    - Key reuse in XOR operations" << std::endl;
    std::wcout << L"    - Memory regions with high entropy" << std::endl;
}

// Test 3: Stack string construction
void TestStackStringConstruction() {
    std::wcout << L"\n[Test 3] Stack-based String Construction" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Building string character-by-character on stack..." << std::endl;
    std::wcout << L"    (Common evasion technique)" << std::endl;
    
    // Instead of: const char* api = "LoadLibrary";
    // Build it dynamically:
    char api[20];
    api[0] = 'L';
    api[1] = 'o';
    api[2] = 'a';
    api[3] = 'd';
    api[4] = 'L';
    api[5] = 'i';
    api[6] = 'b';
    api[7] = 'r';
    api[8] = 'a';
    api[9] = 'r';
    api[10] = 'y';
    api[11] = '\0';
    
    std::wcout << L"\n[*] Constructed string: " << api << std::endl;
    std::wcout << L"    [!] No string visible in static analysis!" << std::endl;
    
    // Advanced: Calculate character values
    std::wcout << L"\n[*] Advanced: Arithmetic construction" << std::endl;
    char advanced[10];
    advanced[0] = 0x43 + 0x04;  // 'G'
    advanced[1] = 0x65;         // 'e'
    advanced[2] = 0x74;         // 't'
    advanced[3] = 0x50;         // 'P'
    advanced[4] = 0x72;         // 'r'
    advanced[5] = 0x6F;         // 'o'
    advanced[6] = 0x63;         // 'c'
    advanced[7] = '\0';
    
    std::wcout << L"    Constructed: " << advanced << std::endl;
    
    std::wcout << L"\n[!] EDR Detection:" << std::endl;
    std::wcout << L"    - Monitor stack operations building strings" << std::endl;
    std::wcout << L"    - Detect arithmetic operations forming ASCII" << std::endl;
    std::wcout << L"    - Behavioral analysis of string usage patterns" << std::endl;
}

// Test 4: String concatenation obfuscation
void TestStringConcatenation() {
    std::wcout << L"\n[Test 4] String Concatenation Obfuscation" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Splitting strings to avoid static detection..." << std::endl;
    
    // Instead of: "CreateRemoteThread"
    std::string part1 = "Create";
    std::string part2 = "Remote";
    std::string part3 = "Thread";
    
    std::string fullApi = part1 + part2 + part3;
    
    std::wcout << L"    Part 1: " << part1.c_str() << std::endl;
    std::wcout << L"    Part 2: " << part2.c_str() << std::endl;
    std::wcout << L"    Part 3: " << part3.c_str() << std::endl;
    std::wcout << L"    Combined: " << fullApi.c_str() << std::endl;
    
    // Advanced: Interleaved strings
    std::wcout << L"\n[*] Advanced: Interleaved construction" << std::endl;
    char interleaved[20];
    const char* s1 = "VraulAoc";
    const char* s2 = "itlleEx";
    
    for (int i = 0; i < 7; i++) {
        interleaved[i * 2] = s1[i];
        interleaved[i * 2 + 1] = s2[i];
    }
    interleaved[14] = '\0';
    
    std::wcout << L"    Result: " << interleaved << std::endl;
    std::wcout << L"    [!] Creates 'VirtualAllocEx' from two innocent strings" << std::endl;
    
    std::wcout << L"\n[!] EDR Should Monitor:" << std::endl;
    std::wcout << L"    - String concatenation patterns" << std::endl;
    std::wcout << L"    - Formation of suspicious API names" << std::endl;
    std::wcout << L"    - Runtime string assembly" << std::endl;
}

// Test 5: Base64-style encoding
void TestBase64StyleEncoding() {
    std::wcout << L"\n[Test 5] Base64-style Encoding" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::string original = "NtCreateThreadEx";
    
    std::wcout << L"[*] Original API: " << original.c_str() << std::endl;
    
    // Simple custom encoding (not real Base64, just demonstration)
    std::wcout << L"\n[*] Applying custom encoding..." << std::endl;
    std::wcout << L"    (Real malware uses Base64, custom alphabets, etc.)" << std::endl;
    
    // Custom encoding: rotate by 13 (ROT13)
    std::string encoded = original;
    for (char& c : encoded) {
        if (isalpha(c)) {
            char base = isupper(c) ? 'A' : 'a';
            c = (c - base + 13) % 26 + base;
        }
    }
    
    std::wcout << L"    Encoded: " << encoded.c_str() << std::endl;
    
    // Decode
    std::string decoded = encoded;
    for (char& c : decoded) {
        if (isalpha(c)) {
            char base = isupper(c) ? 'A' : 'a';
            c = (c - base + 13) % 26 + base;
        }
    }
    
    std::wcout << L"    Decoded: " << decoded.c_str() << std::endl;
    
    std::wcout << L"\n[!] EDR Detection:" << std::endl;
    std::wcout << L"    - Identify encoded strings in binary" << std::endl;
    std::wcout << L"    - Monitor decoding operations" << std::endl;
    std::wcout << L"    - Detect Base64/custom alphabet usage" << std::endl;
    std::wcout << L"    - Analyze decoded content in memory" << std::endl;
}

int main() {
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: String Encryption/Obfuscation" << std::endl;
    std::wcout << L"    MITRE ATT&CK: T1027" << std::endl;
    std::wcout << L"    WARNING: For testing purposes only!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    std::wcout << L"\n[*] This test demonstrates various string obfuscation" << std::endl;
    std::wcout << L"    techniques used by malware to evade detection." << std::endl;
    
    // Run tests
    TestSimpleXOREncryption();
    TestMultiByteXOREncryption();
    TestStackStringConstruction();
    TestStringConcatenation();
    TestBase64StyleEncoding();
    
    // Summary
    std::wcout << L"\n==================================================" << std::endl;
    std::wcout << L"    Test Summary" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"[+] All string obfuscation tests completed" << std::endl;
    std::wcout << L"\n[!] Key EDR Detection Methods:" << std::endl;
    std::wcout << L"    1. Entropy analysis of data sections" << std::endl;
    std::wcout << L"    2. Runtime memory scanning" << std::endl;
    std::wcout << L"    3. API call pattern analysis" << std::endl;
    std::wcout << L"    4. Behavioral monitoring of decryption" << std::endl;
    std::wcout << L"    5. YARA rules for obfuscation patterns" << std::endl;
    std::wcout << L"\n[*] Check your EDR console for alerts!" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    return 0;
}
