/*
 * API Hashing Test - EDR Detection Test
 * 
 * 목적: API 해싱을 통한 동적 API 해결 기법 테스트
 * Purpose: Test EDR's ability to detect API hashing and dynamic API resolution
 * 
 * MITRE ATT&CK: T1027.007 (Dynamic API Resolution)
 * 
 * 탐지 포인트:
 * - GetProcAddress excessive calls
 * - LoadLibrary dynamic calls
 * - Hash-based API resolution patterns
 * - Manual parsing of Export Address Table (EAT)
 */

#include <windows.h>
#include <iostream>
#include <vector>

// Simple DJB2 hash function
DWORD HashString(const char* str) {
    DWORD hash = 5381;
    int c;
    while (c = *str++) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

// Test 1: API Hashing demonstration
void TestAPIHashing() {
    std::wcout << L"\n[Test 1] API Hashing Technique" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Common API names and their hashes:" << std::endl;
    
    std::vector<const char*> apis = {
        "CreateRemoteThread",
        "VirtualAllocEx",
        "WriteProcessMemory",
        "OpenProcess",
        "GetProcAddress",
        "LoadLibraryA"
    };
    
    for (const auto* api : apis) {
        DWORD hash = HashString(api);
        std::wcout << L"    " << api << L" -> 0x" << std::hex << hash << std::dec << std::endl;
    }
    
    std::wcout << L"\n[!] Malware stores hashes, not API names" << std::endl;
    std::wcout << L"[!] Resolves APIs by comparing hashes at runtime" << std::endl;
}

// Test 2: Dynamic API resolution
void TestDynamicAPIResolution() {
    std::wcout << L"\n[Test 2] Dynamic API Resolution" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Resolving API dynamically using GetProcAddress..." << std::endl;
    
    HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
    if (hKernel32) {
        // Demonstrate dynamic resolution
        typedef BOOL (WINAPI *pIsDebuggerPresent)(VOID);
        pIsDebuggerPresent fnIsDebuggerPresent = 
            (pIsDebuggerPresent)GetProcAddress(hKernel32, "IsDebuggerPresent");
        
        if (fnIsDebuggerPresent) {
            std::wcout << L"    [+] Successfully resolved: IsDebuggerPresent" << std::endl;
            std::wcout << L"    Address: 0x" << std::hex << (DWORD_PTR)fnIsDebuggerPresent << std::dec << std::endl;
        }
    }
    
    std::wcout << L"\n[!] EDR Should Detect:" << std::endl;
    std::wcout << L"    - Multiple GetProcAddress calls" << std::endl;
    std::wcout << L"    - Manual EAT parsing" << std::endl;
    std::wcout << L"    - Suspicious API resolution patterns" << std::endl;
}

int main() {
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: API Hashing" << std::endl;
    std::wcout << L"    MITRE ATT&CK: T1027.007" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    TestAPIHashing();
    TestDynamicAPIResolution();
    
    std::wcout << L"\n[+] Tests completed. Check EDR alerts!" << std::endl;
    return 0;
}
