/*
 * Control Flow Obfuscation Test - EDR Detection Test
 * 
 * 목적: 제어 흐름 난독화 기법 테스트
 * Purpose: Test control flow obfuscation techniques
 * 
 * MITRE ATT&CK: T1027
 * 
 * 탐지 포인트:
 * - Excessive jumps and branches
 * - Dead code insertion
 * - Opaque predicates
 * - Code flattening patterns
 */

#include <windows.h>
#include <iostream>

// Opaque predicate - always true but hard to determine statically
bool OpaquePredicateTrue() {
    int x = rand();
    return (x * x >= 0);  // Always true
}

// Test with obfuscated control flow
void TestObfuscatedFunction() {
    std::wcout << L"\n[Test] Control Flow Obfuscation" << std::endl;
    std::wcout << L"-----------------------------------------------------" << std::endl;
    
    std::wcout << L"[*] Executing obfuscated function..." << std::endl;
    
    int state = 0;
    
    // Flattened control flow
    while (true) {
        switch (state) {
            case 0:
                std::wcout << L"    [1] First step" << std::endl;
                if (OpaquePredicateTrue()) {
                    state = 1;
                } else {
                    state = 2;  // Dead code
                }
                break;
                
            case 1:
                std::wcout << L"    [2] Second step" << std::endl;
                // Insert dummy code
                for (int i = 0; i < 10; i++) {
                    int dummy = i * 2;
                    (void)dummy;  // Prevent optimization
                }
                state = 3;
                break;
                
            case 2:  // Dead code path
                std::wcout << L"    [X] Dead code" << std::endl;
                state = 3;
                break;
                
            case 3:
                std::wcout << L"    [3] Final step" << std::endl;
                goto exit_loop;
                
            default:
                goto exit_loop;
        }
    }
    
exit_loop:
    std::wcout << L"\n[!] EDR Should Detect:" << std::endl;
    std::wcout << L"    - Complex control flow patterns" << std::endl;
    std::wcout << L"    - Excessive branching" << std::endl;
    std::wcout << L"    - Code flattening indicators" << std::endl;
}

int main() {
    std::wcout << L"==================================================" << std::endl;
    std::wcout << L"    EDR Test: Control Flow Obfuscation" << std::endl;
    std::wcout << L"==================================================" << std::endl;
    
    TestObfuscatedFunction();
    
    std::wcout << L"\n[+] Test completed!" << std::endl;
    return 0;
}
