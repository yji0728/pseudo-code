# Testing (Google Test) and Encoding Standardization

## Encoding Standardization

- This repo uses UTF-8 with BOM for all source, scripts, and docs.
- Automatic policy: see `.editorconfig`.
- To normalize all files:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\normalize-encoding.ps1
```

## Unit Tests with Google Test

We provide a minimal Google Test setup linking against `edr_core.lib`.

### Prerequisites

- Visual Studio 2019/2022 with C++ components
- vcpkg with GoogleTest installed for `x64-windows` triplet

```powershell
# Install vcpkg and gtest (if not already)
# See https://github.com/microsoft/vcpkg#quick-start for vcpkg install
vcpkg integrate install
vcpkg install gtest:x64-windows

# Optionally set environment variable for faster detection
$env:VCPKG_ROOT = "C:\vcpkg"
```

### Build and Run Tests

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build_tests.ps1
```

- Outputs: `build_tests/bin/edr_tests.exe`
- Sample tests in `tests/sample_report_tests.cpp`

If gtest is not detected, the script exits with guidance. Ensure `gtest.lib` and `gtest_main.lib` are available under your vcpkg `installed/x64-windows/lib` folder.
