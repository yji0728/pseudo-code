# 테스트 커스터마이징 & 실시간 모니터링 시스템

## 개요

EDR Testing Tools의 테스트 커스터마이징 및 실시간 모니터링 시스템은 유연하고 강력한 테스트 실행 환경을 제공합니다.

### 주요 기능

#### 테스트 커스터마이징
- ✅ JSON 기반 테스트 시나리오 정의
- ✅ 기법별 파라미터 커스터마이징
- ✅ 조건부 실행 (프로세스 존재, 메모리, OS 버전 등)
- ✅ 테스트 체인 (순차적/병렬 실행)
- ✅ 사용자 정의 셸코드 주입
- ✅ 동적 파라미터 바인딩

#### 실시간 모니터링
- ✅ 실행 중 상태 표시 (진행률, 현재 기법)
- ✅ 실시간 로그 스트리밍
- ✅ 성능 지표 실시간 업데이트
- ✅ 탐지 이벤트 즉시 알림
- ✅ 대화형 제어 (일시정지/재개/중단)
- ✅ 실시간 대시보드

---

## 테스트 커스터마이징

### 1. 기본 개념

#### CustomTest 클래스

```cpp
CustomTest test;
test.id = "my_dll_injection";
test.name = "Custom DLL Injection";
test.description = "DLL injection with specific parameters";
test.techniqueId = "T1055.001";
test.category = "process_injection";
test.executionMode = ExecutionMode::SEQUENTIAL;
test.priority = 10;
test.maxRetries = 3;
test.timeout = std::chrono::seconds(60);
```

#### 파라미터 정의

```cpp
test.parameters.push_back(
    TestParameter("target_process", ParameterType::STRING, 
                  "notepad.exe", "Target process name")
);

test.parameters.push_back(
    TestParameter("dll_path", ParameterType::FILE_PATH, 
                  "C:\\test.dll", "DLL to inject", true)
);
```

**파라미터 타입:**
- `STRING`: 문자열 값
- `INTEGER`: 정수 값
- `BOOLEAN`: 불리언 값
- `PROCESS_ID`: 프로세스 ID
- `SHELLCODE`: 16진수 셸코드
- `FILE_PATH`: 파일 경로
- `REGISTRY_KEY`: 레지스트리 키

### 2. JSON 시나리오

#### 시나리오 구조

```json
{
  "id": "my_scenario",
  "name": "My Test Scenario",
  "description": "Description of the scenario",
  "author": "Your Name",
  "version": "1.0",
  "globalParameters": {
    "target_process": "notepad.exe",
    "cleanup_after_test": true
  },
  "preconditions": [
    {
      "conditionType": "is_elevated",
      "parameters": {},
      "negate": false
    }
  ],
  "tests": [ ... ],
  "chains": [ ... ]
}
```

#### 테스트 정의

```json
{
  "id": "dll_injection_test",
  "name": "DLL Injection Test",
  "description": "Inject DLL into target process",
  "techniqueId": "T1055.001",
  "category": "process_injection",
  "executionMode": "sequential",
  "priority": 10,
  "maxRetries": 3,
  "timeout": 60,
  "parameters": [
    {
      "name": "target_process",
      "type": "string",
      "value": "${globalParameters.target_process}",
      "description": "Target process name",
      "required": true
    },
    {
      "name": "dll_path",
      "type": "file_path",
      "value": "C:\\test.dll",
      "required": true
    }
  ],
  "preconditions": [
    {
      "conditionType": "process_exists",
      "parameters": {
        "process_name": "${parameters.target_process}"
      },
      "negate": false
    }
  ],
  "postconditions": [],
  "dependencies": []
}
```

#### 테스트 체인

```json
{
  "id": "injection_chain",
  "name": "Injection Technique Chain",
  "description": "Test multiple injection techniques",
  "testIds": [
    "dll_injection",
    "process_hollowing",
    "apc_injection"
  ],
  "executionMode": "sequential",
  "stopOnFirstFailure": false,
  "shareContext": true
}
```

### 3. 조건부 실행

#### 지원 조건

| 조건 타입 | 설명 | 파라미터 |
|----------|------|---------|
| `process_exists` | 프로세스 존재 확인 | `process_name` |
| `memory_available` | 사용 가능한 메모리 | `min_mb` |
| `os_version` | OS 버전 확인 | `min_version` |
| `file_exists` | 파일 존재 확인 | `filepath` |
| `registry_key_exists` | 레지스트리 키 확인 | `key_path` |
| `is_elevated` | 관리자 권한 확인 | - |

#### 조건 사용 예제

```json
"preconditions": [
  {
    "conditionType": "is_elevated",
    "parameters": {},
    "negate": false
  },
  {
    "conditionType": "memory_available",
    "parameters": {
      "min_mb": 500
    },
    "negate": false
  },
  {
    "conditionType": "process_exists",
    "parameters": {
      "process_name": "explorer.exe"
    },
    "negate": false
  }
]
```

### 4. 프로그래밍 인터페이스

#### 테스트 등록

```cpp
TestCustomizer& customizer = TestCustomizer::Instance();

CustomTest test = CreateMyCustomTest();
customizer.RegisterTest(test);
```

#### 시나리오 로드

```cpp
customizer.LoadScenario("scenarios/my_scenario.json");
```

#### 테스트 실행

```cpp
// 단일 테스트
std::map<std::string, json> params;
params["target_process"] = "notepad.exe";
params["dll_path"] = "C:\\test.dll";

TestResult result = customizer.ExecuteTest("dll_injection_test", params);

if (result.success) {
    std::cout << "Success: " << result.output << std::endl;
} else {
    std::cerr << "Failed: " << result.errorMessage << std::endl;
}
```

```cpp
// 시나리오 실행
std::map<std::string, json> params;
auto results = customizer.ExecuteScenario("my_scenario", params);

for (const auto& result : results) {
    std::cout << result.techniqueId << ": " 
              << (result.success ? "PASS" : "FAIL") << std::endl;
}
```

---

## 실시간 모니터링

### 1. 기본 사용법

#### 모니터 시작/중지

```cpp
RealtimeMonitor& monitor = RealtimeMonitor::Instance();

// 모니터링 시작
monitor.Start();

// 테스트 실행...

// 모니터링 중지
monitor.Stop();
```

#### 이벤트 알림

```cpp
// 테스트 시작
monitor.NotifyTestStarted("test_id", "Test Name");

// 진행 업데이트
monitor.NotifyTestProgress("test_id", 50.0, "Phase 2");

// 로그 추가
monitor.NotifyLog("test_id", "Allocating memory...");

// 테스트 완료
monitor.NotifyTestCompleted("test_id", true);

// 탐지 이벤트
monitor.NotifyDetection("test_id", detectionJSON);
```

### 2. 이벤트 핸들러

```cpp
// 이벤트 핸들러 등록
monitor.RegisterEventHandler([](const MonitorEvent& event) {
    switch (event.type) {
        case MonitorEventType::TEST_STARTED:
            std::cout << "Started: " << event.message << std::endl;
            break;
            
        case MonitorEventType::TEST_COMPLETED:
            std::cout << "Completed: " << event.message << std::endl;
            break;
            
        case MonitorEventType::DETECTION_EVENT:
            std::cout << "Detection: " << event.data.dump() << std::endl;
            break;
            
        default:
            break;
    }
});
```

### 3. 메트릭 조회

```cpp
// 현재 메트릭 가져오기
RealtimeMetrics metrics = monitor.GetMetrics();

std::cout << "Total Tests: " << metrics.totalTests << std::endl;
std::cout << "Completed: " << metrics.completedTests << std::endl;
std::cout << "Failed: " << metrics.failedTests << std::endl;
std::cout << "Progress: " << metrics.GetProgressPercent() << "%" << std::endl;
std::cout << "CPU Usage: " << metrics.cpuUsagePercent << "%" << std::endl;
std::cout << "Memory: " << metrics.memoryUsageMB << " MB" << std::endl;
```

### 4. 테스트 상태 조회

```cpp
// 모든 테스트 상태
auto statuses = monitor.GetTestStatuses();
for (const auto& status : statuses) {
    std::cout << status.testName << ": " 
              << status.progressPercent << "%" << std::endl;
}

// 특정 테스트 상태
auto status = monitor.GetTestStatus("test_id");
std::cout << "Status: " << (int)status.status << std::endl;
std::cout << "Progress: " << status.progressPercent << "%" << std::endl;
std::cout << "Phase: " << status.currentPhase << std::endl;
```

### 5. 대화형 제어

```cpp
// 일시정지
monitor.Pause();

// 재개
monitor.Resume();

// 스냅샷 생성
json snapshot = monitor.TakeSnapshot();
std::cout << snapshot.dump(2) << std::endl;

// 로그 내보내기
monitor.ExportLogs("monitor_log.json");
```

### 6. 콘솔 출력 유틸리티

```cpp
// 진행률 바
std::string bar = MonitorUtils::CreateProgressBar(75.5, 50);
std::cout << bar << std::endl;

// 시간 포맷팅
std::string time = MonitorUtils::FormatDuration(
    std::chrono::milliseconds(125000)
);
std::cout << "Duration: " << time << std::endl; // "2m 5s"

// 바이트 포맷팅
std::string size = MonitorUtils::FormatBytes(1536000);
std::cout << "Size: " << size << std::endl; // "1.46 MB"

// 컬러 출력
MonitorUtils::PrintColored("Success!", 10); // Green
```

---

## CLI 통합

### edr-cli 명령어

```bash
# JSON 시나리오 실행
edr-cli run-scenario --file scenarios/comprehensive_injection.json

# 특정 테스트만 실행
edr-cli run-test --id dll_injection_test --param target_process=notepad.exe

# 실시간 모니터링 활성화
edr-cli run-scenario --file scenarios/evasion.json --monitor

# 대화형 모드
edr-cli interactive

# 시나리오 검증
edr-cli validate-scenario --file scenarios/my_scenario.json
```

### CLI에서 파라미터 오버라이드

```bash
edr-cli run-scenario \
  --file scenarios/injection.json \
  --param target_process=calc.exe \
  --param timeout=120 \
  --param max_retries=5
```

---

## 고급 사용 사례

### 1. 동적 파라미터 바인딩

```json
{
  "parameters": [
    {
      "name": "target_pid",
      "type": "process_id",
      "value": "${context.previous_test.target_pid}",
      "description": "Use PID from previous test"
    }
  ]
}
```

### 2. 조건부 체인 실행

```cpp
TestChain chain;
chain.id = "conditional_chain";
chain.stopOnFirstFailure = true;
chain.shareContext = true;

// 이전 테스트 결과에 따라 다음 테스트 결정
chain.testIds = {"test1", "test2_if_success", "test3_if_fail"};
```

### 3. 커스텀 실행 함수

```cpp
test.executeFunction = [](const std::map<std::string, json>& params) {
    TestResult result;
    
    try {
        // 실제 테스트 로직
        std::string targetProc = params.at("target_process");
        DWORD pid = FindProcessId(targetProc);
        
        if (pid == 0) {
            result.success = false;
            result.errorMessage = "Process not found";
            return result;
        }
        
        // DLL 인젝션 수행
        bool injected = InjectDLL(pid, params.at("dll_path"));
        
        result.success = injected;
        result.output = "DLL injected successfully";
        result.metrics["pid"] = pid;
        
    } catch (const std::exception& e) {
        result.success = false;
        result.errorMessage = e.what();
    }
    
    return result;
};
```

### 4. 실시간 대시보드

```cpp
void LiveDashboard() {
    RealtimeMonitor& monitor = RealtimeMonitor::Instance();
    
    while (monitor.IsRunning()) {
        MonitorUtils::ClearConsole();
        
        // 헤더
        std::cout << "=== Live Dashboard ===" << std::endl;
        
        // 메트릭
        auto metrics = monitor.GetMetrics();
        std::cout << "Progress: " 
                  << MonitorUtils::CreateProgressBar(metrics.GetProgressPercent())
                  << " " << (int)metrics.GetProgressPercent() << "%" << std::endl;
        
        // 테스트 상태
        auto statuses = monitor.GetTestStatuses();
        for (const auto& status : statuses) {
            std::cout << status.testName << ": ";
            
            switch (status.status) {
                case TestStatus::RUNNING:
                    MonitorUtils::PrintColored("RUNNING", 11);
                    break;
                case TestStatus::COMPLETED:
                    MonitorUtils::PrintColored("✓ COMPLETED", 10);
                    break;
                case TestStatus::FAILED:
                    MonitorUtils::PrintColored("✗ FAILED", 12);
                    break;
                default:
                    std::cout << "PENDING";
            }
            
            std::cout << std::endl;
        }
        
        Sleep(1000); // 1초마다 업데이트
    }
}
```

---

## 예제 시나리오

### 프로젝트에 포함된 시나리오

#### 1. comprehensive_injection.json
포괄적인 프로세스 인젝션 테스트 모음

**포함 테스트:**
- DLL Injection (Basic & Advanced)
- Process Hollowing
- APC Injection
- Shellcode Injection

**실행:**
```bash
edr-cli run-scenario --file scenarios/comprehensive_injection.json
```

#### 2. edr_evasion.json
EDR 회피 기법 테스트

**포함 테스트:**
- API Hashing
- Indirect Syscalls
- PPID Spoofing
- Timing Evasion
- Memory Protection Evasion

**실행:**
```bash
edr-cli run-scenario --file scenarios/edr_evasion.json --monitor
```

---

## 문제 해결

### 시나리오 로드 실패

```cpp
try {
    customizer.LoadScenario("scenarios/my_scenario.json");
} catch (const json::parse_error& e) {
    std::cerr << "JSON parse error: " << e.what() << std::endl;
    // JSON 형식 확인 필요
} catch (const EDRException& e) {
    std::cerr << "Validation error: " << e.what() << std::endl;
    // 시나리오 검증 실패
}
```

### 테스트 실행 실패

```cpp
TestResult result = customizer.ExecuteTest("test_id", params);

if (!result.success) {
    std::cerr << "Test failed:" << std::endl;
    std::cerr << "  Error: " << result.errorMessage << std::endl;
    std::cerr << "  Output: " << result.output << std::endl;
    
    // 재시도 로직
    if (test.maxRetries > 0) {
        // Retry...
    }
}
```

### 모니터링 이벤트 누락

```cpp
// 이벤트 큐 확인
if (monitor.IsRunning()) {
    // 모니터가 실행 중인지 확인
} else {
    monitor.Start();
}

// 이벤트 핸들러 등록 확인
monitor.RegisterEventHandler(myHandler);
```

---

## 베스트 프랙티스

### 1. 테스트 시나리오 작성

- ✅ 명확한 테스트 ID 및 이름 사용
- ✅ 상세한 description 제공
- ✅ 적절한 timeout 설정
- ✅ preconditions로 실행 가능성 확인
- ✅ globalParameters 활용하여 중복 제거

### 2. 파라미터 설계

- ✅ required 필드 정확히 지정
- ✅ defaultValue 제공
- ✅ 변수 바인딩 활용 (`${...}`)
- ✅ 타입 안전성 유지

### 3. 실시간 모니터링

- ✅ 주기적인 progress 업데이트
- ✅ 의미 있는 phase 메시지
- ✅ 중요한 이벤트만 로깅
- ✅ 핸들러에서 무거운 작업 피하기

### 4. 에러 처리

- ✅ 모든 예외 캐치 및 기록
- ✅ 실패 시 상세한 에러 메시지
- ✅ 자동 재시도 설정
- ✅ 롤백 메커니즘 구현

---

## API 레퍼런스

### TestCustomizer 클래스

| 메서드 | 설명 |
|--------|------|
| `Instance()` | 싱글톤 인스턴스 가져오기 |
| `RegisterTest(test)` | 테스트 등록 |
| `LoadScenario(filepath)` | 시나리오 로드 |
| `ExecuteTest(id, params)` | 테스트 실행 |
| `ExecuteScenario(id, params)` | 시나리오 실행 |
| `ExecuteChain(chain, params)` | 체인 실행 |
| `GetRegisteredTests()` | 등록된 테스트 목록 |
| `GetScenarios()` | 시나리오 목록 |

### RealtimeMonitor 클래스

| 메서드 | 설명 |
|--------|------|
| `Instance()` | 싱글톤 인스턴스 |
| `Start()` | 모니터링 시작 |
| `Stop()` | 모니터링 중지 |
| `Pause()` | 일시정지 |
| `Resume()` | 재개 |
| `NotifyTestStarted(id, name)` | 테스트 시작 알림 |
| `NotifyTestProgress(id, %, phase)` | 진행 업데이트 |
| `NotifyTestCompleted(id, success)` | 완료 알림 |
| `NotifyLog(id, message)` | 로그 추가 |
| `RegisterEventHandler(handler)` | 핸들러 등록 |
| `GetMetrics()` | 현재 메트릭 |
| `GetTestStatuses()` | 테스트 상태 |
| `TakeSnapshot()` | 스냅샷 생성 |

---

## 추가 리소스

- [QUICKSTART.md](QUICKSTART.md): 빠른 시작 가이드
- [CONFIG_MANAGEMENT.md](CONFIG_MANAGEMENT.md): 설정 관리
- [DETECTION_VALIDATION.md](DETECTION_VALIDATION.md): 탐지 검증
- [ADVANCED_REPORTING.md](ADVANCED_REPORTING.md): 리포팅 시스템

---

**마지막 업데이트**: 2025-01-XX  
**버전**: 1.0  
**작성자**: EDR Testing Tools Team
