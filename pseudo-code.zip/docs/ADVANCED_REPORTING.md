# 고급 리포팅 시스템 가이드 (Advanced Reporting System)

## 📋 목차
1. [개요](#개요)
2. [주요 기능](#주요-기능)
3. [리포트 형식](#리포트-형식)
4. [사용 방법](#사용-방법)
5. [HTML 대시보드](#html-대시보드)
6. [ATT&CK Navigator 통합](#attack-navigator-통합)
7. [커스터마이제이션](#커스터마이제이션)
8. [API 레퍼런스](#api-레퍼런스)

---

## 개요

EDR Testing Tools의 **고급 리포팅 시스템**은 탐지 검증 결과를 다양한 형식으로 시각화하고 내보낼 수 있는 포괄적인 보고서 생성 프레임워크입니다.

### 주요 특징
- 🎨 **인터랙티브 HTML 대시보드**: 실시간 차트 및 그래프
- 🎯 **MITRE ATT&CK Navigator 통합**: 표준화된 매트릭스 시각화
- 📊 **다중 형식 지원**: HTML, JSON, CSV, TXT, PDF
- ⚡ **실시간 업데이트**: 탐지 진행 중 보고서 갱신
- 📈 **전문적인 시각화**: Chart.js 기반 고급 차트

---

## 주요 기능

### 1. 통합 리포팅 엔진
```cpp
// 모든 형식의 보고서를 한 번에 생성
ReportGenerator generator(detectionReport, "reports");
generator.GenerateAllReports();
```

**생성되는 파일:**
- `dashboard.html` - 인터랙티브 웹 대시보드
- `attack_navigator.json` - MITRE ATT&CK Navigator 레이어
- `detection_report.json` - 구조화된 JSON 데이터
- `detection_report.csv` - 스프레드시트 호환 CSV
- `summary.txt` - 요약 텍스트 보고서

### 2. 실시간 대시보드
- 탐지율 진행 바
- 기법별 상세 카드
- 이벤트 타임라인
- 탐지 방법 분포도
- 소스별 이벤트 통계

### 3. MITRE 매트릭스 시각화
- 색상 코딩된 기법 셀
- 탐지 신뢰도 표시
- 호버 툴팁 정보
- 클릭 가능한 상세 뷰

---

## 리포트 형식

### HTML 대시보드
**파일명:** `dashboard.html`

**기능:**
```
✓ 요약 통계 카드 (총 기법, 탐지율, 지연시간)
✓ 진행률 시각화 바
✓ MITRE ATT&CK 커버리지 매트릭스
✓ 기법별 상세 정보 카드
✓ 탐지 타임라인
✓ 이벤트 소스 분포 차트
✓ 내보내기 버튼 (PDF/JSON/CSV)
```

**스크린샷 예시:**
```
┌─────────────────────────────────────────────────────────┐
│  🛡️ EDR Detection Validation Report                    │
│  Generated: 2025-10-15 14:30:00                         │
│  [📄 Export PDF] [📊 Export JSON] [📈 Export CSV]       │
├─────────────────────────────────────────────────────────┤
│  Total: 5    Detected: 3    Rate: 60%    Latency: 1.3s │
├─────────────────────────────────────────────────────────┤
│  Detection Rate: [████████░░] 60%                       │
├─────────────────────────────────────────────────────────┤
│  🎯 MITRE ATT&CK Matrix                                 │
│  [🟢T1055.001] [🟢T1055.012] [🟡T1055.004]              │
│  [🔴T1055.002] [🔴T1055.003]                            │
└─────────────────────────────────────────────────────────┘
```

### ATT&CK Navigator JSON
**파일명:** `attack_navigator.json`

**사용 방법:**
1. https://mitre-attack.github.io/attack-navigator/ 방문
2. "Open Existing Layer" 클릭
3. "Upload from local" 선택
4. `attack_navigator.json` 업로드

**색상 코딩:**
| 색상 | 의미 | 점수 범위 |
|------|------|-----------|
| 🟢 Green | High confidence detection | 80-100% |
| 🟡 Yellow | Medium confidence detection | 50-79% |
| 🟠 Orange | Low confidence detection | 1-49% |
| 🔴 Red | Not detected | 0% |

**JSON 구조:**
```json
{
  "name": "EDR Detection Coverage",
  "versions": {
    "attack": "14",
    "navigator": "4.9.5",
    "layer": "4.5"
  },
  "domain": "enterprise-attack",
  "techniques": [
    {
      "techniqueID": "T1055.001",
      "enabled": true,
      "score": 85,
      "color": "#00ff00",
      "comment": "High confidence detection | Methods: ETW, Sysmon"
    }
  ]
}
```

### JSON 보고서
**파일명:** `detection_report.json`

**구조:**
```json
{
  "summary": {
    "totalTechniques": 5,
    "detectedTechniques": 3,
    "overallDetectionRate": 0.6,
    "averageDetectionLatencyMs": 1350,
    "totalETWEvents": 12,
    "totalSysmonEvents": 8,
    "totalWindowsEvents": 3
  },
  "results": [
    {
      "technique": "T1055.001",
      "techniqueName": "DLL Injection",
      "detected": true,
      "detectionMethods": ["ETW", "Sysmon"],
      "detectionLatencyMs": 1200,
      "detectionScore": 0.85,
      "etwEventCount": 5,
      "sysmonEventCount": 2,
      "windowsEventCount": 1
    }
  ]
}
```

### CSV 보고서
**파일명:** `detection_report.csv`

**컬럼:**
```csv
Technique,Technique Name,Detected,Detection Methods,Latency (ms),Score,ETW,Sysmon,Windows
T1055.001,DLL Injection,Yes,ETW;Sysmon,1200,0.85,5,2,1
T1055.012,Process Hollowing,Yes,Sysmon,1300,0.72,0,4,2
```

**용도:**
- Excel/Google Sheets 임포트
- 데이터 분석 및 필터링
- 차트 생성
- 보고서 통합

### 텍스트 요약
**파일명:** `summary.txt`

**내용:**
```
===================================================================
              EDR DETECTION VALIDATION SUMMARY                     
===================================================================

Generated: 2025-10-15 14:30:00

OVERALL STATISTICS:
-------------------------------------------------------------------
Total Techniques Tested:  5
Successfully Detected:    3
Detection Rate:           60.00%
Average Detection Latency:1350ms

EVENT SOURCES:
-------------------------------------------------------------------
ETW Events:               12
Sysmon Events:            8
Windows Event Log:        3

TECHNIQUE DETAILS:
===================================================================

T1055.001 - DLL Injection
Status: [DETECTED]
Detection Score: 85.00%
Latency: 1200ms
Methods: ETW, Sysmon
```

---

## 사용 방법

### 기본 사용법

```cpp
#include "detection_validator.hpp"
#include "report_generator.cpp"

// 1. 탐지 검증 수행
DetectionValidator validator;
validator.StartMonitoring();

// 기법 테스트...
std::vector<std::string> techniques = {"T1055.001", "T1055.012"};
validator.ValidateTechniques(techniques);

validator.StopMonitoring();

// 2. 보고서 생성
DetectionReport report = validator.GenerateReport();
ReportGenerator generator(report, "reports");

// 3. HTML 대시보드 생성
generator.GenerateHTMLDashboard("dashboard.html");

// 4. ATT&CK Navigator JSON 생성
generator.GenerateAttackNavigatorJSON("navigator.json");

// 5. 또는 모든 형식 생성
generator.GenerateAllReports();
```

### 고급 사용법

#### 커스텀 출력 디렉토리
```cpp
ReportGenerator generator(report, "C:\\Reports\\EDR_Test_2025");
generator.GenerateAllReports();
```

#### 선택적 보고서 생성
```cpp
// HTML만 생성
generator.GenerateHTMLDashboard("custom_dashboard.html");

// Navigator JSON만 생성
generator.GenerateAttackNavigatorJSON("my_coverage.json");
```

#### 프로그래매틱 데이터 접근
```cpp
// JSON 파싱
std::ifstream file("detection_report.json");
nlohmann::json reportData = nlohmann::json::parse(file);

double detectionRate = reportData["summary"]["overallDetectionRate"];
int totalDetected = reportData["summary"]["detectedTechniques"];

for (const auto& result : reportData["results"]) {
    std::string technique = result["technique"];
    bool detected = result["detected"];
    // 처리...
}
```

---

## HTML 대시보드

### 대시보드 구성 요소

#### 1. 헤더 섹션
```html
┌──────────────────────────────────────┐
│  🛡️ EDR Testing Dashboard            │
│  Comprehensive Detection Validation  │
│  [Export Buttons]                    │
└──────────────────────────────────────┘
```

#### 2. 요약 통계 카드
4개의 주요 메트릭:
- **Total Techniques**: 테스트된 총 기법 수
- **Detected**: 성공적으로 탐지된 기법 수
- **Detection Rate**: 전체 탐지율 (%)
- **Avg Latency**: 평균 탐지 지연 시간 (ms)

#### 3. 진행률 바
```html
Detection Rate: [████████░░] 60%
```
- 애니메이션 효과
- 색상 그라데이션 (녹색)
- 퍼센트 표시

#### 4. MITRE ATT&CK 매트릭스
```
🎯 MITRE ATT&CK Coverage Matrix
┌─────────┬─────────┬─────────┬─────────┐
│T1055.001│T1055.012│T1055.004│T1055.002│
│  🟢     │  🟢     │  🟡     │  🔴     │
└─────────┴─────────┴─────────┴─────────┘
```
- 그리드 레이아웃
- 호버 효과
- 클릭 시 상세 정보

#### 5. 기법 상세 카드
```
┌────────────────────────────────────┐
│ T1055.001 - DLL Injection          │
│ [✓ DETECTED]                       │
│                                    │
│ ⭕ 85%                             │
│                                    │
│ Latency: 1200ms                    │
│ Confidence: High                   │
│ Severity: [High]                   │
│                                    │
│ [ETW] [Sysmon]                     │
│                                    │
│ Events: ETW(5) Sysmon(2) Win(1)   │
└────────────────────────────────────┘
```

#### 6. 탐지 타임라인
```
⏱️ Detection Timeline
│
├─ +1200ms
│  T1055.001 (DLL Injection) detected
│  [ETW] [Sysmon]
│
├─ +1300ms
│  T1055.012 (Process Hollowing) detected
│  [Sysmon]
│
├─ +1550ms
│  T1055.004 (APC Injection) detected
│  [ETW]
```

#### 7. 이벤트 분포 테이블
```
Event Source      Count    Percentage
────────────────────────────────────
ETW                 12        52.2%
Sysmon               8        34.8%
Windows Event Log    3        13.0%
```

### 대시보드 커스터마이제이션

#### CSS 스타일 수정
```css
/* 기본 색상 변경 */
:root {
    --primary-color: #667eea;
    --success-color: #10b981;
    --danger-color: #ef4444;
    --warning-color: #f59e0b;
}

/* 카드 스타일 */
.stat-card {
    background: white;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
```

#### JavaScript 데이터 수정
```javascript
// 보고서 데이터 로드
const reportData = {
    summary: { /* ... */ },
    results: [ /* ... */ ]
};

// 대시보드 초기화
initDashboard();
```

---

## ATT&CK Navigator 통합

### Navigator JSON 생성

```cpp
ReportGenerator generator(report, "reports");
generator.GenerateAttackNavigatorJSON("my_layer.json");
```

### Navigator 사용 가이드

#### 1. Navigator 웹사이트 접속
```
https://mitre-attack.github.io/attack-navigator/
```

#### 2. 레이어 업로드
1. 좌측 메뉴에서 **"+ Create New Layer"** 클릭
2. **"Open Existing Layer"** 선택
3. **"Upload from local"** 클릭
4. `attack_navigator.json` 파일 선택

#### 3. 레이어 탐색
- **확대/축소**: 마우스 휠
- **기법 선택**: 클릭
- **필터링**: 상단 검색바
- **색상 범례**: 우측 패널

#### 4. 레이어 내보내기
- **SVG**: 벡터 이미지로 저장
- **Excel**: 스프레드시트 형식
- **JSON**: 수정된 레이어 저장

### 고급 Navigator 기능

#### 커스텀 필터
```json
"filters": {
    "platforms": ["windows"],
    "tactics": ["defense-evasion", "privilege-escalation"]
}
```

#### 메타데이터 추가
```json
"metadata": [
    {
        "name": "Test Date",
        "value": "2025-10-15"
    },
    {
        "name": "EDR Version",
        "value": "1.0.0"
    }
]
```

#### 그라데이션 설정
```json
"gradient": {
    "colors": ["#ff0000", "#ffff00", "#00ff00"],
    "minValue": 0,
    "maxValue": 100
}
```

---

## 커스터마이제이션

### 보고서 템플릿 수정

#### HTML 템플릿
`reports/dashboard.html` 파일을 직접 수정하여 레이아웃 변경:

```html
<!-- 커스텀 섹션 추가 -->
<div class="custom-section">
    <h2>🔍 Custom Analysis</h2>
    <div id="customContent">
        <!-- 추가 컨텐츠 -->
    </div>
</div>
```

#### CSS 스타일
```css
/* 다크 모드 테마 */
body {
    background: #1a1a1a;
    color: #e0e0e0;
}

.stat-card {
    background: #2d2d2d;
    border: 1px solid #404040;
}
```

### 데이터 전처리

```cpp
// 커스텀 데이터 필터링
DetectionReport CustomizeReport(const DetectionReport& original) {
    DetectionReport customized = original;
    
    // 탐지된 기법만 포함
    customized.results.erase(
        std::remove_if(customized.results.begin(), 
                      customized.results.end(),
                      [](const DetectionResult& r) { return !r.detected; }),
        customized.results.end()
    );
    
    // 통계 재계산
    customized.summary.totalTechniques = customized.results.size();
    customized.summary.detectedTechniques = customized.results.size();
    customized.summary.overallDetectionRate = 1.0;
    
    return customized;
}

// 사용
DetectionReport filtered = CustomizeReport(originalReport);
ReportGenerator generator(filtered, "reports");
generator.GenerateHTMLDashboard("filtered_dashboard.html");
```

### 다국어 지원

```cpp
// 언어별 템플릿
std::map<std::string, std::string> localization = {
    {"en", "Detection Report"},
    {"ko", "탐지 보고서"},
    {"ja", "検出レポート"}
};

// 커스텀 생성기
class LocalizedReportGenerator : public ReportGenerator {
public:
    void SetLanguage(const std::string& lang) {
        language_ = lang;
    }
    
private:
    std::string language_ = "en";
};
```

---

## API 레퍼런스

### ReportGenerator 클래스

#### 생성자
```cpp
ReportGenerator(const DetectionReport& report, 
                const std::string& outputDir = "reports")
```
**매개변수:**
- `report`: DetectionReport 객체
- `outputDir`: 출력 디렉토리 경로 (기본값: "reports")

#### 메서드

##### GenerateHTMLDashboard
```cpp
bool GenerateHTMLDashboard(const std::string& filename = "dashboard.html")
```
**설명:** 인터랙티브 HTML 대시보드 생성  
**반환값:** 성공 시 `true`, 실패 시 `false`  
**생성 파일:** `{outputDir}/{filename}`

**예제:**
```cpp
if (generator.GenerateHTMLDashboard("report.html")) {
    std::cout << "Dashboard created successfully!" << std::endl;
}
```

##### GenerateAttackNavigatorJSON
```cpp
bool GenerateAttackNavigatorJSON(const std::string& filename = "attack_navigator.json")
```
**설명:** MITRE ATT&CK Navigator JSON 생성  
**반환값:** 성공 시 `true`, 실패 시 `false`  
**생성 파일:** `{outputDir}/{filename}`

**예제:**
```cpp
if (generator.GenerateAttackNavigatorJSON("coverage.json")) {
    std::cout << "Navigator JSON created!" << std::endl;
    std::cout << "Import at: https://mitre-attack.github.io/attack-navigator/" << std::endl;
}
```

##### GenerateAllReports
```cpp
bool GenerateAllReports()
```
**설명:** 모든 형식의 보고서를 한 번에 생성  
**반환값:** 모든 보고서 생성 성공 시 `true`  
**생성 파일:**
- `dashboard.html`
- `attack_navigator.json`
- `detection_report.json`
- `detection_report.csv`
- `summary.txt`

**예제:**
```cpp
if (generator.GenerateAllReports()) {
    std::cout << "All reports generated successfully!" << std::endl;
} else {
    std::cerr << "Some reports failed to generate" << std::endl;
}
```

---

## 모범 사례

### 1. 정기적인 보고서 생성
```cpp
// 자동화 스크립트
void AutomatedReporting() {
    DetectionValidator validator;
    validator.StartMonitoring();
    
    // 테스트 실행...
    
    DetectionReport report = validator.GenerateReport();
    
    // 타임스탬프 포함 파일명
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << "report_" << std::put_time(std::localtime(&time), "%Y%m%d_%H%M%S");
    
    ReportGenerator generator(report, "reports/" + ss.str());
    generator.GenerateAllReports();
}
```

### 2. 보고서 비교
```cpp
// 이전 보고서와 비교
void CompareReports(const std::string& oldReport, 
                    const std::string& newReport) {
    std::ifstream oldFile(oldReport);
    std::ifstream newFile(newReport);
    
    json oldData = json::parse(oldFile);
    json newData = json::parse(newFile);
    
    double oldRate = oldData["summary"]["overallDetectionRate"];
    double newRate = newData["summary"]["overallDetectionRate"];
    
    double improvement = (newRate - oldRate) * 100;
    std::cout << "Detection rate changed by: " << improvement << "%" << std::endl;
}
```

### 3. 보고서 아카이빙
```cpp
// 보고서 압축 및 아카이빙
void ArchiveReports(const std::string& reportDir) {
    std::string timestamp = GetTimestamp();
    std::string archiveName = "reports_archive_" + timestamp + ".zip";
    
    // 압축 로직...
    
    std::cout << "Reports archived to: " << archiveName << std::endl;
}
```

---

## 트러블슈팅

### 문제 1: HTML 대시보드가 비어있음
**원인:** JavaScript 데이터가 올바르게 로드되지 않음  
**해결:**
```javascript
// 콘솔에서 확인
console.log('Report data:', reportData);

// 데이터 파일 경로 확인
fetch('detection_report.json')
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
```

### 문제 2: Navigator JSON 임포트 실패
**원인:** JSON 형식 오류  
**해결:**
```bash
# JSON 유효성 검사
python -m json.tool attack_navigator.json
```

### 문제 3: 보고서 생성 실패
**원인:** 디렉토리 권한 부족  
**해결:**
```cpp
// 관리자 권한으로 실행
// 또는 출력 디렉토리 권한 확인
DWORD attr = GetFileAttributesA(outputDir.c_str());
if (attr == INVALID_FILE_ATTRIBUTES) {
    CreateDirectoryA(outputDir.c_str(), NULL);
}
```

---

## 참고 자료

### 외부 링크
- **MITRE ATT&CK Navigator**: https://mitre-attack.github.io/attack-navigator/
- **Chart.js 문서**: https://www.chartjs.org/docs/
- **JSON Schema**: https://json-schema.org/

### 관련 문서
- `DETECTION_VALIDATION.md` - 탐지 검증 시스템
- `docs/TEST_COVERAGE.md` - 테스트 커버리지
- `docs/detection_guide.md` - 탐지 가이드

---

## 변경 이력

| 버전 | 날짜 | 변경 내역 |
|------|------|-----------|
| 1.0 | 2025-10-15 | 초안 작성 |

---

**문서 작성자:** GitHub Copilot  
**최종 수정:** 2025-10-15
