# 코드 고도화 스펙 (Code Enhancement Specification)

## 문서 정보
- **작성일**: 2025년 10월 14일
- **버전**: 1.0
- **대상 프로젝트**: EDR Testing Tools (pseudo-code)

---

## 📋 목차
1. [개요](#개요)
2. [현재 상태 분석](#현재-상태-분석)
3. [고도화 항목](#고도화-항목)
4. [우선순위 매트릭스](#우선순위-매트릭스)
5. [상세 스펙](#상세-스펙)

---

## 개요

### 목적
EDR 테스팅 도구의 기능 확장, 코드 품질 개선, 사용성 향상을 통해 전문적인 보안 테스팅 프레임워크로 발전시킵니다.

### 분석 결과 요약
- **총 코드 파일**: 9개 (C++ 7개, PowerShell 2개)
- **워크플로우 스크립트**: 3개
- **문서 파일**: 6개
- **현재 커버리지**: MITRE ATT&CK 8+ 기법

---

## 현재 상태 분석

### ✅ 강점
1. **명확한 구조**: 기법별로 잘 분류된 샘플 코드
2. **상세한 주석**: 한/영 이중 언어 지원
3. **테스트 자동화**: 워크플로우 스크립트 존재
4. **교육적 가치**: 각 기법별 탐지 포인트 문서화

### ⚠️ 개선 필요 영역

#### 1. **기능적 제한**
- 제한된 공격 기법 (8개)
- 실제 페이로드 실행 없음 (시뮬레이션만)ㅊㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴ
- 회피 기법(Evasion) 부재
- 네트워크 기반 기법 부족

#### 2. **코드 품질**
- 에러 처리 부족
- 로깅 시스템 미비
- 리소스 정리 불완전
- PowerShell 코드 규칙 위반 (Unapproved verb)

#### 3. **테스트 및 검증**
- 단위 테스트 없음
- 성능 측정 부재
- EDR 탐지 검증 자동화 부족
- 결과 리포팅 기본적 수준

#### 4. **사용성**
- CLI 인터페이스만 제공
- 설정 관리 시스템 없음
- 테스트 커스터마이징 제한적
- 실시간 모니터링 부재

#### 5. **보안 및 안전성**
- 샌드박스 검증 없음
- 실행 환경 체크 부족
- 악용 방지 메커니즘 약함

---

## 고도화 항목

### Category 1: 핵심 기능 확장 (Core Features)

#### 1.1 추가 공격 기법 구현
**설명**: MITRE ATT&CK 기반 추가 기법 구현

**목표 기법**:
- **T1574.002**: DLL Side-Loading
- **T1055.013**: Process Doppelgänging
- **T1055.014**: VDSO Hijacking
- **T1106**: Native API Execution
- **T1027**: Obfuscated Files or Information
- **T1140**: Deobfuscate/Decode Files or Information
- **T1070**: Indicator Removal
- **T1055.015**: ListPlanting

**우선순위**: 🔴 High

**예상 작업량**: 20-25 시간

**구현 계획**:
```
samples/
├── dll_sideloading/
│   ├── README.md
│   ├── dll_search_order.cpp
│   └── phantom_dll_hollowing.cpp
├── obfuscation/
│   ├── README.md
│   ├── string_encryption.cpp
│   ├── api_hashing.cpp
│   └── control_flow_obfuscation.cpp
└── evasion/
    ├── README.md
    ├── sandbox_detection.cpp
    ├── anti_debugging.cpp
    └── timing_attacks.cpp
```

**성공 지표**:
- 최소 8개의 새로운 기법 추가
- 각 기법별 독립 실행 가능
- EDR 탐지 포인트 문서화 완료

---

#### 1.2 고급 셸코드 실행 기법
**설명**: 다양한 셸코드 실행 및 회피 기법 구현

**기능**:
- **Early Bird APC Injection**: 프로세스 초기화 시 APC 큐 삽입
- **Module Stomping**: 로드된 모듈 메모리 덮어쓰기
- **Thread Stack Spoofing**: 콜스택 조작
- **Call Stack Spoofing**: 함수 호출 추적 우회

**우선순위**: 🟠 Medium-High

**예상 작업량**: 15-20 시간

**기술 스펙**:
```cpp
// 예시 인터페이스
class ShellcodeExecutor {
public:
    enum class ExecutionMethod {
        CreateThread,
        EarlyBird,
        ModuleStomping,
        StackSpoofing,
        Fiber,
        Exception
    };
    
    bool Execute(const std::vector<BYTE>& shellcode, 
                 ExecutionMethod method,
                 const ExecutionOptions& options);
    
    std::vector<DetectionPoint> GetDetectionPoints() const;
};
```

---

#### 1.3 네트워크 기반 기법
**설명**: C2 통신 시뮬레이션 및 네트워크 기반 공격 기법

**기능**:
- HTTP/HTTPS C2 통신 시뮬레이션
- DNS 터널링 기법
- SMB Named Pipe 통신
- WebSocket 기반 통신

**우선순위**: 🟠 Medium-High

**예상 작업량**: 20-25 시간

**구현 예시**:
```cpp
// samples/network/c2_simulation.cpp
namespace C2Simulation {
    // HTTP Beacon
    bool SimulateHTTPBeacon(const std::string& server, int interval);
    
    // DNS Tunneling
    bool SimulateDNSTunnel(const std::string& domain);
    
    // Named Pipe
    bool SimulateNamedPipe(const std::wstring& pipeName);
}
```

---

#### 1.4 지속성 메커니즘 (Persistence)
**설명**: 시스템 재부팅 후에도 유지되는 기법 시뮬레이션

**기법**:
- **T1547.001**: Registry Run Keys
- **T1053.005**: Scheduled Task
- **T1543.003**: Windows Service
- **T1037**: Boot or Logon Initialization Scripts
- **T1546.011**: Application Shimming
- **T1547.009**: Shortcut Modification

**우선순위**: 🟡 Medium

**예상 작업량**: 15 시간

---

### Category 2: 코드 품질 개선 (Code Quality)

#### 2.1 통합 로깅 시스템
**설명**: 구조화된 로깅 프레임워크 구축

**기능**:
- 다중 로그 레벨 (DEBUG, INFO, WARN, ERROR, CRITICAL)
- 파일/콘솔/원격 출력 지원
- JSON 형식 구조화 로그
- 타임스탬프 및 스레드 ID 자동 추가
- 로그 순환(Rotation) 지원

**우선순위**: 🔴 High

**예상 작업량**: 10 시간

**기술 스펙**:
```cpp
// include/logger.hpp
class EDRLogger {
public:
    enum class Level { DEBUG, INFO, WARN, ERROR, CRITICAL };
    
    static EDRLogger& Instance();
    
    void Log(Level level, const std::string& message, 
             const std::source_location& loc = std::source_location::current());
    
    void SetOutputFile(const std::string& filename);
    void SetLevel(Level minLevel);
    void EnableJSON(bool enable);
    
    // Structured logging
    void LogEvent(const std::string& eventType,
                  const std::map<std::string, std::string>& attributes);
};

// 사용 예시
#define LOG_INFO(msg) EDRLogger::Instance().Log(EDRLogger::Level::INFO, msg)
#define LOG_ERROR(msg) EDRLogger::Instance().Log(EDRLogger::Level::ERROR, msg)
```

---

#### 2.2 에러 처리 및 예외 안전성
**설명**: 강건한 에러 처리 메커니즘 구현

**개선 사항**:
- RAII 패턴 적용 (자동 리소스 정리)
- 예외 안전성 보장
- 에러 코드 체계화
- 복구 가능한 에러 처리

**우선순위**: 🔴 High

**예상 작업량**: 12 시간

**구현 예시**:
```cpp
// include/error_handling.hpp
enum class EDRErrorCode {
    SUCCESS = 0,
    PROCESS_NOT_FOUND = 1001,
    MEMORY_ALLOCATION_FAILED = 1002,
    INJECTION_FAILED = 1003,
    PERMISSION_DENIED = 1004,
    INVALID_PARAMETER = 1005
};

class EDRException : public std::exception {
private:
    EDRErrorCode code_;
    std::string message_;
    std::string context_;
    
public:
    EDRException(EDRErrorCode code, const std::string& message,
                 const std::string& context = "");
    
    const char* what() const noexcept override;
    EDRErrorCode code() const noexcept { return code_; }
};

// RAII 래퍼 클래스들
class HandleGuard {
    HANDLE handle_;
public:
    explicit HandleGuard(HANDLE h) : handle_(h) {}
    ~HandleGuard() { if (handle_) CloseHandle(handle_); }
    HANDLE get() const { return handle_; }
};
```

---

#### 2.3 PowerShell 코드 품질 개선
**설명**: PSScriptAnalyzer 규칙 준수 및 모범 사례 적용

**개선 사항**:
- 승인된 동사 사용 (Compile-CppSamples → Build-CppSamples)
- 미사용 변수 제거
- 파라미터 검증 강화
- 도움말 주석 추가

**우선순위**: 🟠 Medium

**예상 작업량**: 6 시간

**개선 예시**:
```powershell
<#
.SYNOPSIS
    Builds C++ samples for EDR testing.

.DESCRIPTION
    Compiles all C++ source files in the samples directory using Visual Studio compiler.

.PARAMETER Clean
    Remove all previous build artifacts before compilation.

.PARAMETER Configuration
    Build configuration: Debug or Release.

.EXAMPLE
    Build-CppSamples -Clean -Configuration Release
#>
function Build-CppSamples {
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$Clean,
        
        [Parameter()]
        [ValidateSet('Debug', 'Release')]
        [string]$Configuration = 'Release'
    )
    
    begin {
        $ErrorActionPreference = 'Stop'
        Write-Verbose "Starting build process..."
    }
    
    process {
        # 구현
    }
    
    end {
        Write-Verbose "Build process completed"
    }
}
```

---

#### 2.4 설정 관리 시스템
**설명**: 중앙화된 설정 관리 및 프로파일 지원

**기능**:
- JSON/YAML 설정 파일
- 환경별 프로파일 (개발/테스트/프로덕션)
- 테스트 시나리오 커스터마이징
- 타임아웃 및 재시도 설정

**우선순위**: 🟡 Medium

**예상 작업량**: 8 시간

**설정 파일 예시**:
```json
{
  "version": "1.0",
  "profile": "default",
  "execution": {
    "timeout_seconds": 60,
    "retry_count": 3,
    "delay_between_tests_ms": 1000
  },
  "logging": {
    "level": "INFO",
    "output_file": "logs/edr_test.log",
    "format": "json",
    "max_file_size_mb": 10,
    "max_files": 5
  },
  "test_scenarios": {
    "process_injection": {
      "enabled": true,
      "techniques": ["dll_injection", "process_hollowing", "apc_injection"]
    },
    "fileless": {
      "enabled": true,
      "techniques": ["memory_execution", "wmi_execution"]
    }
  },
  "safety": {
    "require_confirmation": true,
    "sandbox_check": true,
    "allowed_targets": ["notepad.exe", "calc.exe"]
  }
}
```

---

### Category 3: 테스트 및 검증 (Testing & Validation)

#### 3.1 단위 테스트 프레임워크
**설명**: C++ 및 PowerShell 단위 테스트 구현

**기능**:
- Google Test (C++) 통합
- Pester (PowerShell) 테스트
- 모킹 및 스텁 지원
- 코드 커버리지 측정

**우선순위**: 🟠 Medium-High

**예상 작업량**: 15 시간

**구현 구조**:
```
tests/
├── cpp/
│   ├── CMakeLists.txt
│   ├── test_process_injection.cpp
│   ├── test_shellcode_execution.cpp
│   └── mocks/
│       └── mock_windows_api.hpp
├── powershell/
│   ├── automated_test.Tests.ps1
│   └── build.Tests.ps1
└── integration/
    └── end_to_end_test.ps1
```

**테스트 예시**:
```cpp
// tests/cpp/test_process_injection.cpp
#include <gtest/gtest.h>
#include "process_injection.hpp"

TEST(ProcessInjectionTest, FindProcessById) {
    // Arrange
    auto notepad = LaunchTestProcess("notepad.exe");
    
    // Act
    DWORD pid = FindProcessId(L"notepad.exe");
    
    // Assert
    EXPECT_NE(pid, 0);
    EXPECT_EQ(pid, notepad.GetPID());
    
    // Cleanup
    notepad.Terminate();
}

TEST(ProcessInjectionTest, HandleInvalidProcess) {
    // Act & Assert
    EXPECT_THROW(
        InjectDLL(99999, L"test.dll"),
        EDRException
    );
}
```

---

#### 3.2 현재 구현 상태 (링크)
- 단위 테스트 안내: `docs/TESTING.md`
- CI 파이프라인: `.github/workflows/ci.yml`
- 테스트 스크립트: `scripts/build_tests.ps1`

#### 3.2 EDR 탐지 검증 자동화
**설명**: EDR 탐지 결과 자동 확인 시스템

**기능**:
- ETW (Event Tracing for Windows) 이벤트 수집
- Windows Event Log 분석
- Sysmon 로그 파싱
- 탐지율 자동 계산

**우선순위**: 🔴 High

**예상 작업량**: 18 시간

**구현 계획**:
```cpp
// include/detection_validator.hpp
class DetectionValidator {
public:
    struct DetectionResult {
        std::string technique;
        bool detected;
        std::vector<std::string> detectionMethods;
        std::chrono::milliseconds detectionLatency;
        std::string details;
    };
    
    void StartMonitoring();
    void StopMonitoring();
    
    DetectionResult ValidateTechnique(const std::string& techniqueName);
    
    // ETW 이벤트 수집
    void EnableETWProvider(const GUID& providerId);
    
    // Sysmon 로그 분석
    std::vector<SysmonEvent> ParseSysmonLogs(
        const std::chrono::system_clock::time_point& startTime);
    
    // 탐지율 보고
    DetectionReport GenerateReport();
};
```

---

#### 3.3 성능 벤치마킹
**설명**: 각 기법의 실행 시간 및 리소스 사용량 측정

**측정 항목**:
- 실행 시간
- 메모리 사용량
- CPU 사용률
- 디스크 I/O
- 네트워크 I/O

**우선순위**: 🟡 Medium

**예상 작업량**: 8 시간

**구현 예시**:
```cpp
// include/performance_monitor.hpp
class PerformanceMonitor {
public:
    struct Metrics {
        std::chrono::microseconds executionTime;
        size_t peakMemoryUsage;
        double cpuUsagePercent;
        size_t diskBytesRead;
        size_t diskBytesWritten;
    };
    
    void StartMeasurement();
    Metrics StopMeasurement();
    
    void ExportToCSV(const std::string& filename);
    void ExportToJSON(const std::string& filename);
};
```

---

### Category 4: 리포팅 및 시각화 (Reporting & Visualization)

#### 4.1 HTML 대시보드
**설명**: 인터랙티브 웹 기반 테스트 결과 대시보드

**기능**:
- 실시간 테스트 진행 상황
- 탐지율 시각화 (차트/그래프)
- MITRE ATT&CK 히트맵
- 기법별 상세 결과
- 타임라인 뷰

**우선순위**: 🟡 Medium

**예상 작업량**: 20 시간

**기술 스택**:
- HTML5/CSS3
- JavaScript (Chart.js, D3.js)
- Bootstrap 5
- WebSocket (실시간 업데이트)

**대시보드 구조**:
```
reports/
├── dashboard.html
├── assets/
│   ├── css/
│   │   └── dashboard.css
│   ├── js/
│   │   ├── chart_renderer.js
│   │   ├── attack_matrix.js
│   │   └── websocket_client.js
│   └── data/
│       └── test_results.json
└── templates/
    ├── technique_detail.html
    └── comparison_view.html
```

---

#### 4.2 PDF 보고서 생성
**설명**: 전문적인 PDF 형식 테스트 보고서

**포함 내용**:
- 요약 (Executive Summary)
- 테스트 환경 정보
- 기법별 상세 결과
- 탐지 포인트 분석
- 권장사항
- 부록 (로그, 스크린샷)

**우선순위**: 🟡 Medium-Low

**예상 작업량**: 12 시간

---

#### 4.3 MITRE ATT&CK Navigator 연동
**설명**: ATT&CK Navigator JSON 형식 출력

**기능**:
- 테스트된 기법 자동 표시
- 탐지율 기반 색상 코딩
- 커버리지 히트맵 생성

**우선순위**: 🟡 Medium-Low

**예상 작업량**: 6 시간

**출력 예시**:
```json
{
  "name": "EDR Test Coverage",
  "versions": {
    "attack": "14",
    "navigator": "4.9.5",
    "layer": "4.5"
  },
  "domain": "enterprise-attack",
  "techniques": [
    {
      "techniqueID": "T1055.001",
      "enabled": true,
      "score": 100,
      "color": "#00ff00",
      "comment": "Detected by EDR"
    },
    {
      "techniqueID": "T1055.012",
      "enabled": true,
      "score": 0,
      "color": "#ff0000",
      "comment": "Not detected"
    }
  ]
}
```

---

### Category 5: 사용성 개선 (Usability)

#### 5.1 GUI 인터페이스
**설명**: Windows Forms 기반 GUI 도구

**기능**:
- 기법 선택 체크박스
- 실시간 로그 뷰어
- 설정 편집기
- 보고서 뷰어

**우선순위**: 🟢 Low-Medium

**예상 작업량**: 25 시간

**기술**: C# WPF 또는 Electron

---

#### 5.2 커맨드라인 인터페이스 개선
**설명**: 강력한 CLI 도구 개발

**기능**:
```bash
# 특정 기법 실행
edr-test run --technique T1055.001

# 여러 기법 실행
edr-test run --techniques T1055.001,T1055.012 --output report.json

# 프로파일 사용
edr-test run --profile aggressive

# 리스트 확인
edr-test list techniques
edr-test list profiles

# 보고서 생성
edr-test report --format html --output report.html

# 검증 모드
edr-test validate --edr-logs C:\logs\edr.json
```

**우선순위**: 🟠 Medium

**예상 작업량**: 10 시간

---

#### 5.3 대화형 모드
**설명**: 단계별 가이드 실행 모드

**기능**:
- 질문 기반 설정
- 진행 상황 표시
- 에러 발생 시 해결 제안
- 롤백 기능

**우선순위**: 🟢 Low

**예상 작업량**: 8 시간

---

### Category 6: 보안 및 안전성 (Security & Safety)

#### 6.1 샌드박스 탐지
**설명**: 실제 환경과 샌드박스 구분

**체크 항목**:
- VM 환경 탐지
- 디버거 탐지
- 샌드박스 아티팩트 확인
- 사용자 활동 확인

**우선순위**: 🔴 High

**예상 작업량**: 10 시간

**구현 예시**:
```cpp
// include/environment_checker.hpp
class EnvironmentChecker {
public:
    struct EnvironmentInfo {
        bool isVirtualMachine;
        bool isDebuggerPresent;
        bool isSandbox;
        bool hasUserActivity;
        std::string virtualizationPlatform;
        std::vector<std::string> artifacts;
    };
    
    EnvironmentInfo CheckEnvironment();
    
    bool IsSafeToExecute() const;
    bool RequiresElevation() const;
};
```

---

#### 6.2 실행 환경 검증
**설명**: 안전한 테스트 환경 확인

**검증 항목**:
- 격리된 네트워크 확인
- 프로덕션 시스템 방지
- 도메인 환경 체크
- 중요 프로세스 보호

**우선순위**: 🔴 High

**예상 작업량**: 8 시간

---

#### 6.3 악용 방지 메커니즘
**설명**: 도구의 악의적 사용 방지

**방법**:
- 라이선스 헤더 강제
- 실행 빈도 제한
- 감사 로그 생성
- 타임스탬프 기반 제한

**우선순위**: 🟠 Medium

**예상 작업량**: 6 시간

---

#### 6.4 롤백 및 클린업
**설명**: 테스트 후 시스템 원상복구

**기능**:
- 생성된 프로세스 자동 종료
- 레지스트리 변경 복구
- 파일 삭제
- 스케줄 작업 제거

**우선순위**: 🔴 High

**예상 작업량**: 10 시간

---

### Category 7: 문서화 (Documentation)

#### 7.1 API 문서 자동 생성
**설명**: Doxygen/JSDoc 기반 API 문서

**우선순위**: 🟡 Medium

**예상 작업량**: 6 시간

---

#### 7.2 사용자 가이드 강화
**설명**: 단계별 튜토리얼 및 예제

**포함 내용**:
- 설치 가이드
- 빠른 시작 가이드
- 기법별 상세 설명
- 트러블슈팅
- FAQ

**우선순위**: 🟠 Medium

**예상 작업량**: 12 시간

---

#### 7.3 기여 가이드
**설명**: 오픈소스 기여자를 위한 문서

**포함 내용**:
- 코딩 표준
- PR 가이드라인
- 새로운 기법 추가 방법
- 테스트 요구사항

**우선순위**: 🟢 Low

**예상 작업량**: 4 시간

---

## 우선순위 매트릭스

### 🔴 High Priority (즉시 착수)
| 항목 | 임팩트 | 작업량 | 비고 |
|------|--------|--------|------|
| 1.1 추가 공격 기법 구현 | ⭐⭐⭐⭐⭐ | 20-25h | 핵심 기능 |
| 2.1 통합 로깅 시스템 | ⭐⭐⭐⭐ | 10h | 품질 개선 필수 |
| 2.2 에러 처리 강화 | ⭐⭐⭐⭐ | 12h | 안정성 향상 |
| 3.2 EDR 탐지 검증 | ⭐⭐⭐⭐⭐ | 18h | 핵심 목적 달성 |
| 6.1 샌드박스 탐지 | ⭐⭐⭐⭐ | 10h | 안전성 필수 |
| 6.2 실행 환경 검증 | ⭐⭐⭐⭐ | 8h | 안전성 필수 |
| 6.4 롤백 및 클린업 | ⭐⭐⭐⭐ | 10h | 안전성 필수 |

**예상 총 작업량**: 88-93 시간

---

### 🟠 Medium-High Priority (2차 단계)
| 항목 | 임팩트 | 작업량 | 비고 |
|------|--------|--------|------|
| 1.2 고급 셸코드 기법 | ⭐⭐⭐⭐ | 15-20h | 기능 확장 |
| 1.3 네트워크 기반 기법 | ⭐⭐⭐⭐ | 20-25h | 커버리지 확대 |
| 2.3 PowerShell 품질 개선 | ⭐⭐⭐ | 6h | 코드 품질 |
| 3.1 단위 테스트 | ⭐⭐⭐⭐ | 15h | 품질 보증 |
| 5.2 CLI 개선 | ⭐⭐⭐ | 10h | 사용성 |

**예상 총 작업량**: 66-76 시간

---

### 🟡 Medium Priority (3차 단계)
| 항목 | 임팩트 | 작업량 | 비고 |
|------|--------|--------|------|
| 1.4 지속성 메커니즘 | ⭐⭐⭐ | 15h | 기능 확장 |
| 2.4 설정 관리 시스템 | ⭐⭐⭐ | 8h | 사용성 |
| 3.3 성능 벤치마킹 | ⭐⭐ | 8h | 최적화 |
| 4.1 HTML 대시보드 | ⭐⭐⭐ | 20h | 시각화 |
| 4.2 PDF 보고서 | ⭐⭐ | 12h | 리포팅 |
| 4.3 ATT&CK Navigator | ⭐⭐ | 6h | 통합 |
| 6.3 악용 방지 | ⭐⭐⭐ | 6h | 보안 |
| 7.1 API 문서 | ⭐⭐ | 6h | 문서화 |
| 7.2 사용자 가이드 | ⭐⭐⭐ | 12h | 문서화 |

**예상 총 작업량**: 93 시간

---

### 🟢 Low Priority (향후 고려)
| 항목 | 임팩트 | 작업량 | 비고 |
|------|--------|--------|------|
| 5.1 GUI 인터페이스 | ⭐⭐ | 25h | 선택적 |
| 5.3 대화형 모드 | ⭐⭐ | 8h | 선택적 |
| 7.3 기여 가이드 | ⭐ | 4h | 오픈소스화 시 |

**예상 총 작업량**: 37 시간

---

## 상세 스펙

### Phase 1: 기반 구축 (Foundation) - 4주

**목표**: 안정적이고 확장 가능한 기반 마련

#### Week 1-2: 코어 인프라
```
✓ 통합 로깅 시스템 구현
✓ 에러 처리 프레임워크 구축
✓ 설정 관리 시스템 개발
✓ RAII 패턴 적용
```

#### Week 3-4: 안전성 강화
```
✓ 샌드박스 탐지 구현
✓ 실행 환경 검증
✓ 롤백 메커니즘 구현
✓ PowerShell 코드 리팩토링
```

**산출물**:
- `include/logger.hpp`
- `include/error_handling.hpp`
- `include/config_manager.hpp`
- `include/environment_checker.hpp`
- `include/cleanup_manager.hpp`

---

### Phase 2: 기능 확장 (Feature Expansion) - 6주

**목표**: 공격 기법 커버리지 확대

#### Week 1-3: 새로운 기법 구현
```
✓ DLL Side-Loading
✓ Process Doppelgänging
✓ 난독화 기법
✓ 회피 기법
✓ Native API 실행
```

#### Week 4-6: 고급 기법
```
✓ Early Bird APC
✓ Module Stomping
✓ 네트워크 기반 기법
✓ 지속성 메커니즘
```

**산출물**:
- `samples/dll_sideloading/`
- `samples/obfuscation/`
- `samples/evasion/`
- `samples/network/`
- `samples/persistence/`

---

### Phase 3: 검증 및 테스트 (Validation & Testing) - 4주

**목표**: 품질 보증 및 자동화

#### Week 1-2: 테스트 프레임워크
```
✓ Google Test 통합
✓ 단위 테스트 작성
✓ Pester 테스트 구현
✓ CI/CD 파이프라인 구축
```

#### Week 3-4: EDR 검증
```
✓ ETW 이벤트 수집
✓ Sysmon 로그 파싱
✓ 탐지율 자동 계산
✓ 검증 보고서 생성
```

**산출물**:
- `tests/cpp/`
- `tests/powershell/`
- `include/detection_validator.hpp`
- `.github/workflows/ci.yml`

---

### Phase 4: 사용성 및 리포팅 (Usability & Reporting) - 3주

**목표**: 전문적인 사용자 경험

#### Week 1-2: 리포팅 시스템
```
✓ HTML 대시보드 개발
✓ PDF 보고서 생성
✓ ATT&CK Navigator 통합
✓ 실시간 모니터링
```

#### Week 3: CLI 및 문서화
```
✓ CLI 인터페이스 개선
✓ API 문서 생성
✓ 사용자 가이드 작성
✓ 예제 시나리오 추가
```

**산출물**:
- `reports/dashboard.html`
- `reports/generator.py`
- `docs/API.md`
- `docs/USER_GUIDE.md`

---

## 기술 스택

### C++
- **표준**: C++17/20
- **빌드 시스템**: CMake
- **테스트 프레임워크**: Google Test
- **로깅**: spdlog (고려)
- **JSON**: nlohmann/json

### PowerShell
- **버전**: PowerShell 7+
- **테스트**: Pester 5
- **린팅**: PSScriptAnalyzer
- **문서**: PlatyPS

### 웹 (리포팅)
- **프론트엔드**: HTML5, CSS3, JavaScript (ES6+)
- **차트**: Chart.js, D3.js
- **프레임워크**: Bootstrap 5
- **빌드**: Webpack (선택)

### 기타
- **문서**: Markdown, Doxygen
- **CI/CD**: GitHub Actions
- **버전 관리**: Git, Semantic Versioning

---

## 성공 지표 (KPI)

### 기능적 지표
- ✅ MITRE ATT&CK 기법 커버리지: 8개 → 25개+ (3배 증가)
- ✅ EDR 탐지율 자동 측정 정확도: 90%+
- ✅ 테스트 코드 커버리지: 70%+
- ✅ 지원 공격 카테고리: 3개 → 8개

### 품질 지표
- ✅ 에러 처리율: 100% (모든 에러 케이스 처리)
- ✅ 메모리 누수: 0건
- ✅ 코드 정적 분석 이슈: Critical 0건
- ✅ 문서화 완성도: 90%+

### 사용성 지표
- ✅ 설치 시간: 5분 이내
- ✅ 기본 테스트 실행 시간: 10분 이내
- ✅ 설정 커스터마이징 난이도: 초급자 수준
- ✅ 에러 메시지 명확성: 90%+ (사용자 이해도 기준)

### 안전성 지표
- ✅ 샌드박스 탐지율: 95%+
- ✅ 자동 롤백 성공률: 100%
- ✅ 오탐지율(실제 악성 행위): 0%
- ✅ 안전 장치 우회 시도 탐지: 100%

---

## 리스크 및 완화 전략

### 기술적 리스크

#### R1: Windows API 변경
**영향도**: Medium  
**발생 확률**: Low  
**완화 전략**:
- 여러 Windows 버전에서 테스트
- 대체 API 준비
- 버전별 조건부 컴파일

#### R2: EDR 오탐지
**영향도**: Medium  
**발생 확률**: Medium  
**완화 전략**:
- 테스트 전 명확한 경고
- 화이트리스트 등록 가이드
- EDR 제외 설정 문서

#### R3: 성능 저하
**영향도**: Low  
**발생 확률**: Medium  
**완화 전략**:
- 프로파일링 도구 사용
- 비동기 처리 적용
- 리소스 풀링

### 보안 리스크

#### R4: 도구 악용
**영향도**: High  
**발생 확률**: Medium  
**완화 전략**:
- 명확한 라이선스 및 경고
- 실행 환경 제한
- 감사 로그 생성
- 윤리적 사용 서약

#### R5: 코드 유출
**영향도**: Medium  
**발생 확률**: Low  
**완화 전략**:
- 오픈소스 정책 명확화
- 민감 정보 제외
- 안전한 저장소 관리

---

## 예상 일정 및 리소스

### 총 예상 기간: 17주 (약 4개월)

### 인력 구성
- **C++ 개발자**: 1-2명
- **PowerShell 개발자**: 1명
- **보안 전문가**: 1명 (파트타임)
- **QA/테스터**: 1명 (파트타임)
- **기술 작가**: 1명 (파트타임)

### 총 예상 공수
- **개발**: 280-300 시간
- **테스트**: 80-100 시간
- **문서화**: 40-50 시간
- **리뷰/수정**: 50-60 시간
- **총**: 450-510 시간

---

## 다음 단계 (Next Steps)

### 즉시 실행 가능 항목
1. ✅ 로깅 시스템 설계 문서 작성
2. ✅ 에러 코드 체계 정의
3. ✅ 설정 파일 스키마 설계
4. ✅ 테스트 환경 구축
5. ✅ CI/CD 파이프라인 초안

### 의사결정 필요 항목
- [ ] 오픈소스 공개 여부
- [ ] GUI 개발 우선순위
- [ ] 상용 라이브러리 사용 여부
- [ ] 외부 기여자 수용 정책

### 리소스 확보 필요 항목
- [ ] 테스트용 Windows VM
- [ ] 상용 EDR 라이선스 (테스트용)
- [ ] 코드 서명 인증서
- [ ] 문서화 도구 라이선스

---

## 부록

### A. 참고 자료
- MITRE ATT&CK Framework: https://attack.mitre.org/
- Windows API Documentation: https://docs.microsoft.com/windows/win32/
- Google C++ Style Guide: https://google.github.io/styleguide/cppguide.html
- PowerShell Best Practices: https://poshcode.gitbook.io/powershell-practice-and-style/

### B. 관련 프로젝트
- Atomic Red Team: https://github.com/redcanaryco/atomic-red-team
- CALDERA: https://github.com/mitre/caldera
- Infection Monkey: https://github.com/guardicore/monkey
- PurpleSharp: https://github.com/mvelazc0/PurpleSharp

### C. 기여자 가이드 (예시)
```markdown
## 새로운 기법 추가 방법

1. MITRE ATT&CK 기법 ID 확인
2. `samples/<category>/` 에 소스 파일 생성
3. README.md 작성 (한/영)
4. 단위 테스트 작성
5. detection_guide.md 업데이트
6. Pull Request 생성
```

---

## 문서 버전 이력

| 버전 | 날짜 | 변경 내역 | 작성자 |
|------|------|-----------|--------|
| 1.0 | 2025-10-14 | 초안 작성 | GitHub Copilot |

---

## 연락처 및 피드백

이 스펙 문서에 대한 피드백이나 제안사항이 있으시면 이슈를 생성해주세요.

**문서 끝**
