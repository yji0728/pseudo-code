# Configuration Management System

## 개요

EDR Testing Tools는 강력하고 유연한 설정 관리 시스템을 제공합니다. JSON 기반의 설정 파일을 통해 테스트 동작, 로깅, 안전 설정, 성능 모니터링 등 모든 측면을 세밀하게 제어할 수 있습니다.

## 주요 기능

- **프로파일 기반 설정**: 다양한 테스트 시나리오에 맞는 사전 정의된 프로파일
- **JSON 기반 저장소**: 사람이 읽기 쉬운 형식으로 설정 관리
- **환경 변수 오버라이드**: CI/CD 파이프라인에서 설정 동적 변경
- **실시간 설정 변경**: 런타임에 설정 값 수정 가능
- **타입 안전성**: 강력한 타입의 접근자 메서드
- **계층적 구조**: 8개의 주요 설정 카테고리로 체계적 관리

## 설정 파일 구조

### 기본 구조

```json
{
    "version": "1.0",
    "profile": "default",
    "execution": { ... },
    "logging": { ... },
    "test_scenarios": { ... },
    "safety": { ... },
    "performance": { ... },
    "detection": { ... },
    "reporting": { ... },
    "misc": { ... }
}
```

### 설정 카테고리

#### 1. Execution Settings (실행 설정)

테스트 실행과 관련된 기본 설정입니다.

```json
"execution": {
    "timeout_seconds": 60,
    "retry_count": 3,
    "delay_between_tests_ms": 1000,
    "max_concurrent_tests": 1,
    "stop_on_first_failure": false
}
```

**옵션 설명:**
- `timeout_seconds`: 각 테스트의 최대 실행 시간 (초)
- `retry_count`: 실패 시 재시도 횟수
- `delay_between_tests_ms`: 테스트 간 대기 시간 (밀리초)
- `max_concurrent_tests`: 동시 실행 가능한 테스트 수
- `stop_on_first_failure`: 첫 번째 실패 시 중단 여부

#### 2. Logging Settings (로깅 설정)

로깅 동작을 제어합니다.

```json
"logging": {
    "level": "INFO",
    "output_file": "logs/edr_test.log",
    "format": "json",
    "max_file_size_mb": 10,
    "max_files": 5,
    "console_output": true,
    "include_timestamp": true
}
```

**로깅 레벨:**
- `TRACE`: 모든 상세 정보
- `DEBUG`: 디버깅 정보
- `INFO`: 일반 정보 (기본값)
- `WARNING`: 경고 메시지
- `ERROR`: 오류 메시지
- `CRITICAL`: 치명적 오류만

**로그 포맷:**
- `json`: JSON 형식 (기본값, 파싱 용이)
- `text`: 일반 텍스트 형식
- `xml`: XML 형식

#### 3. Test Scenarios (테스트 시나리오)

실행할 테스트 시나리오와 기법을 정의합니다.

```json
"test_scenarios": {
    "process_injection": {
        "enabled": true,
        "techniques": [
            "T1055.001",  // DLL Injection
            "T1055.012"   // Process Hollowing
        ]
    },
    "fileless": {
        "enabled": true,
        "techniques": [
            "memory_execution",
            "wmi_execution"
        ]
    }
}
```

**지원 시나리오:**
- `process_injection`: 프로세스 인젝션 기법
- `fileless`: 파일리스 실행 기법
- `shellcode`: 쉘코드 실행 기법
- `combined`: 복합 공격 시나리오

#### 4. Safety Settings (안전 설정)

테스트 실행의 안전성을 보장하는 설정입니다.

```json
"safety": {
    "require_confirmation": true,
    "sandbox_check": true,
    "allowed_targets": [
        "notepad.exe",
        "calc.exe"
    ],
    "max_execution_time_minutes": 30,
    "enable_cleanup": true
}
```

**옵션 설명:**
- `require_confirmation`: 실행 전 사용자 확인 필요
- `sandbox_check`: 샌드박스 환경 자동 감지
- `allowed_targets`: 허용된 대상 프로세스 목록
- `max_execution_time_minutes`: 전체 테스트의 최대 실행 시간
- `enable_cleanup`: 테스트 후 자동 정리 활성화

#### 5. Performance Monitoring (성능 모니터링)

성능 측정 및 내보내기 설정입니다.

```json
"performance": {
    "enable_monitoring": true,
    "export_format": "json",
    "export_path": "reports/performance",
    "collect_cpu_usage": true,
    "collect_memory_usage": true,
    "collect_io_stats": true
}
```

#### 6. Detection Validation (탐지 검증)

EDR 탐지 검증 설정입니다.

```json
"detection": {
    "enable_validation": true,
    "etw_providers": [
        "Microsoft-Windows-Kernel-Process",
        "Microsoft-Windows-Threat-Intelligence"
    ],
    "sysmon_enabled": true,
    "windows_event_logs": true
}
```

#### 7. Reporting Settings (보고서 설정)

보고서 생성 설정입니다.

```json
"reporting": {
    "auto_generate": true,
    "formats": ["html", "json", "csv"],
    "output_directory": "reports",
    "include_screenshots": false,
    "include_raw_data": true
}
```

**보고서 포맷:**
- `html`: HTML 대시보드 (권장)
- `json`: JSON 형식 (API 통합 용이)
- `csv`: CSV 형식 (Excel 호환)
- `txt`: 텍스트 형식
- `xml`: XML 형식

#### 8. Miscellaneous (기타)

기타 설정들입니다.

```json
"misc": {
    "auto_update_check": true,
    "telemetry_enabled": false,
    "debug_mode": false
}
```

## 프로파일

### 기본 프로파일 (default)

안전하고 보수적인 설정으로, 일반적인 테스트에 적합합니다.

```json
{
    "profile": "default",
    "execution": {
        "timeout_seconds": 60,
        "retry_count": 3
    },
    "safety": {
        "require_confirmation": true,
        "sandbox_check": true
    },
    "logging": {
        "level": "INFO"
    }
}
```

**사용 시나리오:**
- 초기 테스트
- 프로덕션 유사 환경
- 안전성이 중요한 경우

### Aggressive 프로파일

모든 기능을 활성화한 포괄적인 테스트 프로파일입니다.

```json
{
    "profile": "aggressive",
    "execution": {
        "timeout_seconds": 120,
        "retry_count": 5,
        "max_concurrent_tests": 3
    },
    "safety": {
        "require_confirmation": false,
        "sandbox_check": false
    },
    "logging": {
        "level": "DEBUG"
    }
}
```

**사용 시나리오:**
- 포괄적인 EDR 테스트
- 자동화된 CI/CD 파이프라인
- 고급 사용자

### Custom 프로파일

사용자 정의 프로파일을 만들 수 있습니다.

```bash
# 기본 설정을 복사하여 수정
cp config.json config_custom.json

# 설정 파일 편집
notepad config_custom.json

# 프로파일 사용
edr-cli profile use custom
```

## ConfigManager API

### 기본 사용법

```cpp
#include "config_manager.hpp"

using namespace EDR;

// 싱글톤 인스턴스 가져오기
ConfigManager& config = ConfigManager::Instance();

// 설정 파일 로드
config.LoadFromFile("config.json");

// 설정 값 읽기
int timeout = config.GetExecutionTimeout();
std::string logLevel = config.GetLoggingLevel();
bool requireConfirm = config.GetRequireConfirmation();

// 설정 값 쓰기
config.SetValue("execution.timeout_seconds", 90);
config.SetValue("logging.level", "DEBUG");

// 파일로 저장
config.SaveToFile("config_modified.json");
```

### 프로파일 관리

```cpp
// 프로파일 전환
config.LoadFromFile("config_aggressive.json");
config.SetProfile("aggressive");

// 현재 프로파일 확인
std::string currentProfile = config.GetProfile();

// 프로파일별 설정 저장
config.SaveToFile("config.json");
```

### 시나리오 및 기법 관리

```cpp
// 시나리오 활성화 확인
bool enabled = config.IsScenarioEnabled("process_injection");

// 활성화된 기법 목록 가져오기
std::vector<std::string> techniques = 
    config.GetEnabledTechniques("process_injection");

// 모든 활성화된 기법 가져오기
std::vector<std::string> allTechniques = 
    config.GetAllEnabledTechniques();

// 기법 추가
config.AddTechnique("process_injection", "T1055.013");
```

### 환경 변수 오버라이드

```cpp
// 환경 변수 설정
SetEnvironmentVariable("EDR_CONFIG_TIMEOUT", "180");
SetEnvironmentVariable("EDR_CONFIG_LOG_LEVEL", "TRACE");

// 환경 변수 적용
config.ApplyEnvironmentVariableOverrides();

// 이제 설정이 환경 변수 값으로 오버라이드됨
int newTimeout = config.GetExecutionTimeout(); // 180
```

### 설정 요약 출력

```cpp
// 현재 설정 요약 출력
config.PrintSummary();
```

출력 예제:
```
=== Configuration Summary ===

Profile: default
Version: 1.0

Execution Settings:
  Timeout: 60s
  Retry: 3
  Delay: 1000ms
  Max Concurrent: 1
  Stop on Failure: No

Logging Settings:
  Level: INFO
  Output: logs/edr_test.log
  Format: json
  ...
```

## CLI 도구 사용법

### edr-cli 명령어

#### 기법 실행

```bash
# 단일 기법 실행
edr-cli run --technique T1055.001

# 여러 기법 실행
edr-cli run --techniques T1055.001,T1055.012

# 시나리오 전체 실행
edr-cli run --scenario process_injection

# 특정 프로파일로 실행
edr-cli run --profile aggressive --scenario process_injection

# 출력 파일 지정
edr-cli run --technique T1055.001 --output report.json
```

#### 목록 조회

```bash
# 사용 가능한 기법 목록
edr-cli list techniques

# 프로파일 목록
edr-cli list profiles

# 시나리오 목록
edr-cli list scenarios
```

#### 설정 관리

```bash
# 현재 설정 표시
edr-cli config show

# 설정 값 변경
edr-cli config set execution.timeout_seconds 120
edr-cli config set logging.level DEBUG

# 설정 파일 지정
edr-cli config --config custom_config.json show
```

#### 프로파일 관리

```bash
# 프로파일 목록
edr-cli profile list

# 프로파일 전환
edr-cli profile use aggressive

# 현재 프로파일 확인
edr-cli profile show
```

#### 보고서 생성

```bash
# HTML 보고서 생성
edr-cli report --format html

# JSON 보고서 생성
edr-cli report --format json --output report.json

# 모든 형식으로 보고서 생성
edr-cli report --format all
```

#### 탐지 검증

```bash
# EDR 로그로 탐지 검증
edr-cli validate --edr-logs C:\logs\edr.json

# Sysmon 로그로 검증
edr-cli validate --sysmon-logs C:\logs\sysmon.xml
```

### 대화형 모드

```bash
# 대화형 설정 관리
config_demo.exe --interactive
```

대화형 메뉴:
```
╔═══════════════════════════════════════╗
║       Configuration Manager           ║
╠═══════════════════════════════════════╣
║  1. Show Current Configuration        ║
║  2. Switch Profile                    ║
║  3. List Scenarios                    ║
║  4. Modify Setting                    ║
║  5. Save Configuration                ║
║  6. Run All Demos                     ║
║  0. Exit                              ║
╚═══════════════════════════════════════╝
```

## 환경 변수 레퍼런스

ConfigManager는 다음 환경 변수를 지원합니다:

| 환경 변수 | 설정 경로 | 설명 |
|----------|----------|------|
| `EDR_CONFIG_FILE` | - | 설정 파일 경로 |
| `EDR_CONFIG_PROFILE` | `profile` | 프로파일 이름 |
| `EDR_CONFIG_TIMEOUT` | `execution.timeout_seconds` | 실행 타임아웃 |
| `EDR_CONFIG_RETRY` | `execution.retry_count` | 재시도 횟수 |
| `EDR_CONFIG_LOG_LEVEL` | `logging.level` | 로깅 레벨 |
| `EDR_CONFIG_LOG_FILE` | `logging.output_file` | 로그 파일 경로 |
| `EDR_CONFIG_REQUIRE_CONFIRM` | `safety.require_confirmation` | 확인 필요 여부 |
| `EDR_CONFIG_SANDBOX_CHECK` | `safety.sandbox_check` | 샌드박스 체크 |

### 사용 예제

PowerShell:
```powershell
$env:EDR_CONFIG_TIMEOUT = "180"
$env:EDR_CONFIG_LOG_LEVEL = "DEBUG"
$env:EDR_CONFIG_REQUIRE_CONFIRM = "false"

.\edr-cli.exe run --scenario process_injection
```

Bash:
```bash
export EDR_CONFIG_TIMEOUT=180
export EDR_CONFIG_LOG_LEVEL=DEBUG
export EDR_CONFIG_REQUIRE_CONFIRM=false

./edr-cli run --scenario process_injection
```

CI/CD 파이프라인:
```yaml
# GitHub Actions 예제
env:
  EDR_CONFIG_PROFILE: aggressive
  EDR_CONFIG_TIMEOUT: 300
  EDR_CONFIG_REQUIRE_CONFIRM: false

steps:
  - name: Run EDR Tests
    run: |
      edr-cli run --scenario process_injection
      edr-cli report --format html
```

## 고급 사용 사례

### 1. 커스텀 테스트 워크플로우

```cpp
ConfigManager& config = ConfigManager::Instance();

// 커스텀 프로파일 로드
config.LoadFromFile("config_custom.json");

// 특정 시나리오만 활성화
config.SetValue("test_scenarios.process_injection.enabled", true);
config.SetValue("test_scenarios.fileless.enabled", false);

// 타임아웃 증가
config.SetValue("execution.timeout_seconds", 300);

// 디버그 로깅 활성화
config.SetValue("logging.level", "DEBUG");

// 설정 저장
config.SaveToFile("config_custom.json");

// 활성화된 기법으로 테스트 실행
auto techniques = config.GetAllEnabledTechniques();
for (const auto& tech : techniques) {
    // 기법 실행 코드
}
```

### 2. 프로그래밍 방식 설정 관리

```cpp
class TestExecutor {
private:
    ConfigManager& config_;
    
public:
    TestExecutor() : config_(ConfigManager::Instance()) {
        // 초기 설정
        config_.LoadFromFile("config.json");
    }
    
    void RunConservativeTests() {
        config_.SetProfile("default");
        config_.SetValue("safety.require_confirmation", true);
        // 테스트 실행
    }
    
    void RunAggressiveTests() {
        config_.SetProfile("aggressive");
        config_.SetValue("execution.max_concurrent_tests", 5);
        // 테스트 실행
    }
    
    void RunWithCustomConfig(const std::string& configFile) {
        config_.LoadFromFile(configFile);
        config_.ApplyEnvironmentVariableOverrides();
        // 테스트 실행
    }
};
```

### 3. 조건부 설정

```cpp
ConfigManager& config = ConfigManager::Instance();

// 운영 체제에 따른 설정
if (IsWindows10()) {
    config.SetValue("detection.etw_providers", 
        json::array({
            "Microsoft-Windows-Kernel-Process",
            "Microsoft-Windows-Threat-Intelligence"
        }));
} else {
    config.SetValue("detection.sysmon_enabled", true);
}

// 권한에 따른 설정
if (IsElevated()) {
    config.SetValue("test_scenarios.process_injection.enabled", true);
} else {
    config.SetValue("test_scenarios.fileless.enabled", true);
}
```

## 문제 해결

### 설정 파일을 찾을 수 없음

```cpp
if (!config.LoadFromFile("config.json")) {
    // 기본 설정 사용
    config.LoadDefaults();
    // 또는 새 설정 파일 생성
    config.SaveToFile("config.json");
}
```

### 잘못된 JSON 형식

```cpp
try {
    config.LoadFromFile("config.json");
} catch (const json::parse_error& e) {
    std::cerr << "Invalid JSON: " << e.what() << std::endl;
    // 백업에서 복원 또는 기본값 사용
    config.LoadDefaults();
}
```

### 환경 변수가 적용되지 않음

```cpp
// 설정 파일 로드 후 환경 변수 적용 필요
config.LoadFromFile("config.json");
config.ApplyEnvironmentVariableOverrides(); // 이 줄 추가!
```

## 베스트 프랙티스

### 1. 프로파일 사용

특정 사용 사례에 맞는 프로파일을 만들고 사용하세요:

- `default`: 일반적인 테스트
- `aggressive`: 포괄적인 테스트
- `ci`: CI/CD 파이프라인용
- `production`: 프로덕션 테스트용

### 2. 설정 버전 관리

설정 파일을 Git에 커밋하여 버전 관리하세요:

```bash
git add config.json config_aggressive.json
git commit -m "Add default and aggressive test profiles"
```

### 3. 환경별 설정

다른 환경에서는 환경 변수를 사용하세요:

```bash
# 개발 환경
export EDR_CONFIG_LOG_LEVEL=DEBUG

# 프로덕션 환경
export EDR_CONFIG_LOG_LEVEL=INFO
export EDR_CONFIG_REQUIRE_CONFIRM=true
```

### 4. 설정 검증

중요한 설정은 항상 검증하세요:

```cpp
int timeout = config.GetExecutionTimeout();
if (timeout < 10 || timeout > 600) {
    throw std::runtime_error("Invalid timeout value");
}
```

### 5. 설정 문서화

커스텀 설정에 주석을 추가하세요:

```json
{
    "_comment": "Custom configuration for CI/CD pipeline",
    "profile": "ci",
    "execution": {
        "_comment": "Increased timeout for slow CI runners",
        "timeout_seconds": 300
    }
}
```

## 추가 리소스

- [QUICKSTART.md](QUICKSTART.md): 빠른 시작 가이드
- [ENHANCEMENT_SPEC.md](../ENHANCEMENT_SPEC.md): 향상 사항 명세
- [config_demo.cpp](../samples/config_demo.cpp): 데모 프로그램 소스 코드
- [config.json](../config.json): 기본 설정 파일
- [config_aggressive.json](../config_aggressive.json): Aggressive 프로파일

## 지원

문제가 발생하거나 질문이 있으시면:

1. 이 문서의 문제 해결 섹션 확인
2. config_demo.exe를 실행하여 데모 확인
3. GitHub Issues에 문제 보고

---

**마지막 업데이트**: 2024-01-XX  
**버전**: 1.0  
**작성자**: EDR Testing Tools Team
