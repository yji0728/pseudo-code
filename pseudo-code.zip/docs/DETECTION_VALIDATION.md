# EDR Detection Validation System

## 📋 개요

EDR Detection Validation System은 EDR 솔루션의 탐지 능력을 자동으로 검증하고 측정하는 종합 시스템입니다. 여러 이벤트 소스(ETW, Sysmon, Windows Event Log)에서 데이터를 수집하여 공격 기법의 탐지 여부를 자동으로 판단합니다.

## ✨ 주요 기능

### 1. 다중 소스 이벤트 수집
- **ETW (Event Tracing for Windows)**: 커널 레벨 이벤트 실시간 수집
- **Sysmon**: 상세한 프로세스/네트워크 활동 로깅
- **Windows Event Log**: 시스템 보안 이벤트 분석

### 2. 자동 탐지 검증
- MITRE ATT&CK 기법 ID 기반 검증
- 탐지 지표(Indicator) 자동 매칭
- 탐지 신뢰도(Confidence) 계산
- 심각도(Severity) 평가

### 3. 성능 측정
- 탐지 지연시간(Detection Latency) 측정
- 탐지율(Detection Rate) 통계
- 이벤트 상관관계 분석

### 4. 종합 리포팅
- JSON/CSV 형식 보고서 export
- HTML 대시보드 (향후 구현)
- 상세 타임라인 분석

## 🏗️ 아키텍처

```
┌─────────────────────────────────────────────────────────────┐
│                    Detection Validator                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ ETW Provider │  │    Sysmon    │  │  Event Log   │    │
│  │   Collector  │  │    Parser    │  │    Parser    │    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘    │
│         │                  │                  │            │
│         └──────────────────┴──────────────────┘            │
│                           │                                │
│                   ┌───────▼───────┐                       │
│                   │ Event Storage │                       │
│                   └───────┬───────┘                       │
│                           │                                │
│         ┌─────────────────┴─────────────────┐             │
│         │                                   │             │
│  ┌──────▼──────┐                  ┌─────────▼────────┐   │
│  │  Technique  │                  │    Detection     │   │
│  │   Matcher   │                  │  Scoring Engine  │   │
│  └──────┬──────┘                  └─────────┬────────┘   │
│         │                                   │             │
│         └───────────────┬───────────────────┘             │
│                         │                                 │
│                  ┌──────▼──────┐                         │
│                  │   Reporter  │                         │
│                  └─────────────┘                         │
└─────────────────────────────────────────────────────────────┘
```

## 📊 데이터 구조

### DetectionResult
```cpp
struct DetectionResult {
    std::string technique;              // T1055.001
    std::string techniqueName;          // DLL Injection
    bool detected;                      // true/false
    std::vector<std::string> detectionMethods;  // ["ETW", "Sysmon"]
    std::chrono::milliseconds detectionLatency;  // 탐지 시간
    std::string severity;               // Low/Medium/High/Critical
    std::string confidence;             // Low/Medium/High
    double detectionScore;              // 0.0 ~ 1.0
    
    std::vector<ETWEvent> etwEvents;
    std::vector<SysmonEvent> sysmonEvents;
    std::vector<WindowsEvent> windowsEvents;
};
```

### DetectionReport
```cpp
struct DetectionReport {
    int totalTechniques;
    int detectedTechniques;
    double overallDetectionRate;        // 전체 탐지율
    
    std::chrono::milliseconds averageDetectionLatency;
    std::chrono::milliseconds minDetectionLatency;
    std::chrono::milliseconds maxDetectionLatency;
    
    std::map<std::string, int> detectionMethodCounts;
    std::map<std::string, double> techniqueDetectionRates;
};
```

## 🚀 사용법

### 기본 사용 예제

```cpp
#include "detection_validator.hpp"

using namespace EDR;

int main() {
    DetectionValidator validator;
    
    // 1. 모니터링 시작
    validator.StartMonitoring();
    
    // 2. 공격 기법 실행
    // ... execute technique ...
    
    // 3. 탐지 검증
    auto result = validator.ValidateTechnique("T1055.001");
    
    // 4. 모니터링 중지
    validator.StopMonitoring();
    
    // 5. 결과 확인
    if (result.detected) {
        std::cout << "Detected by: ";
        for (const auto& method : result.detectionMethods) {
            std::cout << method << " ";
        }
        std::cout << "\nDetection Score: " << result.detectionScore << "\n";
    }
    
    // 6. 보고서 생성
    auto report = validator.GenerateReport();
    report.ExportToCSV("report.csv");
    
    return 0;
}
```

### 고급 사용 예제

#### 1. 여러 기법 일괄 검증

```cpp
DetectionValidator validator;

// ETW 프로바이더 활성화
std::map<GUID, std::wstring> providers = {
    {ETWProviders::KernelProcess, L"Kernel-Process"},
    {ETWProviders::KernelFile, L"Kernel-File"},
    {ETWProviders::SecurityAuditing, L"Security-Auditing"}
};
validator.EnableETWProviders(providers);

validator.StartMonitoring();

// 여러 기법 테스트
std::vector<std::string> techniques = {
    "T1055.001",  // DLL Injection
    "T1055.012",  // Process Hollowing
    "T1055.004"   // APC Injection
};

auto results = validator.ValidateTechniques(techniques);

validator.StopMonitoring();

// 통계 출력
auto report = validator.GenerateReport();
std::cout << "Detection Rate: " 
          << (report.overallDetectionRate * 100.0) << "%\n";
```

#### 2. 실시간 모니터링

```cpp
DetectionValidator validator;

// 실시간 콜백 설정
validator.SetRealtimeCallback([](const ETWEvent& event) {
    std::wcout << L"Event: " << event.eventName 
               << L" (PID: " << event.processId << L")\n";
});

validator.SetVerboseLogging(true);
validator.StartMonitoring();

// 모니터링 중...
std::this_thread::sleep_for(std::chrono::seconds(60));

validator.StopMonitoring();

// 수집된 이벤트 확인
auto events = validator.GetETWEvents();
std::cout << "Total events: " << events.size() << "\n";
```

#### 3. 프로세스 ID로 검증

```cpp
DetectionValidator validator;

validator.StartMonitoring();

// 특정 프로세스 실행
DWORD targetPid = LaunchTargetProcess();

// 해당 프로세스 관련 탐지 검증
auto result = validator.ValidateByProcessId(targetPid);

validator.StopMonitoring();

std::cout << "Events for PID " << targetPid << ": " 
          << result.etwEvents.size() << "\n";
```

#### 4. 시간 범위 지정 보고서

```cpp
DetectionValidator validator;

auto startTime = std::chrono::system_clock::now();

validator.StartMonitoring();

// 테스트 실행...

auto endTime = std::chrono::system_clock::now();

validator.StopMonitoring();

// 특정 시간 범위의 보고서
auto report = validator.GenerateReport(startTime, endTime);

// JSON 내보내기
std::string json = report.ExportToJSON();
std::ofstream file("report.json");
file << json;
file.close();
```

## 📖 API 레퍼런스

### DetectionValidator 클래스

#### 모니터링 제어

```cpp
bool StartMonitoring();
```
- 이벤트 모니터링 시작
- **반환**: 성공 시 true
- **요구사항**: 관리자 권한 필요

```cpp
bool StopMonitoring();
```
- 이벤트 모니터링 중지
- **반환**: 성공 시 true

```cpp
bool IsMonitoring() const;
```
- 현재 모니터링 상태 확인
- **반환**: 모니터링 중이면 true

#### ETW 제어

```cpp
bool EnableETWProvider(const GUID& providerId, const std::wstring& providerName);
```
- ETW 프로바이더 활성화
- **매개변수**:
  - `providerId`: 프로바이더 GUID
  - `providerName`: 이름 (로깅용)
- **반환**: 성공 시 true

```cpp
int EnableETWProviders(const std::map<GUID, std::wstring>& providers);
```
- 여러 ETW 프로바이더 일괄 활성화
- **반환**: 성공한 개수

#### 이벤트 수집

```cpp
std::vector<SysmonEvent> ParseSysmonLogs(
    const std::chrono::system_clock::time_point& startTime);
```
- Sysmon 로그 파싱
- **매개변수**: 시작 시간 (이 시간 이후의 이벤트만)
- **반환**: Sysmon 이벤트 목록

```cpp
std::vector<WindowsEvent> ParseWindowsEventLog(
    const std::wstring& logName,
    const std::chrono::system_clock::time_point& startTime);
```
- Windows Event Log 파싱
- **매개변수**:
  - `logName`: 로그 이름 ("Security", "System" 등)
  - `startTime`: 시작 시간
- **반환**: Windows 이벤트 목록

```cpp
std::vector<ETWEvent> GetETWEvents() const;
```
- 수집된 ETW 이벤트 가져오기
- **반환**: ETW 이벤트 목록

#### 탐지 검증

```cpp
DetectionResult ValidateTechnique(const std::string& techniqueName);
```
- 특정 기법의 탐지 여부 검증
- **매개변수**: 기법 이름 또는 ID (예: "T1055.001", "dll_injection")
- **반환**: 탐지 결과

```cpp
std::vector<DetectionResult> ValidateTechniques(
    const std::vector<std::string>& techniqueNames);
```
- 여러 기법 일괄 검증
- **반환**: 탐지 결과 목록

```cpp
DetectionResult ValidateByProcessId(DWORD processId);
```
- 프로세스 ID로 탐지 검증
- **반환**: 해당 프로세스 관련 탐지 결과

#### 보고서 생성

```cpp
DetectionReport GenerateReport();
```
- 전체 탐지 보고서 생성
- **반환**: 종합 보고서

```cpp
DetectionReport GenerateReport(
    const std::chrono::system_clock::time_point& startTime,
    const std::chrono::system_clock::time_point& endTime);
```
- 특정 기간의 보고서 생성
- **반환**: 기간별 보고서

#### 설정

```cpp
void SetDetectionTimeout(std::chrono::milliseconds timeout);
```
- 탐지 타임아웃 설정

```cpp
void SetVerboseLogging(bool enable);
```
- 상세 로깅 활성화/비활성화

```cpp
void SetRealtimeCallback(std::function<void(const ETWEvent&)> callback);
```
- 실시간 이벤트 콜백 등록

#### 유틸리티

```cpp
static bool IsSysmonInstalled();
```
- Sysmon 설치 여부 확인

```cpp
static bool IsElevated();
```
- 관리자 권한 여부 확인

### TechniqueDatabase 클래스

```cpp
static TechniqueInfo GetTechniqueInfo(const std::string& techniqueId);
```
- 기법 정보 가져오기

```cpp
static std::vector<TechniqueInfo> GetAllTechniques();
```
- 지원하는 모든 기법 목록

```cpp
static bool IsTechniqueSupported(const std::string& techniqueId);
```
- 기법 지원 여부 확인

## 🔍 지원하는 기법

### T1055.001 - DLL Injection
- **전술**: Defense Evasion
- **탐지 지표**:
  - CreateRemoteThread API 호출
  - VirtualAllocEx with PAGE_EXECUTE_READWRITE
  - WriteProcessMemory to remote process
  - LoadLibrary in remote process
- **Sysmon Event ID**: 8 (CreateRemoteThread), 10 (ProcessAccess)

### T1055.012 - Process Hollowing
- **전술**: Defense Evasion
- **탐지 지표**:
  - Process created in suspended state
  - UnmapViewOfSection call
  - VirtualAllocEx in remote process
  - WriteProcessMemory to overwrite image
  - SetThreadContext to update entry point
  - ResumeThread to start execution
- **Sysmon Event ID**: 1 (ProcessCreate), 10 (ProcessAccess)

### T1055.004 - Asynchronous Procedure Call
- **전술**: Defense Evasion
- **탐지 지표**:
  - QueueUserAPC API call
  - VirtualAllocEx with executable memory
  - WriteProcessMemory
  - Thread enumeration
- **Sysmon Event ID**: 8, 10

## 📊 탐지 점수 계산

DetectionValidator는 다음 요소를 기반으로 0.0 ~ 1.0의 탐지 점수를 계산합니다:

```
Detection Score = (
    ETW Events × 0.3 +
    Sysmon Events × 0.4 +
    Windows Events × 0.2 +
    Detection Method Diversity × 0.1
) / 10.0
```

### 신뢰도(Confidence) 결정
- **High**: Detection Score ≥ 0.8
- **Medium**: 0.5 ≤ Detection Score < 0.8
- **Low**: Detection Score < 0.5

## 📈 리포트 형식

### JSON 형식

```json
{
  "summary": {
    "totalTechniques": 3,
    "detectedTechniques": 2,
    "overallDetectionRate": 0.6667,
    "averageDetectionLatencyMs": 1250
  },
  "results": [
    {
      "technique": "T1055.001",
      "techniqueName": "DLL Injection",
      "detected": true,
      "detectionMethods": ["ETW", "Sysmon"],
      "detectionLatencyMs": 1200,
      "severity": "High",
      "confidence": "High",
      "detectionScore": 0.85,
      "totalIndicators": 4,
      "triggeredIndicators": 3,
      "etwEventCount": 5,
      "sysmonEventCount": 2,
      "windowsEventCount": 1
    }
  ]
}
```

### CSV 형식

```csv
Technique,Technique Name,Detected,Detection Methods,Latency (ms),Severity,Confidence,Score,ETW Events,Sysmon Events,Windows Events
T1055.001,DLL Injection,Yes,"ETW;Sysmon",1200,High,High,0.85,5,2,1
T1055.012,Process Hollowing,Yes,"Sysmon",1300,High,Medium,0.65,0,3,0
T1055.004,APC Injection,No,"",0,High,Low,0.0,0,0,0
```

## ⚙️ 시스템 요구사항

### 필수 요구사항
- **OS**: Windows 10/11 or Windows Server 2016+
- **권한**: Administrator (ETW 수집 시)
- **빌드**: Visual Studio 2019+ with C++17 support

### 선택적 요구사항
- **Sysmon**: 상세한 프로세스/네트워크 모니터링
  - 다운로드: https://docs.microsoft.com/sysinternals/downloads/sysmon
  - 설치: `sysmon64.exe -accepteula -i`

## 🔧 빌드 방법

```powershell
# detection_validator.cpp와 함께 컴파일
cl.exe /EHsc /W4 /std:c++17 /nologo ^
    /I..\include ^
    detection_validation_demo.cpp ^
    ..\src\detection_validator.cpp ^
    /Fe:detection_validation_demo.exe ^
    /link /SUBSYSTEM:CONSOLE ^
    tdh.lib advapi32.lib wevtapi.lib
```

또는 build.ps1 스크립트 사용:
```powershell
.\scripts\build.ps1
```

## 🎯 활용 예시

### 1. EDR 제품 비교
여러 EDR 솔루션을 동일한 환경에서 테스트하여 탐지율 비교

### 2. EDR 설정 최적화
다양한 EDR 설정을 테스트하여 최적의 구성 찾기

### 3. 공격 시나리오 검증
레드팀 작전 후 블루팀의 탐지 능력 평가

### 4. 지속적 모니터링
정기적으로 탐지 능력 테스트하여 추세 분석

### 5. 규정 준수(Compliance)
MITRE ATT&CK 커버리지 문서화

## ⚠️ 주의사항

### 보안 고려사항
1. **테스트 환경에서만 사용**: 프로덕션 시스템에서 사용 금지
2. **격리된 네트워크**: 실제 공격과 구분하기 위해 격리된 환경 권장
3. **사전 승인**: 모든 테스트는 사전 승인 후 진행
4. **로깅**: 모든 활동이 로깅되므로 감사 추적 가능

### 성능 고려사항
1. **ETW 오버헤드**: ETW 수집은 시스템 성능에 영향
2. **메모리 사용**: 장시간 모니터링 시 메모리 사용량 증가
3. **디스크 I/O**: 많은 이벤트 로깅 시 디스크 I/O 증가

### 제한사항
1. **ETW 프로바이더**: 일부 프로바이더는 추가 권한 필요
2. **Sysmon 의존성**: Sysmon 미설치 시 일부 기능 제한
3. **Windows 버전**: 일부 ETW 프로바이더는 특정 Windows 버전에서만 사용 가능

## 🔮 향후 개발 계획

### Phase 1 (현재)
- [x] 기본 ETW 이벤트 수집
- [x] Sysmon 로그 파싱
- [x] 기본 탐지 검증
- [x] JSON/CSV 리포트

### Phase 2 (개발 중)
- [ ] 실시간 ETW 이벤트 처리
- [ ] 고급 이벤트 상관관계 분석
- [ ] 머신러닝 기반 탐지 점수
- [ ] HTML 대시보드

### Phase 3 (계획)
- [ ] 클라우드 EDR 지원
- [ ] SIEM 통합
- [ ] 자동화된 대응(Response)
- [ ] 벤치마크 데이터베이스

## 📚 참고 자료

### ETW (Event Tracing for Windows)
- [ETW Overview](https://docs.microsoft.com/windows/win32/etw/about-event-tracing)
- [ETW Providers](https://docs.microsoft.com/windows/win32/etw/providers)

### Sysmon
- [Sysmon Documentation](https://docs.microsoft.com/sysinternals/downloads/sysmon)
- [Sysmon Event IDs](https://docs.microsoft.com/sysinternals/downloads/sysmon#events)

### MITRE ATT&CK
- [ATT&CK Framework](https://attack.mitre.org/)
- [Defense Evasion Techniques](https://attack.mitre.org/tactics/TA0005/)

### Windows Event Log
- [Windows Security Events](https://docs.microsoft.com/windows/security/threat-protection/auditing/security-auditing-overview)

## 📞 지원 및 기여

### 문제 보고
GitHub Issues를 통해 버그나 기능 요청 제출

### 기여 방법
1. 새로운 기법 추가: `TechniqueDatabase::InitializeDatabase()` 수정
2. ETW 프로바이더 추가: `ETWProviders` namespace에 GUID 추가
3. 탐지 로직 개선: `MatchesTechnique()` 함수 수정
4. 문서 개선: 이 문서 업데이트

---

**Last Updated**: 2025-10-15  
**Version**: 1.0.0  
**Author**: EDR Testing Tools Team
