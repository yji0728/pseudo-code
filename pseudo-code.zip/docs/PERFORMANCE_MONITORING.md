# Performance Monitoring System Documentation
## EDR Testing Tools - Performance Benchmarking

### 📊 Overview

This document describes the performance monitoring system integrated into the EDR Testing Tools project. The system provides comprehensive performance metrics for evaluating EDR evasion techniques.

**Version:** 1.0  
**Category:** Testing & Validation (ENHANCEMENT_SPEC.md - Category 3.3)  
**Status:** ✅ Implemented

---

### 🎯 Purpose

The Performance Monitoring System addresses the critical need to:

1. **Measure Execution Time**: Track how long each technique takes to execute
2. **Monitor Resource Usage**: Record memory, CPU, and disk I/O consumption
3. **Compare Techniques**: Provide data for comparing different approaches
4. **Identify Bottlenecks**: Help optimize performance-critical code
5. **Generate Reports**: Export data in CSV and JSON formats for analysis

---

### 📦 Components

#### 1. Core Header File
**Location:** `include/performance_monitor.hpp`  
**Lines of Code:** 630+  
**Dependencies:** `logger.hpp`, `error_handling.hpp`, Windows APIs (psapi.h, pdh.h)

#### 2. Demo Application
**Location:** `demos/performance_demo.cpp`  
**Purpose:** Demonstrate all monitoring capabilities  
**Tests Included:** Memory allocation, CPU intensive, Disk I/O, Process creation

#### 3. Enhanced Samples
**Location:** `samples/process_injection/dll_injection_v3.cpp`  
**Purpose:** Real-world integration example  
**Features:** Combines v2 enhancements + performance tracking

---

### 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Application Code                       │
│              (EDR Evasion Techniques)                    │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ Uses
                     ▼
┌─────────────────────────────────────────────────────────┐
│          PerformanceMonitor Class                        │
│  ┌────────────────────────────────────────────────┐    │
│  │  StartMeasurement()                             │    │
│  │  - Initialize counters                          │    │
│  │  - Record start time                            │    │
│  │  - Get baseline metrics                         │    │
│  └─────────────────┬──────────────────────────────┘    │
│                    │                                     │
│        [Code execution with monitoring]                 │
│                    │                                     │
│  ┌─────────────────▼──────────────────────────────┐    │
│  │  StopMeasurement()                              │    │
│  │  - Record end time                              │    │
│  │  - Calculate deltas                             │    │
│  │  - Return metrics                               │    │
│  └────────────────────────────────────────────────┘    │
└──────────────┬──────────────────────┬───────────────────┘
               │                      │
               ▼                      ▼
      ┌─────────────────┐    ┌──────────────────┐
      │  ExportToCSV()  │    │  ExportToJSON()  │
      │  - Tabular data │    │  - Structured    │
      │  - Excel ready  │    │  - Programmatic  │
      └─────────────────┘    └──────────────────┘
```

---

### 📋 PerformanceMetrics Structure

The `PerformanceMetrics` struct captures comprehensive performance data:

```cpp
struct PerformanceMetrics {
    // Timing Information
    std::chrono::microseconds executionTime;  // Total execution time
    std::chrono::system_clock::time_point startTime;
    std::chrono::system_clock::time_point endTime;
    
    // Memory Metrics (bytes)
    size_t peakMemoryUsage;      // Peak working set size
    size_t currentMemoryUsage;   // Current working set
    size_t memoryDelta;          // Memory change during execution
    
    // CPU Metrics
    double cpuUsagePercent;      // CPU usage percentage
    double cpuTimeMs;            // CPU time in milliseconds
    
    // Disk I/O Metrics
    uint64_t diskBytesRead;      // Bytes read from disk
    uint64_t diskBytesWritten;   // Bytes written to disk
    uint64_t diskReadOps;        // Number of read operations
    uint64_t diskWriteOps;       // Number of write operations
    
    // Process Information
    DWORD processId;             // Process ID
    std::string processName;     // Process name
    std::string techniqueName;   // Name of technique tested
    std::string description;     // Description of test
    bool success;                // Whether test succeeded
};
```

**Total Metrics:** 14 different performance indicators

---

### 🔧 API Reference

#### Class: `PerformanceMonitor`

##### Constructor
```cpp
PerformanceMonitor();
```
- Initializes the performance monitoring system
- Sets up Windows API handles
- Prepares measurement infrastructure

##### Core Methods

###### 1. StartMeasurement()
```cpp
void StartMeasurement(
    const std::string& techniqueName,
    const std::string& description = ""
);
```
**Purpose:** Begin tracking performance metrics

**Parameters:**
- `techniqueName`: Name of the technique being measured (e.g., "DLL Injection")
- `description`: Optional detailed description

**Process:**
1. Records start timestamp (high-resolution)
2. Captures baseline memory usage
3. Gets initial CPU counters
4. Reads initial disk I/O statistics
5. Stores process information (PID, name)

**Example:**
```cpp
PerformanceMonitor monitor;
monitor.StartMeasurement("DLL Injection", 
                        "Inject payload.dll into notepad.exe");
```

---

###### 2. StopMeasurement()
```cpp
PerformanceMetrics StopMeasurement();
```
**Purpose:** Complete measurement and calculate final metrics

**Returns:** `PerformanceMetrics` struct with all calculated data

**Process:**
1. Records end timestamp
2. Calculates execution time (microsecond precision)
3. Measures final memory usage and peak
4. Computes CPU usage percentage
5. Calculates disk I/O deltas
6. Stores metrics in history vector
7. Returns complete metrics

**Example:**
```cpp
auto metrics = monitor.StopMeasurement();
std::cout << "Execution time: " 
          << (metrics.executionTime.count() / 1000.0) << " ms\n";
```

---

###### 3. SetSuccess()
```cpp
void SetSuccess(bool success);
```
**Purpose:** Mark whether the measured operation succeeded

**Parameters:**
- `success`: true if operation succeeded, false otherwise

**Usage:**
```cpp
try {
    // Perform operation
    monitor.SetSuccess(true);
} catch (...) {
    monitor.SetSuccess(false);
}
```

---

###### 4. ExportToCSV()
```cpp
void ExportToCSV(const std::string& filename) const;
```
**Purpose:** Export performance data to CSV file

**Format:**
```csv
Technique,Description,Success,Execution Time (ms),Start Time,End Time,
Peak Memory (MB),Current Memory (MB),Memory Delta (MB),CPU Usage (%),
CPU Time (ms),Disk Read (KB),Disk Write (KB),Disk Read Ops,
Disk Write Ops,Process ID,Process Name,Timestamp
```

**Features:**
- Proper CSV escaping (quotes, commas, newlines)
- Header row included
- Excel-compatible format
- Timestamps in ISO 8601 format

**Example:**
```cpp
monitor.ExportToCSV("results.csv");
```

---

###### 5. ExportToJSON()
```cpp
void ExportToJSON(const std::string& filename) const;
```
**Purpose:** Export performance data to JSON file

**Structure:**
```json
{
  "performance_data": [
    {
      "technique": "DLL Injection",
      "description": "Inject payload into process",
      "success": true,
      "execution_time_ms": 245.67,
      "memory": {
        "peak_mb": 12.5,
        "current_mb": 10.2,
        "delta_mb": 2.3
      },
      "cpu": {
        "usage_percent": 5.8,
        "time_ms": 120.5
      },
      "disk_io": {
        "read_kb": 45.2,
        "write_kb": 12.8,
        "read_ops": 23,
        "write_ops": 5
      },
      "process": {
        "id": 1234,
        "name": "dll_injection.exe"
      },
      "timestamp": "2024-01-15T10:30:45Z"
    }
  ],
  "summary": {
    "total_tests": 1,
    "successful_tests": 1,
    "avg_execution_time_ms": 245.67,
    "avg_memory_usage_mb": 10.2,
    "avg_cpu_usage_percent": 5.8
  }
}
```

**Example:**
```cpp
monitor.ExportToJSON("results.json");
```

---

###### 6. PrintSummary()
```cpp
void PrintSummary() const;
```
**Purpose:** Print statistical summary to console

**Output Format:**
```
======================================================
Performance Summary
======================================================
Total Tests: 5
Successful: 5
Failed: 0

Average Execution Time: 189.34 ms
Average Memory Usage: 15.67 MB
Average CPU Usage: 8.42 %
======================================================
```

**Example:**
```cpp
monitor.PrintSummary();
```

---

###### 7. GetHistory()
```cpp
const std::vector<PerformanceMetrics>& GetHistory() const;
```
**Purpose:** Retrieve all recorded measurements

**Returns:** Vector of `PerformanceMetrics` structs

**Example:**
```cpp
auto history = monitor.GetHistory();
for (const auto& metrics : history) {
    std::cout << metrics.techniqueName << ": "
              << (metrics.executionTime.count() / 1000.0) << " ms\n";
}
```

---

###### 8. ClearHistory()
```cpp
void ClearHistory();
```
**Purpose:** Clear all recorded measurements

**Example:**
```cpp
monitor.ClearHistory();
```

---

### 💡 Usage Patterns

#### Pattern 1: Basic Measurement
```cpp
PerformanceMonitor monitor;

// Start measurement
monitor.StartMeasurement("Memory Allocation", "Allocate 100MB");

try {
    // Your code here
    std::vector<char> buffer(100 * 1024 * 1024);
    
    monitor.SetSuccess(true);
} catch (...) {
    monitor.SetSuccess(false);
}

// Stop and get results
auto metrics = monitor.StopMeasurement();
```

---

#### Pattern 2: Multiple Iterations
```cpp
PerformanceMonitor monitor;

for (int i = 0; i < 5; ++i) {
    monitor.StartMeasurement("Iteration " + std::to_string(i));
    
    // Your code
    
    monitor.StopMeasurement();
}

// Export all results
monitor.ExportToCSV("iterations.csv");
monitor.PrintSummary();
```

---

#### Pattern 3: Comparison Testing
```cpp
PerformanceMonitor monitor;

// Test Technique A
monitor.StartMeasurement("Technique A", "Direct injection");
TechniqueA();
monitor.StopMeasurement();

// Test Technique B
monitor.StartMeasurement("Technique B", "Staged injection");
TechniqueB();
monitor.StopMeasurement();

// Compare results
auto history = monitor.GetHistory();
CompareMetrics(history[0], history[1]);
```

---

#### Pattern 4: EDR Technique Profiling
```cpp
PerformanceMonitor monitor;

// Profile DLL injection
monitor.StartMeasurement("DLL Injection", 
                        "Inject into target process");

bool success = PerformDLLInjection(targetPID, dllPath);
monitor.SetSuccess(success);

auto metrics = monitor.StopMeasurement();

// Export for analysis
monitor.ExportToCSV("dll_injection_profile.csv");
monitor.ExportToJSON("dll_injection_profile.json");
```

---

### 📊 Metrics Interpretation

#### Execution Time
- **Range:** Microseconds to seconds
- **Precision:** Microsecond (std::chrono::high_resolution_clock)
- **Use Case:** Identify slow operations, compare technique efficiency

**Example Values:**
- Fast: < 100 ms (memory operations)
- Medium: 100-1000 ms (process operations)
- Slow: > 1000 ms (complex injections)

---

#### Memory Usage
- **Units:** Bytes (displayed as MB)
- **Metrics:**
  - **Peak:** Maximum memory used
  - **Current:** Memory at measurement stop
  - **Delta:** Change during execution

**Example Values:**
- Minimal: < 5 MB (simple operations)
- Moderate: 5-50 MB (typical injection)
- High: > 50 MB (large payload or multiple allocations)

---

#### CPU Usage
- **Units:** Percentage (0-100%)
- **Calculation:** Based on process CPU time vs wall time
- **Use Case:** Identify CPU-intensive operations

**Example Values:**
- Low: < 10% (I/O bound operations)
- Medium: 10-50% (balanced operations)
- High: > 50% (CPU-intensive calculations)

---

#### Disk I/O
- **Metrics:**
  - **Read/Write Bytes:** Total data transferred
  - **Read/Write Ops:** Number of I/O operations
- **Use Case:** Track file access patterns

**Example Values:**
- Minimal: < 100 KB (configuration read)
- Moderate: 100 KB - 10 MB (DLL loading)
- High: > 10 MB (large file operations)

---

### 🔍 Integration Examples

#### Example 1: DLL Injection (v3)
**File:** `samples/process_injection/dll_injection_v3.cpp`

**Key Integration Points:**
```cpp
// 1. Create monitor
PerformanceMonitor monitor;

// 2. Start measurement before technique
monitor.StartMeasurement("DLL Injection", 
                        "Inject " + dllPath + " into " + processName);

// 3. Execute technique with error handling
try {
    // ... injection code ...
    monitor.SetSuccess(true);
} catch (...) {
    monitor.SetSuccess(false);
}

// 4. Stop and capture metrics
auto metrics = monitor.StopMeasurement();

// 5. Export results
monitor.ExportToCSV("dll_injection_performance.csv");
monitor.ExportToJSON("dll_injection_performance.json");
```

**Benefits:**
- ✅ Automatic resource tracking
- ✅ Detailed performance profile
- ✅ Exportable data for analysis
- ✅ Historical comparison capability

---

#### Example 2: Performance Demo
**File:** `demos/performance_demo.cpp`

**Tests Included:**
1. **Memory Allocation** (100 MB allocation and fill)
2. **CPU Intensive** (Prime number calculation)
3. **Disk I/O** (10 MB write/read)
4. **Process Creation** (Create and terminate notepad.exe)
5. **Comparison** (5 iterations of memory allocation)

**Output:**
- Console summary statistics
- `performance_results.csv` - Tabular data
- `performance_results.json` - Structured data
- `performance_demo.log` - Detailed log

---

### 📈 Data Analysis

#### CSV Analysis (Excel/Python)
```python
import pandas as pd

# Load data
df = pd.read_csv('performance_results.csv')

# Calculate statistics
print(f"Average execution time: {df['Execution Time (ms)'].mean():.2f} ms")
print(f"Peak memory usage: {df['Peak Memory (MB)'].max():.2f} MB")
print(f"Success rate: {df['Success'].mean() * 100:.1f}%")

# Compare techniques
grouped = df.groupby('Technique')['Execution Time (ms)'].agg(['mean', 'std'])
print(grouped)
```

---

#### JSON Analysis (Programmatic)
```python
import json

# Load data
with open('performance_results.json', 'r') as f:
    data = json.load(f)

# Access summary
summary = data['summary']
print(f"Total tests: {summary['total_tests']}")
print(f"Avg execution: {summary['avg_execution_time_ms']:.2f} ms")

# Analyze individual tests
for test in data['performance_data']:
    if not test['success']:
        print(f"Failed test: {test['technique']}")
```

---

### 🎯 Best Practices

#### 1. Consistent Naming
```cpp
// ✅ Good: Descriptive technique names
monitor.StartMeasurement("DLL Injection - Classic Method");
monitor.StartMeasurement("Process Hollowing - NTDLL Variant");

// ❌ Bad: Vague names
monitor.StartMeasurement("Test 1");
monitor.StartMeasurement("Function");
```

---

#### 2. Meaningful Descriptions
```cpp
// ✅ Good: Detailed description
monitor.StartMeasurement("APC Injection",
    "Inject shellcode into notepad.exe using APC queue");

// ❌ Bad: No description
monitor.StartMeasurement("APC Injection");
```

---

#### 3. Always Set Success Status
```cpp
// ✅ Good: Explicit success tracking
try {
    // ... operation ...
    monitor.SetSuccess(true);
} catch (...) {
    monitor.SetSuccess(false);
}

// ❌ Bad: No success status
// ... operation ...
monitor.StopMeasurement();  // Success undefined
```

---

#### 4. Export Data Regularly
```cpp
// ✅ Good: Export after each major test suite
monitor.ExportToCSV("technique_A_results.csv");
monitor.ClearHistory();

// Run next suite
// ... tests ...

monitor.ExportToCSV("technique_B_results.csv");

// ❌ Bad: Never export or export once at end
// Risk: Data loss if program crashes
```

---

#### 5. Use Descriptive Filenames
```cpp
// ✅ Good: Includes timestamp and technique
std::string filename = "dll_injection_" + 
    GetTimestamp() + ".csv";
monitor.ExportToCSV(filename);

// ❌ Bad: Overwrites previous results
monitor.ExportToCSV("results.csv");
```

---

### 🧪 Testing Guidelines

#### Unit Testing
```cpp
// Test 1: Verify timing accuracy
void TestTimingAccuracy() {
    PerformanceMonitor monitor;
    monitor.StartMeasurement("Sleep Test");
    
    Sleep(1000);  // Sleep for 1 second
    
    auto metrics = monitor.StopMeasurement();
    
    // Should be approximately 1000ms
    double execTime = metrics.executionTime.count() / 1000.0;
    assert(execTime >= 990 && execTime <= 1010);
}

// Test 2: Verify memory tracking
void TestMemoryTracking() {
    PerformanceMonitor monitor;
    monitor.StartMeasurement("Memory Test");
    
    std::vector<char> buffer(10 * 1024 * 1024);  // 10 MB
    
    auto metrics = monitor.StopMeasurement();
    
    // Should show memory increase
    assert(metrics.memoryDelta > 0);
}
```

---

#### Integration Testing
```cpp
// Test: Full workflow
void TestFullWorkflow() {
    PerformanceMonitor monitor;
    
    // Perform multiple operations
    for (int i = 0; i < 5; ++i) {
        monitor.StartMeasurement("Test " + std::to_string(i));
        // ... operation ...
        monitor.StopMeasurement();
    }
    
    // Verify history
    assert(monitor.GetHistory().size() == 5);
    
    // Test export
    monitor.ExportToCSV("test_workflow.csv");
    monitor.ExportToJSON("test_workflow.json");
    
    // Verify files created
    assert(FileExists("test_workflow.csv"));
    assert(FileExists("test_workflow.json"));
}
```

---

### 🐛 Troubleshooting

#### Issue 1: Zero CPU Usage
**Symptom:** `cpuUsagePercent` is always 0

**Causes:**
- Very fast operations (< 1ms)
- Insufficient precision in time measurement

**Solution:**
```cpp
// Add artificial work for testing
for (int i = 0; i < 1000000; ++i) {
    volatile int x = i * i;  // Prevent optimization
}
```

---

#### Issue 2: Memory Delta is Negative
**Symptom:** `memoryDelta` shows negative value

**Causes:**
- Garbage collection during measurement
- Memory released by other threads

**Solution:**
- Use `peakMemoryUsage` instead of `memoryDelta`
- Isolate test from background operations

---

#### Issue 3: Export Fails
**Symptom:** `ExportToCSV()` or `ExportToJSON()` throws exception

**Causes:**
- File path doesn't exist
- Insufficient permissions
- File is open in another program

**Solution:**
```cpp
try {
    monitor.ExportToCSV("results.csv");
} catch (const Exception& e) {
    std::cerr << "Export failed: " << e.what() << "\n";
    // Try alternative location
    monitor.ExportToCSV("C:\\temp\\results.csv");
}
```

---

### 📚 Advanced Features

#### Custom Metric Collection
```cpp
// Collect additional custom metrics
class CustomPerformanceMonitor : public PerformanceMonitor {
private:
    size_t networkBytesReceived = 0;
    size_t networkBytesSent = 0;
    
public:
    void TrackNetworkIO(size_t received, size_t sent) {
        networkBytesReceived += received;
        networkBytesSent += sent;
    }
    
    void PrintNetworkStats() const {
        std::cout << "Network Received: " 
                  << networkBytesReceived << " bytes\n";
        std::cout << "Network Sent: " 
                  << networkBytesSent << " bytes\n";
    }
};
```

---

#### Automated Performance Regression Detection
```cpp
bool DetectPerformanceRegression(
    const PerformanceMetrics& baseline,
    const PerformanceMetrics& current,
    double thresholdPercent = 10.0) {
    
    double baselineTime = baseline.executionTime.count();
    double currentTime = current.executionTime.count();
    
    double percentIncrease = 
        ((currentTime - baselineTime) / baselineTime) * 100.0;
    
    if (percentIncrease > thresholdPercent) {
        std::cout << "PERFORMANCE REGRESSION DETECTED!\n";
        std::cout << "Baseline: " << baselineTime << " μs\n";
        std::cout << "Current: " << currentTime << " μs\n";
        std::cout << "Increase: " << percentIncrease << " %\n";
        return true;
    }
    
    return false;
}
```

---

### 📝 Implementation Checklist

When integrating performance monitoring into a new technique:

- [ ] Include `performance_monitor.hpp`
- [ ] Create `PerformanceMonitor` instance
- [ ] Call `StartMeasurement()` before technique execution
- [ ] Wrap technique in try-catch with `SetSuccess()`
- [ ] Call `StopMeasurement()` after technique execution
- [ ] Export results to CSV and/or JSON
- [ ] Add performance tests to automated test suite
- [ ] Document expected performance characteristics
- [ ] Set up performance regression tests
- [ ] Update build scripts to include new file

---

### 🔗 Related Documentation

- **ENHANCEMENT_SPEC.md** - Category 3.3: Performance Benchmarking
- **ERROR_HANDLING_INTEGRATION_REPORT.md** - Error handling system
- **docs/detection_guide.md** - EDR detection techniques
- **docs/TEST_COVERAGE.md** - Test coverage information

---

### 📊 Performance Metrics Summary

| Component | Status | Lines of Code | Files |
|-----------|--------|---------------|-------|
| Core System | ✅ Complete | 630+ | 1 |
| Demo Application | ✅ Complete | 310+ | 1 |
| Enhanced Sample (v3) | ✅ Complete | 420+ | 1 |
| Documentation | ✅ Complete | 1000+ | 1 |
| **Total** | **100%** | **2360+** | **4** |

---

### 🎯 Future Enhancements

#### Planned Features
1. **Real-time Monitoring Dashboard** - Live performance visualization
2. **Network I/O Tracking** - Monitor network activity
3. **Thread-level Metrics** - Per-thread performance data
4. **GPU Usage Tracking** - Monitor GPU utilization
5. **Energy Consumption** - Track power usage
6. **Comparative Analysis Tool** - Automated technique comparison
7. **Performance Alerts** - Real-time anomaly detection
8. **Integration with CI/CD** - Automated performance regression tests

---

### ✅ Completion Status

**Category 3.3: Performance Benchmarking** - ✅ **COMPLETE**

**Implemented Components:**
- ✅ `performance_monitor.hpp` - Core monitoring system
- ✅ `performance_demo.cpp` - Demonstration application
- ✅ `dll_injection_v3.cpp` - Integration example
- ✅ `PERFORMANCE_MONITORING.md` - Comprehensive documentation

**Deliverables:**
- ✅ High-resolution timing (microsecond precision)
- ✅ Memory usage tracking (peak, current, delta)
- ✅ CPU usage calculation
- ✅ Disk I/O monitoring
- ✅ CSV export functionality
- ✅ JSON export functionality
- ✅ Historical data tracking
- ✅ Statistical summary generation
- ✅ Integration with existing infrastructure (logger, error_handling)
- ✅ RAII-based resource management
- ✅ Complete documentation with examples

**Testing:**
- ✅ Demo application with 5 different tests
- ✅ Integration example (dll_injection_v3)
- ✅ CSV export validation
- ✅ JSON export validation
- ✅ Summary statistics calculation

---

### 📧 Support

For questions or issues related to the performance monitoring system:

1. Check this documentation first
2. Review `performance_demo.cpp` for usage examples
3. Examine `dll_injection_v3.cpp` for integration patterns
4. Check logs in `*.log` files for debugging information
5. Refer to `ENHANCEMENT_SPEC.md` for original requirements

---

**Last Updated:** 2024-01-15  
**Author:** EDR Testing Tools Development Team  
**Version:** 1.0
