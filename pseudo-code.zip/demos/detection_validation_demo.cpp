/*
 * Detection Validation Demo - EDR Testing Tools
 * 
 * Purpose: Demonstrate EDR detection validation capabilities
 * 
 * This demo shows:
 * - How to use DetectionValidator class
 * - ETW event collection
 * - Sysmon log parsing
 * - Automated detection rate calculation
 * - Report generation
 * 
 * Features demonstrated:
 * 1. Real-time monitoring
 * 2. Technique validation
 * 3. Multi-source event correlation
 * 4. Detection scoring
 * 5. Report export (JSON/CSV)
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include "../include/detection_validator.hpp"
#include "../include/logger.hpp"
#include "../include/error_handling.hpp"

using namespace EDR;

// ============================================================================
// Helper Functions
// ============================================================================

void PrintBanner() {
    std::cout << R"(
+====================================================================+
|          EDR Detection Validation Demo                              |
|                                                                     |
|  This demo demonstrates automated EDR detection validation          |
|  capabilities using multiple event sources.                         |
+====================================================================+
)" << "\n";
}

void PrintDetectionResult(const DetectionResult& result) {
    std::cout << "\n" << std::string(70, '=') << "\n";
    std::cout << "Technique: " << result.technique << " - " << result.techniqueName << "\n";
    std::cout << std::string(70, '=') << "\n";
    
    std::cout << "Status: " << (result.detected ? "✓ DETECTED" : "✗ NOT DETECTED") << "\n";
    
    if (result.detected) {
        std::cout << "Detection Latency: " << result.detectionLatency.count() << " ms\n";
        std::cout << "Detection Score: " << (result.detectionScore * 100.0) << "%\n";
        std::cout << "Confidence: " << result.confidence << "\n";
        std::cout << "Severity: " << result.severity << "\n";
        
        std::cout << "\nDetection Methods:\n";
        for (const auto& method : result.detectionMethods) {
            std::cout << "  - " << method << "\n";
        }
        
        std::cout << "\nEvent Summary:\n";
        std::cout << "  ETW Events: " << result.etwEvents.size() << "\n";
        std::cout << "  Sysmon Events: " << result.sysmonEvents.size() << "\n";
        std::cout << "  Windows Events: " << result.windowsEvents.size() << "\n";
        
        if (!result.details.empty()) {
            std::cout << "\nDetails: " << result.details << "\n";
        }
    }
    
    std::cout << std::string(70, '=') << "\n";
}

void PrintDetectionReport(const DetectionReport& report) {
    std::cout << "\n" << std::string(70, '=') << "\n";
    std::cout << "               DETECTION VALIDATION REPORT\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(
        report.endTime - report.startTime);
    
    std::cout << "Test Duration: " << duration.count() << " seconds\n";
    std::cout << "Total Techniques Tested: " << report.totalTechniques << "\n";
    std::cout << "Detected Techniques: " << report.detectedTechniques << "\n";
    std::cout << "Overall Detection Rate: " 
              << (report.overallDetectionRate * 100.0) << "%\n\n";
    
    if (report.detectedTechniques > 0) {
        std::cout << "Detection Latency Statistics:\n";
        std::cout << "  Average: " << report.averageDetectionLatency.count() << " ms\n";
        std::cout << "  Minimum: " << report.minDetectionLatency.count() << " ms\n";
        std::cout << "  Maximum: " << report.maxDetectionLatency.count() << " ms\n\n";
    }
    
    if (!report.detectionMethodCounts.empty()) {
        std::cout << "Detection Methods Used:\n";
        for (const auto& [method, count] : report.detectionMethodCounts) {
            std::cout << "  " << method << ": " << count << " detections\n";
        }
        std::cout << "\n";
    }
    
    if (!report.results.empty()) {
        std::cout << "Detailed Results:\n";
        std::cout << std::string(70, '-') << "\n";
        
        for (const auto& result : report.results) {
            std::cout << "  " << result.technique << " (" << result.techniqueName << ")\n";
            std::cout << "    Status: " << (result.detected ? "DETECTED" : "NOT DETECTED") << "\n";
            std::cout << "    Score: " << (result.detectionScore * 100.0) << "%\n";
            std::cout << "    Confidence: " << result.confidence << "\n";
            std::cout << "\n";
        }
    }
    
    std::cout << std::string(70, '=') << "\n";
}

// ============================================================================
// Demo Scenarios
// ============================================================================

/**
 * @brief Demo 1: Basic detection validation
 */
void Demo1_BasicValidation() {
    std::cout << "\n[Demo 1] Basic Detection Validation\n";
    std::cout << std::string(70, '-') << "\n";
    
    try {
        DetectionValidator validator;
        
        // 권한 확인
        if (!DetectionValidator::IsElevated()) {
            std::cout << "[!] Administrator privileges required\n";
            std::cout << "[!] Please run as administrator to enable ETW monitoring\n";
            return;
        }
        
        std::cout << "[*] Starting monitoring...\n";
        
        if (!validator.StartMonitoring()) {
            std::cout << "[-] Failed to start monitoring\n";
            return;
        }
        
        std::cout << "[+] Monitoring started\n";
        
        // 시뮬레이션: 실제로는 여기서 공격 기법을 실행
        std::cout << "[*] Simulating technique execution...\n";
        std::this_thread::sleep_for(std::chrono::seconds(3));
        
        // 탐지 검증
        std::cout << "[*] Validating detection...\n";
        auto result = validator.ValidateTechnique("dll_injection");
        
        validator.StopMonitoring();
        
        PrintDetectionResult(result);
        
        // 보고서 생성
        auto report = validator.GenerateReport();
        PrintDetectionReport(report);
        
    } catch (const Exception& e) {
        std::cerr << "[-] Error: " << e.what() << "\n";
        std::cerr << "[-] Error Code: " << static_cast<int>(e.code()) << "\n";
    }
}

/**
 * @brief Demo 2: Multiple technique validation
 */
void Demo2_MultipleTechniques() {
    std::cout << "\n[Demo 2] Multiple Technique Validation\n";
    std::cout << std::string(70, '-') << "\n";
    
    try {
        DetectionValidator validator;
        
        if (!DetectionValidator::IsElevated()) {
            std::cout << "[!] Administrator privileges required\n";
            return;
        }
        
        // ETW 프로바이더 활성화
        std::cout << "[*] Enabling ETW providers...\n";
        std::map<GUID, std::wstring, GuidLess> providers = {
            {ETWProviders::KernelProcess, L"Kernel-Process"},
            {ETWProviders::KernelFile, L"Kernel-File"},
            {ETWProviders::KernelRegistry, L"Kernel-Registry"}
        };
        
        int enabled = validator.EnableETWProviders(providers);
        std::cout << "[+] Enabled " << enabled << " ETW providers\n";
        
        validator.StartMonitoring();
        
        // 여러 기법 테스트
        std::vector<std::string> techniques = {
            "dll_injection",
            "process_hollowing",
            "apc_injection"
        };
        
        std::cout << "[*] Testing " << techniques.size() << " techniques...\n";
        std::this_thread::sleep_for(std::chrono::seconds(2));
        
        auto results = validator.ValidateTechniques(techniques);
        
        validator.StopMonitoring();
        
        // 결과 출력
        for (const auto& result : results) {
            PrintDetectionResult(result);
        }
        
        // 전체 보고서
        auto report = validator.GenerateReport();
        PrintDetectionReport(report);
        
        // JSON 내보내기
        std::cout << "[*] Exporting report to JSON...\n";
        std::string jsonReport = report.ExportToJSON();
        
        std::ofstream jsonFile("detection_report.json");
        if (jsonFile.is_open()) {
            jsonFile << jsonReport;
            jsonFile.close();
            std::cout << "[+] Report exported to detection_report.json\n";
        }
        
        // CSV 내보내기
        std::cout << "[*] Exporting report to CSV...\n";
        report.ExportToCSV("detection_report.csv");
        std::cout << "[+] Report exported to detection_report.csv\n";
        
    } catch (const Exception& e) {
        std::cerr << "[-] Error: " << e.what() << "\n";
    }
}

/**
 * @brief Demo 3: Real-time monitoring with callback
 */
void Demo3_RealtimeMonitoring() {
    std::cout << "\n[Demo 3] Real-time Monitoring\n";
    std::cout << std::string(70, '-') << "\n";
    
    try {
        DetectionValidator validator;
        
        if (!DetectionValidator::IsElevated()) {
            std::cout << "[!] Administrator privileges required\n";
            return;
        }
        
        // 실시간 콜백 설정
        std::cout << "[*] Setting up real-time callback...\n";
        
        int eventCount = 0;
        validator.SetRealtimeCallback([&eventCount](const ETWEvent& event) {
            ++eventCount;
            
            if (eventCount % 10 == 0) {
                std::cout << "[*] Events collected: " << eventCount << "\r" << std::flush;
            }
        });
        
        validator.SetVerboseLogging(true);
        validator.StartMonitoring();
        
        std::cout << "[*] Monitoring for 10 seconds...\n";
        std::cout << "[*] Press Ctrl+C to stop early\n\n";
        
        // 10초 동안 모니터링
        for (int i = 10; i > 0; --i) {
            std::cout << "[*] Time remaining: " << i << " seconds\r" << std::flush;
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        
        std::cout << "\n";
        validator.StopMonitoring();
        
        std::cout << "[+] Total events collected: " << eventCount << "\n";
        
        // 수집된 이벤트 표시
        auto events = validator.GetETWEvents();
        std::cout << "[+] ETW events: " << events.size() << "\n";
        
        if (!events.empty() && events.size() <= 5) {
            std::cout << "\nSample Events:\n";
            for (const auto& event : events) {
                std::wcout << event.ToString() << L"\n";
            }
        }
        
    } catch (const Exception& e) {
        std::cerr << "[-] Error: " << e.what() << "\n";
    }
}

/**
 * @brief Demo 4: Sysmon integration
 */
void Demo4_SysmonIntegration() {
    std::cout << "\n[Demo 4] Sysmon Integration\n";
    std::cout << std::string(70, '-') << "\n";
    
    // Sysmon 설치 확인
    if (!DetectionValidator::IsSysmonInstalled()) {
        std::cout << "[!] Sysmon is not installed\n";
        std::cout << "[i] To install Sysmon:\n";
        std::cout << "    1. Download from: https://docs.microsoft.com/sysinternals/downloads/sysmon\n";
        std::cout << "    2. Run: sysmon64.exe -accepteula -i\n";
        std::cout << "[i] Skipping Sysmon demo...\n";
        return;
    }
    
    std::cout << "[+] Sysmon is installed\n";
    
    try {
        DetectionValidator validator;
        
        auto startTime = std::chrono::system_clock::now();
        
        std::cout << "[*] Parsing Sysmon logs...\n";
        
        auto sysmonEvents = validator.ParseSysmonLogs(
            startTime - std::chrono::minutes(5) // Last 5 minutes
        );
        
        std::cout << "[+] Found " << sysmonEvents.size() << " Sysmon events\n";
        
        if (!sysmonEvents.empty()) {
            std::cout << "\nRecent Sysmon Events:\n";
            std::cout << std::string(70, '-') << "\n";
            
            int displayCount = (std::min)(static_cast<int>(sysmonEvents.size()), 5);
            
            for (int i = 0; i < displayCount; ++i) {
                const auto& event = sysmonEvents[i];
                
                std::wcout << L"Event: " << event.GetTypeName() << L"\n";
                std::wcout << L"  Process: " << event.processName 
                          << L" (PID: " << event.processId << L")\n";
                
                if (!event.image.empty()) {
                    std::wcout << L"  Image: " << event.image << L"\n";
                }
                
                if (!event.commandLine.empty()) {
                    std::wcout << L"  Command: " << event.commandLine << L"\n";
                }
                
                std::cout << "\n";
            }
        }
        
    } catch (const Exception& e) {
        std::cerr << "[-] Error: " << e.what() << "\n";
    }
}

/**
 * @brief Demo 5: Technique database
 */
void Demo5_TechniqueDatabase() {
    std::cout << "\n[Demo 5] Technique Database\n";
    std::cout << std::string(70, '-') << "\n";
    
    auto techniques = TechniqueDatabase::GetAllTechniques();
    
    std::cout << "[+] Supported techniques: " << techniques.size() << "\n\n";
    
    for (const auto& tech : techniques) {
        std::cout << "Technique: " << tech.id << " - " << tech.name << "\n";
        std::cout << "Tactic: " << tech.tactic << "\n";
        
        std::cout << "Detection Indicators:\n";
        for (const auto& indicator : tech.indicators) {
            std::cout << "  - " << indicator << "\n";
        }
        
        std::cout << "Sysmon Event IDs: ";
        for (size_t i = 0; i < tech.sysmonEventIds.size(); ++i) {
            std::cout << tech.sysmonEventIds[i];
            if (i < tech.sysmonEventIds.size() - 1) {
                std::cout << ", ";
            }
        }
        std::cout << "\n\n";
    }
}

// ============================================================================
// Main Menu
// ============================================================================

void ShowMenu() {
    std::cout << "\n" << std::string(70, '=') << "\n";
    std::cout << "Select a demo:\n";
    std::cout << std::string(70, '=') << "\n";
    std::cout << "1. Basic Detection Validation\n";
    std::cout << "2. Multiple Technique Validation\n";
    std::cout << "3. Real-time Monitoring\n";
    std::cout << "4. Sysmon Integration\n";
    std::cout << "5. Technique Database\n";
    std::cout << "6. Run All Demos\n";
    std::cout << "0. Exit\n";
    std::cout << std::string(70, '=') << "\n";
    std::cout << "Choice: ";
}

int main() {
    PrintBanner();
    
    // Logger 초기화
    Logger::Instance().SetLevel(Logger::Level::INFO);
    Logger::Instance().SetOutputFile("detection_validation.log");
    
    std::cout << "[i] Log file: detection_validation.log\n";
    
    // 권한 확인
    if (!DetectionValidator::IsElevated()) {
        std::cout << "\n[!] WARNING: Not running as administrator\n";
        std::cout << "[!] Some features will be limited\n";
        std::cout << "[!] For full functionality, run as administrator\n";
    }
    
    bool running = true;
    
    while (running) {
        ShowMenu();
        
        int choice;
        std::cin >> choice;
        
        switch (choice) {
            case 1:
                Demo1_BasicValidation();
                break;
                
            case 2:
                Demo2_MultipleTechniques();
                break;
                
            case 3:
                Demo3_RealtimeMonitoring();
                break;
                
            case 4:
                Demo4_SysmonIntegration();
                break;
                
            case 5:
                Demo5_TechniqueDatabase();
                break;
                
            case 6:
                Demo1_BasicValidation();
                Demo2_MultipleTechniques();
                Demo3_RealtimeMonitoring();
                Demo4_SysmonIntegration();
                Demo5_TechniqueDatabase();
                break;
                
            case 0:
                running = false;
                std::cout << "\n[+] Goodbye!\n";
                break;
                
            default:
                std::cout << "\n[-] Invalid choice\n";
                break;
        }
        
        if (running && choice != 0) {
            std::cout << "\nPress Enter to continue...";
            std::cin.ignore();
            std::cin.get();
        }
    }
    
    return 0;
}
