/**
 * @file test_customization_demo.cpp
 * @brief 테스트 커스터마이징 & 실시간 모니터링 데모
 * @details
 * 5가지 데모 시나리오:
 * 1. 기본 테스트 커스터마이징
 * 2. JSON 시나리오 로드 및 실행
 * 3. 실시간 모니터링
 * 4. 대화형 테스트 제어
 * 5. 실시간 대시보드
 */

#include <iostream>
#include <windows.h>
#include <thread>
#include <chrono>
#include <conio.h>
#include "../include/test_customizer.hpp"
#include "../include/realtime_monitor.hpp"
#include "../include/config_manager.hpp"
#include "../include/logger.hpp"

using namespace EDR;
using namespace std::chrono_literals;

// 콘솔 색상
void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void PrintSection(const std::string& title) {
    SetColor(14); // Yellow
    std::cout << "\n+--------------------------------------------------------------+" << std::endl;
    std::cout << "|  " << title;
    for (size_t i = title.length(); i < 58; ++i) std::cout << " ";
    std::cout << "|" << std::endl;
    std::cout << "+--------------------------------------------------------------+" << std::endl;
    SetColor(7);
}

void PrintSuccess(const std::string& message) {
    SetColor(10); // Green
    std::cout << "[OK] " << message << std::endl;
    SetColor(7);
}

void PrintInfo(const std::string& message) {
    SetColor(11); // Cyan
    std::cout << "[i] " << message << std::endl;
    SetColor(7);
}

void PrintError(const std::string& message) {
    SetColor(12); // Red
    std::cout << "[X] " << message << std::endl;
    SetColor(7);
}

// Demo 1: 기본 테스트 커스터마이징
void Demo1_BasicCustomization() {
    PrintSection("Demo 1: Basic Test Customization");
    
    TestCustomizer& customizer = TestCustomizer::Instance();
    
    // 커스텀 테스트 생성
    PrintInfo("Creating custom DLL injection test...");
    
    CustomTest dllTest;
    dllTest.id = "custom_dll_injection";
    dllTest.name = "Custom DLL Injection Test";
    dllTest.description = "DLL injection with custom parameters";
    dllTest.techniqueId = "T1055.001";
    dllTest.category = "process_injection";
    dllTest.executionMode = ExecutionMode::SEQUENTIAL;
    dllTest.priority = 10;
    dllTest.maxRetries = 3;
    dllTest.timeout = std::chrono::seconds(60);
    
    // 파라미터 추가
    dllTest.parameters.push_back(
        TestParameter("target_process", ParameterType::STRING, "notepad.exe", "Target process name")
    );
    dllTest.parameters.push_back(
        TestParameter("dll_path", ParameterType::FILE_PATH, "C:\\Windows\\System32\\kernel32.dll", "DLL to inject")
    );
    dllTest.parameters.push_back(
        TestParameter("wait_for_target", ParameterType::BOOLEAN, true, "Wait if target not found")
    );
    
    // 실행 함수 설정 (시뮬레이션)
    dllTest.executeFunction = [](const std::map<std::string, json>& params) -> TestResult {
        TestResult result;
        result.techniqueId = "T1055.001";
        result.techniqueName = "Custom DLL Injection";
        
        // 시뮬레이션 실행
        std::cout << "  Executing DLL injection with parameters:" << std::endl;
        for (const auto& [key, value] : params) {
            std::cout << "    - " << key << ": " << value << std::endl;
        }
        
        Sleep(2000); // 시뮬레이션
        
        result.success = true;
        result.duration = std::chrono::milliseconds(2000);
        result.output = "DLL injection simulated successfully";
        
        return result;
    };
    
    // 테스트 등록
    customizer.RegisterTest(dllTest);
    PrintSuccess("Custom test registered: " + dllTest.id);
    
    // 테스트 실행
    PrintInfo("Executing custom test...");
    try {
        std::map<std::string, json> params;
        params["target_process"] = "notepad.exe";
        params["dll_path"] = "C:\\Windows\\System32\\kernel32.dll";
        params["wait_for_target"] = false;
        
        TestResult result = customizer.ExecuteTest(dllTest.id, params);
        
        if (result.success) {
            PrintSuccess("Test completed: " + result.output);
            std::cout << "  Duration: " << result.duration.count() << "ms" << std::endl;
        } else {
            PrintError("Test failed: " + result.errorMessage);
        }
    } catch (const std::exception& e) {
        PrintError(std::string("Error: ") + e.what());
    }
}

// Demo 2: JSON 시나리오 로드 및 실행
void Demo2_JSONScenario() {
    PrintSection("Demo 2: JSON Scenario Loading");
    
    TestCustomizer& customizer = TestCustomizer::Instance();
    
    // 시나리오 파일 경로
    std::string scenarioPath = "scenarios/comprehensive_injection.json";
    
    PrintInfo("Loading scenario from: " + scenarioPath);
    
    try {
        customizer.LoadScenario(scenarioPath);
        PrintSuccess("Scenario loaded successfully");
        
        // 시나리오 정보 표시
        auto scenario = customizer.GetScenario("comprehensive_injection_test");
        std::cout << "\nScenario Information:" << std::endl;
        std::cout << "  Name: " << scenario.name << std::endl;
        std::cout << "  Description: " << scenario.description << std::endl;
        std::cout << "  Tests: " << scenario.tests.size() << std::endl;
        std::cout << "  Chains: " << scenario.chains.size() << std::endl;
        
        std::cout << "\nAvailable Tests:" << std::endl;
        for (const auto& test : scenario.tests) {
            std::cout << "  • " << test.id << " (" << test.techniqueId << ")" << std::endl;
            std::cout << "    " << test.description << std::endl;
        }
        
        std::cout << "\nAvailable Chains:" << std::endl;
        for (const auto& chain : scenario.chains) {
            std::cout << "  • " << chain.id << std::endl;
            std::cout << "    Tests: " << chain.testIds.size() << std::endl;
        }
        
    } catch (const std::exception& e) {
        PrintError(std::string("Failed to load scenario: ") + e.what());
    }
}

// Demo 3: 실시간 모니터링
void Demo3_RealtimeMonitoring() {
    PrintSection("Demo 3: Real-time Monitoring");
    
    RealtimeMonitor& monitor = RealtimeMonitor::Instance();
    
    PrintInfo("Starting real-time monitor...");
    monitor.Start();
    
    // 이벤트 핸들러 등록
    monitor.RegisterEventHandler([](const MonitorEvent& event) {
        switch (event.type) {
            case MonitorEventType::TEST_STARTED:
                SetColor(11);
                std::cout << "[STARTED] " << event.message << std::endl;
                SetColor(7);
                break;
            case MonitorEventType::TEST_COMPLETED:
                SetColor(10);
                std::cout << "[COMPLETED] " << event.message << std::endl;
                SetColor(7);
                break;
            case MonitorEventType::TEST_FAILED:
                SetColor(12);
                std::cout << "[FAILED] " << event.message << std::endl;
                SetColor(7);
                break;
            case MonitorEventType::LOG_MESSAGE:
                std::cout << "[LOG] " << event.message << std::endl;
                break;
            default:
                break;
        }
    });
    
    // 테스트 시뮬레이션
    PrintInfo("Simulating test execution...");
    
    std::vector<std::string> tests = {
        "dll_injection",
        "process_hollowing",
        "apc_injection",
        "shellcode_injection"
    };
    
    for (const auto& testId : tests) {
        monitor.NotifyTestStarted(testId, "Test: " + testId);
        
        // 진행 시뮬레이션
        for (int i = 0; i <= 100; i += 20) {
            Sleep(200);
            monitor.NotifyTestProgress(testId, i, "Phase " + std::to_string(i/20 + 1));
        }
        
        // 완료
        bool success = (rand() % 100) > 20; // 80% 성공률
        monitor.NotifyTestCompleted(testId, success);
        
        Sleep(500);
    }
    
    // 메트릭 표시
    std::cout << "\n";
    PrintInfo("Current Metrics:");
    auto metrics = monitor.GetMetrics();
    std::cout << "  Total Tests: " << metrics.totalTests << std::endl;
    std::cout << "  Completed: " << metrics.completedTests << std::endl;
    std::cout << "  Failed: " << metrics.failedTests << std::endl;
    std::cout << "  Progress: " << metrics.GetProgressPercent() << "%" << std::endl;
    
    PrintSuccess("Real-time monitoring demo completed");
    
    Sleep(1000);
    monitor.Stop();
}

// Demo 4: 대화형 테스트 제어
void Demo4_InteractiveControl() {
    PrintSection("Demo 4: Interactive Test Control");
    
    RealtimeMonitor& monitor = RealtimeMonitor::Instance();
    monitor.Start();
    
    std::cout << "\nInteractive Control Commands:" << std::endl;
    std::cout << "  [P] Pause monitoring" << std::endl;
    std::cout << "  [R] Resume monitoring" << std::endl;
    std::cout << "  [S] Take snapshot" << std::endl;
    std::cout << "  [Q] Quit" << std::endl;
    std::cout << std::endl;
    
    // 백그라운드에서 테스트 실행 시뮬레이션
    std::thread simulationThread([]() {
        RealtimeMonitor& mon = RealtimeMonitor::Instance();
        
        for (int i = 0; i < 10; ++i) {
            if (mon.IsPaused()) {
                Sleep(500);
                continue;
            }
            
            std::string testId = "test_" + std::to_string(i);
            mon.NotifyTestStarted(testId, "Background Test " + std::to_string(i));
            
            Sleep(1000);
            
            mon.NotifyTestCompleted(testId, true);
            Sleep(500);
        }
    });
    
    // 사용자 입력 대기
    while (true) {
        if (_kbhit()) {
            char ch = _getch();
            
            switch (toupper(ch)) {
                case 'P':
                    PrintInfo("Pausing monitor...");
                    monitor.Pause();
                    break;
                    
                case 'R':
                    PrintInfo("Resuming monitor...");
                    monitor.Resume();
                    break;
                    
                case 'S': {
                    PrintInfo("Taking snapshot...");
                    auto snapshot = monitor.TakeSnapshot();
                    std::cout << "Snapshot:\n" << snapshot.dump(2) << std::endl;
                    break;
                }
                
                case 'Q':
                    PrintInfo("Quitting...");
                    goto exit_loop;
            }
        }
        
        Sleep(100);
    }
    
exit_loop:
    simulationThread.join();
    monitor.Stop();
    PrintSuccess("Interactive control demo completed");
}

// Demo 5: 실시간 대시보드
void Demo5_RealtimeDashboard() {
    PrintSection("Demo 5: Real-time Dashboard");
    
    RealtimeMonitor& monitor = RealtimeMonitor::Instance();
    monitor.Start();
    
    PrintInfo("Starting real-time dashboard...");
    std::cout << "Dashboard will update every second for 30 seconds" << std::endl;
    std::cout << "Press Ctrl+C to stop" << std::endl;
    std::cout << std::endl;
    
    // 백그라운드 테스트 시뮬레이션
    std::thread simulationThread([]() {
        RealtimeMonitor& mon = RealtimeMonitor::Instance();
        
        std::vector<std::string> techniques = {
            "DLL Injection",
            "Process Hollowing",
            "APC Injection",
            "Shellcode Injection",
            "Reflective DLL Injection"
        };
        
        for (size_t i = 0; i < techniques.size(); ++i) {
            std::string testId = "test_" + std::to_string(i);
            mon.NotifyTestStarted(testId, techniques[i]);
            
            for (int progress = 0; progress <= 100; progress += 10) {
                Sleep(300);
                mon.NotifyTestProgress(testId, progress, "Executing...");
            }
            
            bool success = (rand() % 100) > 15; // 85% 성공률
            mon.NotifyTestCompleted(testId, success);
            
            Sleep(500);
        }
    });
    
    // 대시보드 렌더링
    for (int i = 0; i < 30; ++i) {
        MonitorUtils::ClearConsole();
        MonitorUtils::SetCursorPosition(0, 0);
        
        // 헤더
    SetColor(14);
    std::cout << "+------------------------------------------------------------+" << std::endl;
    std::cout << "|           EDR Testing Tools - Live Dashboard              |" << std::endl;
    std::cout << "+------------------------------------------------------------+" << std::endl;
        SetColor(7);
        
        // 메트릭
        auto metrics = monitor.GetMetrics();
    std::cout << "\nOverall Metrics:" << std::endl;
        std::cout << "  Total Tests: " << metrics.totalTests << std::endl;
        std::cout << "  Completed: " << metrics.completedTests 
                  << " (" << (int)metrics.GetProgressPercent() << "%)" << std::endl;
        std::cout << "  Failed: " << metrics.failedTests << std::endl;
        
        // 진행률 바
    std::cout << "\n  Progress: " 
                  << MonitorUtils::CreateProgressBar(metrics.GetProgressPercent(), 40) 
                  << std::endl;
        
        // 테스트 상태
    std::cout << "\nTest Status:" << std::endl;
        auto statuses = monitor.GetTestStatuses();
        for (const auto& status : statuses) {
            switch (status.status) {
                case TestStatus::RUNNING:
                    SetColor(11);
                    std::cout << "  RUN  ";
                    break;
                case TestStatus::COMPLETED:
                    SetColor(10);
                    std::cout << "  DONE ";
                    break;
                case TestStatus::FAILED:
                    SetColor(12);
                    std::cout << "  FAIL ";
                    break;
                default:
                    SetColor(7);
                    std::cout << "  IDLE ";
            }
            
            std::cout << " " << status.testName;
            if (status.status == TestStatus::RUNNING) {
                std::cout << " (" << (int)status.progressPercent << "%)";
            }
            std::cout << std::endl;
            SetColor(7);
        }
        
        std::cout << "\nElapsed: " << i << "s / 30s" << std::endl;
        
        Sleep(1000);
    }
    
    simulationThread.join();
    monitor.Stop();
    
    MonitorUtils::ClearConsole();
    PrintSuccess("Real-time dashboard demo completed");
}

// 메인 메뉴
void ShowMenu() {
        std::cout << R"(
+--------------------------------------------------------------+
|   Test Customization & Real-time Monitoring Demo v1.0      |
+--------------------------------------------------------------+

Please select a demo:

    1. Basic Test Customization
    2. JSON Scenario Loading
    3. Real-time Monitoring
    4. Interactive Test Control
    5. Real-time Dashboard
    6. Run All Demos
    0. Exit

Enter choice: )" << std::endl;
}

int main(int argc, char* argv[]) {
    // 로거 초기화
    EDR::Logger::Instance().SetLevel(EDRLOG_INFO);
    EDR::Logger::Instance().EnableConsole(false); // 데모 출력과 분리
    
    std::cout << R"(
+--------------------------------------------------------------+
|                                                              |
|     Test Customization & Real-time Monitoring System        |
|                    Demonstration                             |
|                                                              |
|  This demo showcases advanced test customization and        |
|  real-time monitoring capabilities:                         |
|                                                              |
|  - Custom test definitions with parameters                  |
|  - JSON-based test scenarios                                |
|  - Real-time execution monitoring                           |
|  - Interactive test control                                 |
|  - Live dashboard with metrics                              |
|                                                              |
+--------------------------------------------------------------+
)" << std::endl;
    
    if (argc > 1 && std::string(argv[1]) == "--all") {
        // 모든 데모 실행
        Demo1_BasicCustomization();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo2_JSONScenario();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo3_RealtimeMonitoring();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo4_InteractiveControl();
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
        
        Demo5_RealtimeDashboard();
        
    } else {
        // 대화형 메뉴
        while (true) {
            ShowMenu();
            
            int choice;
            std::cin >> choice;
            
            if (choice == 0) {
                PrintInfo("Exiting demo...");
                break;
            }
            
            switch (choice) {
                case 1:
                    Demo1_BasicCustomization();
                    break;
                case 2:
                    Demo2_JSONScenario();
                    break;
                case 3:
                    Demo3_RealtimeMonitoring();
                    break;
                case 4:
                    Demo4_InteractiveControl();
                    break;
                case 5:
                    Demo5_RealtimeDashboard();
                    break;
                case 6:
                    Demo1_BasicCustomization();
                    std::cout << "\nPress Enter to continue...";
                    std::cin.ignore();
                    std::cin.get();
                    
                    Demo2_JSONScenario();
                    std::cout << "\nPress Enter to continue...";
                    std::cin.get();
                    
                    Demo3_RealtimeMonitoring();
                    std::cout << "\nPress Enter to continue...";
                    std::cin.get();
                    
                    Demo4_InteractiveControl();
                    std::cout << "\nPress Enter to continue...";
                    std::cin.get();
                    
                    Demo5_RealtimeDashboard();
                    break;
                default:
                    PrintError("Invalid choice. Please try again.");
            }
            
            if (choice != 0) {
                std::cout << "\nPress Enter to return to menu...";
                std::cin.ignore();
                std::cin.get();
            }
        }
    }
    
    std::cout << "\n\n";
    PrintSuccess("All demos completed!");
    std::cout << "\nTip: Run with --all flag to execute all demos automatically:" << std::endl;
    std::cout << "     test_customization_demo.exe --all" << std::endl;
    
    return 0;
}
