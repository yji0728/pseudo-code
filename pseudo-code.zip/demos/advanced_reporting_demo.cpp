/**
 * @file advanced_reporting_demo.cpp
 * @brief 향상된 리포팅 시스템 데모
 * @details
 * 데모 시나리오:
 * 1. HTML 대시보드 생성
 * 2. MITRE ATT&CK Navigator JSON 생성
 * 3. 통합 보고서 (모든 형식) 생성
 * 4. 커스터마이즈된 보고서 생성
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include "../include/detection_validator.hpp"
#include "../include/logger.hpp"
#include "../include/report_generator.hpp"

using namespace EDR;

// 콘솔 출력 색상 설정
void SetConsoleColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

// 배너 출력
void PrintBanner() {
    SetConsoleColor(11); // Cyan
    std::cout << R"(
╔══════════════════════════════════════════════════════════════╗
║          Advanced EDR Reporting System Demo                 ║
║              Enhanced Visualization & Export                ║
╚══════════════════════════════════════════════════════════════╝
)" << std::endl;
    SetConsoleColor(7); // White
}

// 구분선
void PrintSeparator() {
    std::cout << std::string(70, '=') << std::endl;
}

// 섹션 헤더
void PrintSectionHeader(const std::string& title) {
    PrintSeparator();
    SetConsoleColor(14); // Yellow
    std::cout << ">>> " << title << std::endl;
    SetConsoleColor(7);
    PrintSeparator();
}

// 샘플 보고서 데이터 생성
DetectionReport CreateSampleReport() {
    DetectionReport report;
    
    // 기본 통계 (실제 값은 Generator에서 계산되지만 데모용 기본값 설정)
    report.totalTechniques = 5;
    report.detectedTechniques = 3;
    report.overallDetectionRate = 0.6;
    report.averageDetectionLatency = std::chrono::milliseconds(1350);
    
    // 기법별 결과
    DetectionResult r1;
    r1.technique = "T1055.001";
    r1.techniqueName = "DLL Injection";
    r1.detected = true;
    r1.detectionMethods = {"ETW", "Sysmon"};
    r1.detectionLatency = std::chrono::milliseconds(1200);
    r1.detectionScore = 0.85;
    r1.etwEvents.resize(5);
    r1.sysmonEvents.resize(2);
    r1.windowsEvents.resize(1);
    report.results.push_back(r1);
    
    DetectionResult r2;
    r2.technique = "T1055.012";
    r2.techniqueName = "Process Hollowing";
    r2.detected = true;
    r2.detectionMethods = {"Sysmon", "Windows Event Log"};
    r2.detectionLatency = std::chrono::milliseconds(1300);
    r2.detectionScore = 0.72;
    r2.etwEvents.resize(0);
    r2.sysmonEvents.resize(4);
    r2.windowsEvents.resize(2);
    report.results.push_back(r2);
    
    DetectionResult r3;
    r3.technique = "T1055.004";
    r3.techniqueName = "APC Injection";
    r3.detected = true;
    r3.detectionMethods = {"ETW"};
    r3.detectionLatency = std::chrono::milliseconds(1550);
    r3.detectionScore = 0.65;
    r3.etwEvents.resize(7);
    r3.sysmonEvents.resize(2);
    r3.windowsEvents.resize(0);
    report.results.push_back(r3);
    
    DetectionResult r4;
    r4.technique = "T1055.002";
    r4.techniqueName = "Portable Executable Injection";
    r4.detected = false;
    r4.detectionLatency = std::chrono::milliseconds(0);
    r4.detectionScore = 0.0;
    r4.etwEvents.clear();
    r4.sysmonEvents.clear();
    r4.windowsEvents.clear();
    report.results.push_back(r4);
    
    DetectionResult r5;
    r5.technique = "T1055.003";
    r5.techniqueName = "Thread Execution Hijacking";
    r5.detected = false;
    r5.detectionLatency = std::chrono::milliseconds(0);
    r5.detectionScore = 0.0;
    r5.etwEvents.clear();
    r5.sysmonEvents.clear();
    r5.windowsEvents.clear();
    report.results.push_back(r5);
    
    return report;
}

/**
 * Demo 1: HTML 대시보드 생성
 */
void Demo1_GenerateHTMLDashboard() {
    PrintSectionHeader("Demo 1: HTML Dashboard Generation");
    
    try {
        std::cout << "Creating sample detection report..." << std::endl;
        DetectionReport report = CreateSampleReport();
        
        std::cout << "Initializing report generator..." << std::endl;
        ReportGenerator generator(report, "reports");
        
        std::cout << "Generating HTML dashboard..." << std::endl;
        if (generator.GenerateHTMLDashboard("demo_dashboard.html")) {
            SetConsoleColor(10); // Green
            std::cout << "\n[SUCCESS] HTML dashboard created!" << std::endl;
            std::cout << "Location: reports\\demo_dashboard.html" << std::endl;
            std::cout << "\nFeatures:" << std::endl;
            std::cout << "  - Interactive charts and graphs" << std::endl;
            std::cout << "  - Technique details with scores" << std::endl;
            std::cout << "  - Detection timeline visualization" << std::endl;
            std::cout << "  - Export to PDF/JSON/CSV buttons" << std::endl;
            SetConsoleColor(7);
        } else {
            SetConsoleColor(12); // Red
            std::cout << "[FAILED] Dashboard generation failed" << std::endl;
            SetConsoleColor(7);
        }
        
    } catch (const std::exception& e) {
        SetConsoleColor(12);
        std::cerr << "Error: " << e.what() << std::endl;
        SetConsoleColor(7);
    }
    
    std::cout << "\nPress Enter to continue...";
    std::cin.ignore();
    std::cin.get();
}

/**
 * Demo 2: MITRE ATT&CK Navigator JSON 생성
 */
void Demo2_GenerateAttackNavigator() {
    PrintSectionHeader("Demo 2: MITRE ATT&CK Navigator Export");
    
    try {
        std::cout << "Creating sample detection report..." << std::endl;
        DetectionReport report = CreateSampleReport();
        
        std::cout << "Initializing report generator..." << std::endl;
        ReportGenerator generator(report, "reports");
        
        std::cout << "Generating ATT&CK Navigator JSON..." << std::endl;
        if (generator.GenerateAttackNavigatorJSON("demo_navigator.json")) {
            SetConsoleColor(10);
            std::cout << "\n[SUCCESS] Navigator JSON created!" << std::endl;
            std::cout << "Location: reports\\demo_navigator.json" << std::endl;
            std::cout << "\nHow to use:" << std::endl;
            std::cout << "  1. Visit: https://mitre-attack.github.io/attack-navigator/" << std::endl;
            std::cout << "  2. Click 'Open Existing Layer'" << std::endl;
            std::cout << "  3. Select 'Upload from local'" << std::endl;
            std::cout << "  4. Choose demo_navigator.json" << std::endl;
            std::cout << "\nColor coding:" << std::endl;
            std::cout << "  Green  = High confidence detection (80%+)" << std::endl;
            std::cout << "  Yellow = Medium confidence detection (50-80%)" << std::endl;
            std::cout << "  Orange = Low confidence detection (<50%)" << std::endl;
            std::cout << "  Red    = Not detected" << std::endl;
            SetConsoleColor(7);
        } else {
            SetConsoleColor(12);
            std::cout << "[FAILED] Navigator JSON generation failed" << std::endl;
            SetConsoleColor(7);
        }
        
    } catch (const std::exception& e) {
        SetConsoleColor(12);
        std::cerr << "Error: " << e.what() << std::endl;
        SetConsoleColor(7);
    }
    
    std::cout << "\nPress Enter to continue...";
    std::cin.ignore();
    std::cin.get();
}

/**
 * Demo 3: 통합 보고서 생성 (모든 형식)
 */
void Demo3_GenerateAllReports() {
    PrintSectionHeader("Demo 3: Comprehensive Report Generation");
    
    try {
        std::cout << "Creating sample detection report..." << std::endl;
        DetectionReport report = CreateSampleReport();
        
        std::cout << "Initializing report generator..." << std::endl;
        ReportGenerator generator(report, "reports");
        
        std::cout << "\nGenerating all report formats..." << std::endl;
        std::cout << "This will create:" << std::endl;
        std::cout << "  1. HTML Dashboard (demo_dashboard.html)" << std::endl;
        std::cout << "  2. ATT&CK Navigator JSON (demo_navigator.json)" << std::endl;
        std::cout << "  3. Detection Report JSON (detection_report.json)" << std::endl;
        std::cout << "  4. Detection Report CSV (detection_report.csv)" << std::endl;
        std::cout << "  5. Summary Report TXT (summary.txt)" << std::endl;
        std::cout << "\nGenerating..." << std::endl;
        
        if (generator.GenerateAllReports()) {
            SetConsoleColor(10);
            std::cout << "\n[SUCCESS] All reports generated successfully!" << std::endl;
            std::cout << "\nGenerated files in 'reports' directory:" << std::endl;
            std::cout << "  ✓ HTML Dashboard (interactive web view)" << std::endl;
            std::cout << "  ✓ ATT&CK Navigator (MITRE matrix visualization)" << std::endl;
            std::cout << "  ✓ JSON Report (programmatic access)" << std::endl;
            std::cout << "  ✓ CSV Report (spreadsheet import)" << std::endl;
            std::cout << "  ✓ Text Summary (quick overview)" << std::endl;
            SetConsoleColor(7);
        } else {
            SetConsoleColor(12);
            std::cout << "\n[WARNING] Some reports failed to generate" << std::endl;
            std::cout << "Check logs for details" << std::endl;
            SetConsoleColor(7);
        }
        
    } catch (const std::exception& e) {
        SetConsoleColor(12);
        std::cerr << "Error: " << e.what() << std::endl;
        SetConsoleColor(7);
    }
    
    std::cout << "\nPress Enter to continue...";
    std::cin.ignore();
    std::cin.get();
}

/**
 * Demo 4: 실시간 보고서 업데이트 시뮬레이션
 */
void Demo4_RealtimeReporting() {
    PrintSectionHeader("Demo 4: Real-time Report Updates");
    
    try {
        std::cout << "Simulating real-time detection validation..." << std::endl;
        std::cout << "This demonstrates how reports can be updated as detections occur\n" << std::endl;
        
        DetectionReport report;
    report.totalTechniques = 3;
    report.detectedTechniques = 0;
    report.overallDetectionRate = 0.0;
    report.averageDetectionLatency = std::chrono::milliseconds(0);
        
        ReportGenerator generator(report, "reports");
        
        // 시뮬레이션: 순차적으로 탐지 발생
        std::vector<DetectionResult> results;
        {
            DetectionResult x; x.technique="T1055.001"; x.techniqueName="DLL Injection"; x.detected=true; x.detectionMethods={"ETW","Sysmon"}; x.detectionLatency=std::chrono::milliseconds(1200); x.detectionScore=0.85; x.etwEvents.resize(5); x.sysmonEvents.resize(2); x.windowsEvents.resize(1); results.push_back(x);
        }
        {
            DetectionResult x; x.technique="T1055.012"; x.techniqueName="Process Hollowing"; x.detected=true; x.detectionMethods={"Sysmon"}; x.detectionLatency=std::chrono::milliseconds(1300); x.detectionScore=0.72; x.etwEvents.resize(0); x.sysmonEvents.resize(4); x.windowsEvents.resize(2); results.push_back(x);
        }
        {
            DetectionResult x; x.technique="T1055.004"; x.techniqueName="APC Injection"; x.detected=true; x.detectionMethods={"ETW"}; x.detectionLatency=std::chrono::milliseconds(1550); x.detectionScore=0.65; x.etwEvents.resize(7); x.sysmonEvents.resize(2); x.windowsEvents.resize(0); results.push_back(x);
        }
        
        for (size_t i = 0; i < results.size(); ++i) {
            std::cout << "\n[" << (i + 1) << "/" << results.size() << "] ";
            std::cout << "Testing " << results[i].technique << "..." << std::endl;
            
            Sleep(1000); // 시뮬레이션 딜레이
            
            // 결과 추가
            report.results.push_back(results[i]);
            report.detectedTechniques++;
            report.overallDetectionRate = 
                static_cast<double>(report.detectedTechniques) / (i + 1);
            
            SetConsoleColor(10);
            std::cout << "  ✓ " << results[i].techniqueName << " detected!" << std::endl;
            SetConsoleColor(7);
            std::cout << "    Methods: ";
            for (size_t j = 0; j < results[i].detectionMethods.size(); ++j) {
                std::cout << results[i].detectionMethods[j];
                if (j < results[i].detectionMethods.size() - 1) std::cout << ", ";
            }
            std::cout << std::endl;
            std::cout << "    Score: " << (results[i].detectionScore * 100) << "%" << std::endl;
            
            // 보고서 업데이트
            std::string filename = "realtime_report_" + std::to_string(i + 1) + ".html";
            generator.GenerateHTMLDashboard(filename);
            std::cout << "    Report updated: reports\\" << filename << std::endl;
        }
        
        SetConsoleColor(10);
        std::cout << "\n[SUCCESS] Real-time reporting simulation completed!" << std::endl;
        std::cout << "Check the reports directory for incremental updates" << std::endl;
        SetConsoleColor(7);
        
    } catch (const std::exception& e) {
        SetConsoleColor(12);
        std::cerr << "Error: " << e.what() << std::endl;
        SetConsoleColor(7);
    }
    
    std::cout << "\nPress Enter to continue...";
    std::cin.ignore();
    std::cin.get();
}

// 메뉴 표시
void DisplayMenu() {
    PrintSeparator();
    SetConsoleColor(11);
    std::cout << "Select a demo scenario:" << std::endl;
    SetConsoleColor(7);
    std::cout << "  1. Generate HTML Dashboard" << std::endl;
    std::cout << "  2. Generate ATT&CK Navigator JSON" << std::endl;
    std::cout << "  3. Generate All Reports (Comprehensive)" << std::endl;
    std::cout << "  4. Real-time Reporting Simulation" << std::endl;
    std::cout << "  0. Exit" << std::endl;
    PrintSeparator();
    std::cout << "Enter your choice: ";
}

int main() {
    // 로거 초기화
    Logger::Instance().SetLevel(Logger::Level::INFO);
    Logger::Instance().SetOutputFile("reports/advanced_reporting_demo.log");
    
    PrintBanner();
    
    std::cout << "This demo showcases the enhanced reporting capabilities:\n" << std::endl;
    std::cout << "✓ Interactive HTML dashboards with charts" << std::endl;
    std::cout << "✓ MITRE ATT&CK Navigator integration" << std::endl;
    std::cout << "✓ Multiple export formats (HTML/JSON/CSV/TXT)" << std::endl;
    std::cout << "✓ Real-time report updates" << std::endl;
    std::cout << "✓ Professional visualization and formatting" << std::endl;
    
    std::cout << "\nPress Enter to start...";
    std::cin.get();
    
    int choice;
    do {
        system("cls");
        PrintBanner();
        DisplayMenu();
        
        std::cin >> choice;
        std::cin.ignore();
        
        system("cls");
        PrintBanner();
        
        switch (choice) {
            case 1:
                Demo1_GenerateHTMLDashboard();
                break;
            case 2:
                Demo2_GenerateAttackNavigator();
                break;
            case 3:
                Demo3_GenerateAllReports();
                break;
            case 4:
                Demo4_RealtimeReporting();
                break;
            case 0:
                SetConsoleColor(11);
                std::cout << "\nThank you for using Advanced EDR Reporting System!" << std::endl;
                SetConsoleColor(7);
                break;
            default:
                SetConsoleColor(12);
                std::cout << "\nInvalid choice. Please try again." << std::endl;
                SetConsoleColor(7);
                Sleep(2000);
        }
        
    } while (choice != 0);
    
    return 0;
}
