/*
 * Performance Monitoring Demo - EDR Testing Tools
 * 
 * Purpose: Demonstrate performance monitoring capabilities
 * 
 * This demo shows:
 * - How to use PerformanceMonitor class
 * - Measuring execution time, memory, CPU, and I/O
 * - Exporting results to CSV and JSON
 * - Comparing performance across techniques
 * 
 * Techniques demonstrated:
 * 1. Memory allocation simulation
 * 2. CPU-intensive operation
 * 3. Disk I/O operation
 * 4. Process creation
 */

#include <windows.h>
#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include "../include/performance_monitor.hpp"
#include "../include/logger.hpp"
#include "../include/error_handling.hpp"

using namespace EDR;

// Demo 1: Memory allocation test
void DemoMemoryAllocation(PerformanceMonitor& monitor) {
    monitor.StartMeasurement("Memory Allocation", 
                            "Allocate and fill 100MB of memory");
    
    try {
        std::cout << "\n[Demo 1] Memory Allocation Test\n";
        std::cout << "Allocating 100MB of memory...\n";
        
        const size_t size = 100 * 1024 * 1024; // 100 MB
        std::vector<char> buffer(size);
        
        // Fill with data to ensure physical memory allocation
        std::cout << "Filling memory with data...\n";
        for (size_t i = 0; i < size; i += 4096) {
            buffer[i] = static_cast<char>(i % 256);
        }
        
        std::cout << "Memory allocated and filled.\n";
        Sleep(1000); // Hold memory for 1 second
        
        // buffer will be deallocated here
        std::cout << "Releasing memory...\n";
        
        monitor.SetSuccess(true);
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        monitor.SetSuccess(false);
    }
    
    auto metrics = monitor.StopMeasurement();
    std::cout << "[+] Peak memory usage: " 
              << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << " MB\n";
}

// Demo 2: CPU-intensive operation
void DemoCPUIntensive(PerformanceMonitor& monitor) {
    monitor.StartMeasurement("CPU Intensive", 
                            "Calculate primes up to 100,000");
    
    try {
        std::cout << "\n[Demo 2] CPU-Intensive Test\n";
        std::cout << "Calculating prime numbers up to 100,000...\n";
        
        std::vector<int> primes;
        for (int n = 2; n <= 100000; ++n) {
            bool isPrime = true;
            for (int i = 2; i * i <= n; ++i) {
                if (n % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                primes.push_back(n);
            }
        }
        
        std::cout << "[+] Found " << primes.size() << " prime numbers\n";
        monitor.SetSuccess(true);
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        monitor.SetSuccess(false);
    }
    
    auto metrics = monitor.StopMeasurement();
    std::cout << "[+] CPU usage: " << metrics.cpuUsagePercent << " %\n";
    std::cout << "[+] Execution time: " 
              << (metrics.executionTime.count() / 1000.0) << " ms\n";
}

// Demo 3: Disk I/O operation
void DemoDiskIO(PerformanceMonitor& monitor) {
    monitor.StartMeasurement("Disk I/O", 
                            "Write and read 10MB test file");
    
    const std::string testFile = "perf_test_file.tmp";
    
    try {
        std::cout << "\n[Demo 3] Disk I/O Test\n";
        
        // Write test
        std::cout << "Writing 10MB to disk...\n";
        {
            std::ofstream file(testFile, std::ios::binary);
            if (!file.is_open()) {
                throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                               "Failed to create test file",
                               "DemoDiskIO", __FILE__, __LINE__);
            }
            
            const size_t size = 10 * 1024 * 1024; // 10 MB
            std::vector<char> data(size, 'A');
            file.write(data.data(), size);
        }
        
        // Read test
        std::cout << "Reading 10MB from disk...\n";
        {
            std::ifstream file(testFile, std::ios::binary);
            if (!file.is_open()) {
                throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                               "Failed to open test file",
                               "DemoDiskIO", __FILE__, __LINE__);
            }
            
            file.seekg(0, std::ios::end);
            size_t size = file.tellg();
            file.seekg(0, std::ios::beg);
            
            std::vector<char> data(size);
            file.read(data.data(), size);
        }
        
        // Cleanup
        DeleteFileA(testFile.c_str());
        
        std::cout << "[+] Disk I/O completed\n";
        monitor.SetSuccess(true);
        
    } catch (const Exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        DeleteFileA(testFile.c_str());
        monitor.SetSuccess(false);
    }
    
    auto metrics = monitor.StopMeasurement();
    std::cout << "[+] Disk read: " << (metrics.diskBytesRead / 1024.0) << " KB\n";
    std::cout << "[+] Disk write: " << (metrics.diskBytesWritten / 1024.0) << " KB\n";
}

// Demo 4: Process creation (simulating injection technique)
void DemoProcessCreation(PerformanceMonitor& monitor) {
    monitor.StartMeasurement("Process Creation", 
                            "Create and terminate notepad.exe");
    
    try {
        std::cout << "\n[Demo 4] Process Creation Test\n";
        std::cout << "Creating notepad.exe...\n";
        
        STARTUPINFOW si = { sizeof(si) };
        PROCESS_INFORMATION pi;
        ZeroMemory(&pi, sizeof(pi));
        
        if (!CreateProcessW(
            L"C:\\Windows\\System32\\notepad.exe",
            NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            throw Exception(ErrorCode::PROCESS_NOT_FOUND,
                           "Failed to create process",
                           "DemoProcessCreation", __FILE__, __LINE__);
        }
        
        HandleGuard hProcess(pi.hProcess);
        HandleGuard hThread(pi.hThread);
        
        std::cout << "[+] Process created (PID: " << pi.dwProcessId << ")\n";
        Sleep(2000); // Let process run for 2 seconds
        
        std::cout << "Terminating process...\n";
        if (!TerminateProcess(hProcess.get(), 0)) {
            LOG_WARN("Failed to terminate process");
        }
        
        std::cout << "[+] Process terminated\n";
        monitor.SetSuccess(true);
        
    } catch (const Exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        monitor.SetSuccess(false);
    }
    
    auto metrics = monitor.StopMeasurement();
    std::cout << "[+] Total execution time: " 
              << (metrics.executionTime.count() / 1000.0) << " ms\n";
}

// Demo 5: Comparison test - Multiple iterations
void DemoComparison(PerformanceMonitor& monitor) {
    std::cout << "\n[Demo 5] Performance Comparison Test\n";
    std::cout << "Running 5 iterations of quick memory allocation...\n\n";
    
    for (int i = 1; i <= 5; ++i) {
        std::string name = "Iteration " + std::to_string(i);
        monitor.StartMeasurement(name, "Quick memory allocation test");
        
        try {
            // Small memory allocation
            const size_t size = 10 * 1024 * 1024; // 10 MB
            std::vector<char> buffer(size, 0);
            
            // Simulate some work
            std::this_thread::sleep_for(std::chrono::milliseconds(100 + (i * 50)));
            
            monitor.SetSuccess(true);
            
        } catch (...) {
            monitor.SetSuccess(false);
        }
        
        monitor.StopMeasurement();
        std::cout << "  Iteration " << i << " completed\n";
    }
    
    std::cout << "\n[+] Comparison test completed\n";
}

int main() {
    try {
        // Initialize logger
        auto& logger = Logger::Instance();
        logger.SetLevel(EDRLOG_INFO);
        logger.SetOutputFile("performance_demo.log");
        logger.EnableConsole(false); // Avoid duplicate output
        
        LOG_INFO("=== Performance Monitoring Demo Started ===");
        
        std::cout << "======================================================\n";
        std::cout << "    EDR Performance Monitoring Demo\n";
        std::cout << "======================================================\n";
        
        // Create performance monitor
        PerformanceMonitor monitor;
        
        // Run demos
        DemoMemoryAllocation(monitor);
        DemoCPUIntensive(monitor);
        DemoDiskIO(monitor);
        DemoProcessCreation(monitor);
        DemoComparison(monitor);
        
        // Print summary
        std::cout << "\n";
        monitor.PrintSummary();
        
        // Export results
        std::cout << "\nExporting results...\n";
        
        try {
            monitor.ExportToCSV("performance_results.csv");
            std::cout << "[+] CSV exported: performance_results.csv\n";
            
            monitor.ExportToJSON("performance_results.json");
            std::cout << "[+] JSON exported: performance_results.json\n";
            
        } catch (const Exception& e) {
            std::cerr << "[-] Export failed: " << e.what() << "\n";
        }
        
        std::cout << "\n======================================================\n";
        std::cout << "Demo completed successfully!\n";
        std::cout << "Check performance_demo.log for detailed logs.\n";
        std::cout << "======================================================\n";
        
        LOG_INFO("=== Performance Monitoring Demo Completed Successfully ===");
        return 0;
        
    } catch (const Exception& e) {
        std::cerr << "\n[FATAL ERROR] " << e.what() << "\n";
        std::cerr << "Error Code: " << static_cast<int>(e.code()) << "\n";
        LOG_ERROR(std::string("Fatal error: ") + e.what());
        return 1;
        
    } catch (const std::exception& e) {
        std::cerr << "\n[FATAL ERROR] Unexpected: " << e.what() << "\n";
        LOG_ERROR(std::string("Unexpected error: ") + e.what());
        return 1;
        
    } catch (...) {
        std::cerr << "\n[FATAL ERROR] Unknown error occurred\n";
        LOG_ERROR("Unknown fatal error");
        return 1;
    }
}
