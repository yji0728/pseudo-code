/*
 * EDR Testing Tools - Error Handling System
 * 
 * Purpose: Provide robust error handling and exception safety
 * 
 * Features:
 * - Structured error codes
 * - Exception hierarchy
 * - RAII resource management
 * - Automatic cleanup
 * - Error context tracking
 * 
 * Usage:
 *   try {
 *       HandleGuard hProcess(OpenProcess(...));
 *       if (!hProcess) {
 *           throw EDRException(EDRErrorCode::PROCESS_NOT_FOUND, "Failed to open process");
 *       }
 *   } catch (const EDRException& e) {
 *       LOG_ERROR(e.what());
 *   }
 */

#ifndef EDR_ERROR_HANDLING_HPP
#define EDR_ERROR_HANDLING_HPP

#include <windows.h>
#include <string>
#include <exception>
#include <memory>
#include <sstream>
#include <vector>
#include "logger.hpp"

namespace EDR {

// Error codes
enum class ErrorCode {
    SUCCESS = 0,
    
    // Process related (1xxx)
    PROCESS_NOT_FOUND = 1001,
    PROCESS_ACCESS_DENIED = 1002,
    PROCESS_TERMINATED = 1003,
    PROCESS_SUSPENDED = 1004,
    
    // Memory related (2xxx)
    MEMORY_ALLOCATION_FAILED = 2001,
    MEMORY_PROTECTION_FAILED = 2002,
    MEMORY_WRITE_FAILED = 2003,
    MEMORY_READ_FAILED = 2004,
    
    // Injection related (3xxx)
    INJECTION_FAILED = 3001,
    DLL_NOT_FOUND = 3002,
    THREAD_CREATION_FAILED = 3003,
    REMOTE_THREAD_FAILED = 3004,
    
    // File/Resource related (4xxx)
    FILE_NOT_FOUND = 4001,
    FILE_ACCESS_DENIED = 4002,
    FILE_INVALID_FORMAT = 4003,
    RESOURCE_EXHAUSTED = 4004,
    
    // Permission related (5xxx)
    PERMISSION_DENIED = 5001,
    ELEVATION_REQUIRED = 5002,
    
    // Parameter related (6xxx)
    INVALID_PARAMETER = 6001,
    NULL_POINTER = 6002,
    BUFFER_TOO_SMALL = 6003,
    
    // System related (7xxx)
    SYSTEM_CALL_FAILED = 7001,
    API_NOT_AVAILABLE = 7002,
    INCOMPATIBLE_OS = 7003,
    
    // Unknown
    UNKNOWN_ERROR = 9999
};

// Exception class
class Exception : public std::exception {
public:
    Exception(ErrorCode code, const std::string& message, 
              const std::string& context = "",
              const char* file = nullptr, int line = 0)
        : code_(code)
        , message_(message)
        , context_(context)
        , file_(file ? file : "")
        , line_(line)
        , systemError_(GetLastError())
    {
        FormatFullMessage();
    }

    const char* what() const noexcept override {
        return fullMessage_.c_str();
    }

    ErrorCode code() const noexcept { return code_; }
    const std::string& message() const noexcept { return message_; }
    const std::string& context() const noexcept { return context_; }
    DWORD systemError() const noexcept { return systemError_; }
    
    std::string GetErrorCodeName() const {
        return GetErrorCodeName(code_);
    }
    
    static std::string GetErrorCodeName(ErrorCode code) {
        switch (code) {
            case ErrorCode::SUCCESS: return "SUCCESS";
            case ErrorCode::PROCESS_NOT_FOUND: return "PROCESS_NOT_FOUND";
            case ErrorCode::PROCESS_ACCESS_DENIED: return "PROCESS_ACCESS_DENIED";
            case ErrorCode::PROCESS_TERMINATED: return "PROCESS_TERMINATED";
            case ErrorCode::PROCESS_SUSPENDED: return "PROCESS_SUSPENDED";
            case ErrorCode::MEMORY_ALLOCATION_FAILED: return "MEMORY_ALLOCATION_FAILED";
            case ErrorCode::MEMORY_PROTECTION_FAILED: return "MEMORY_PROTECTION_FAILED";
            case ErrorCode::MEMORY_WRITE_FAILED: return "MEMORY_WRITE_FAILED";
            case ErrorCode::MEMORY_READ_FAILED: return "MEMORY_READ_FAILED";
            case ErrorCode::INJECTION_FAILED: return "INJECTION_FAILED";
            case ErrorCode::DLL_NOT_FOUND: return "DLL_NOT_FOUND";
            case ErrorCode::THREAD_CREATION_FAILED: return "THREAD_CREATION_FAILED";
            case ErrorCode::REMOTE_THREAD_FAILED: return "REMOTE_THREAD_FAILED";
            case ErrorCode::FILE_NOT_FOUND: return "FILE_NOT_FOUND";
            case ErrorCode::FILE_ACCESS_DENIED: return "FILE_ACCESS_DENIED";
            case ErrorCode::FILE_INVALID_FORMAT: return "FILE_INVALID_FORMAT";
            case ErrorCode::RESOURCE_EXHAUSTED: return "RESOURCE_EXHAUSTED";
            case ErrorCode::PERMISSION_DENIED: return "PERMISSION_DENIED";
            case ErrorCode::ELEVATION_REQUIRED: return "ELEVATION_REQUIRED";
            case ErrorCode::INVALID_PARAMETER: return "INVALID_PARAMETER";
            case ErrorCode::NULL_POINTER: return "NULL_POINTER";
            case ErrorCode::BUFFER_TOO_SMALL: return "BUFFER_TOO_SMALL";
            case ErrorCode::SYSTEM_CALL_FAILED: return "SYSTEM_CALL_FAILED";
            case ErrorCode::API_NOT_AVAILABLE: return "API_NOT_AVAILABLE";
            case ErrorCode::INCOMPATIBLE_OS: return "INCOMPATIBLE_OS";
            case ErrorCode::UNKNOWN_ERROR: return "UNKNOWN_ERROR";
            default: return "UNKNOWN";
        }
    }

private:
    void FormatFullMessage() {
        std::stringstream ss;
        ss << "[" << GetErrorCodeName() << "] " << message_;
        
        if (!context_.empty()) {
            ss << " (Context: " << context_ << ")";
        }
        
        if (systemError_ != 0) {
            ss << " [System Error: " << systemError_;
            
            // Get system error message
            char* msgBuf = nullptr;
            FormatMessageA(
                FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
                NULL,
                systemError_,
                MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                (LPSTR)&msgBuf,
                0,
                NULL
            );
            
            if (msgBuf) {
                ss << " - " << msgBuf;
                LocalFree(msgBuf);
            }
            
            ss << "]";
        }
        
        if (!file_.empty() && line_ > 0) {
            ss << " at " << file_ << ":" << line_;
        }
        
        fullMessage_ = ss.str();
    }

private:
    ErrorCode code_;
    std::string message_;
    std::string context_;
    std::string file_;
    int line_;
    DWORD systemError_;
    std::string fullMessage_;
};

// RAII Handle Guard
class HandleGuard {
public:
    HandleGuard() : handle_(NULL) {}
    
    explicit HandleGuard(HANDLE h) : handle_(h) {}
    
    ~HandleGuard() {
        Close();
    }
    
    // Move semantics
    HandleGuard(HandleGuard&& other) noexcept : handle_(other.handle_) {
        other.handle_ = NULL;
    }
    
    HandleGuard& operator=(HandleGuard&& other) noexcept {
        if (this != &other) {
            Close();
            handle_ = other.handle_;
            other.handle_ = NULL;
        }
        return *this;
    }
    
    // Delete copy
    HandleGuard(const HandleGuard&) = delete;
    HandleGuard& operator=(const HandleGuard&) = delete;
    
    HANDLE get() const { return handle_; }
    HANDLE* getPtr() { return &handle_; }
    
    HANDLE release() {
        HANDLE h = handle_;
        handle_ = NULL;
        return h;
    }
    
    void reset(HANDLE h = NULL) {
        Close();
        handle_ = h;
    }
    
    bool isValid() const {
        return handle_ != NULL && handle_ != INVALID_HANDLE_VALUE;
    }
    
    operator bool() const {
        return isValid();
    }
    
    operator HANDLE() const {
        return handle_;
    }

private:
    void Close() {
        if (isValid()) {
            CloseHandle(handle_);
            handle_ = NULL;
        }
    }

private:
    HANDLE handle_;
};

// RAII Virtual Memory Guard
class VirtualMemoryGuard {
public:
    VirtualMemoryGuard() : process_(NULL), address_(nullptr), size_(0) {}
    
    VirtualMemoryGuard(HANDLE process, LPVOID address, SIZE_T size)
        : process_(process), address_(address), size_(size) {}
    
    ~VirtualMemoryGuard() {
        Free();
    }
    
    // Move semantics
    VirtualMemoryGuard(VirtualMemoryGuard&& other) noexcept
        : process_(other.process_)
        , address_(other.address_)
        , size_(other.size_)
    {
        other.process_ = NULL;
        other.address_ = nullptr;
        other.size_ = 0;
    }
    
    VirtualMemoryGuard& operator=(VirtualMemoryGuard&& other) noexcept {
        if (this != &other) {
            Free();
            process_ = other.process_;
            address_ = other.address_;
            size_ = other.size_;
            other.process_ = NULL;
            other.address_ = nullptr;
            other.size_ = 0;
        }
        return *this;
    }
    
    // Delete copy
    VirtualMemoryGuard(const VirtualMemoryGuard&) = delete;
    VirtualMemoryGuard& operator=(const VirtualMemoryGuard&) = delete;
    
    LPVOID get() const { return address_; }
    SIZE_T size() const { return size_; }
    
    LPVOID release() {
        LPVOID addr = address_;
        address_ = nullptr;
        size_ = 0;
        return addr;
    }
    
    void reset(HANDLE process = NULL, LPVOID address = nullptr, SIZE_T size = 0) {
        Free();
        process_ = process;
        address_ = address;
        size_ = size;
    }
    
    bool isValid() const {
        return address_ != nullptr;
    }
    
    operator bool() const {
        return isValid();
    }
    
    operator LPVOID() const {
        return address_;
    }

private:
    void Free() {
        if (isValid() && process_) {
            VirtualFreeEx(process_, address_, 0, MEM_RELEASE);
            address_ = nullptr;
            size_ = 0;
        }
    }

private:
    HANDLE process_;
    LPVOID address_;
    SIZE_T size_;
};

// Helper function to allocate memory with VirtualAllocEx
inline VirtualMemoryGuard AllocateMemoryGuard(HANDLE process, SIZE_T size, DWORD protection) {
    LPVOID address = VirtualAllocEx(process, NULL, size, MEM_COMMIT | MEM_RESERVE, protection);
    if (!address) {
        throw Exception(ErrorCode::MEMORY_ALLOCATION_FAILED,
                       "Failed to allocate remote memory",
                       "VirtualAllocEx");
    }
    return VirtualMemoryGuard(process, address, size);
}

// RAII Library Guard
class LibraryGuard {
public:
    LibraryGuard() : module_(NULL) {}
    
    explicit LibraryGuard(HMODULE module) : module_(module) {}
    
    ~LibraryGuard() {
        Free();
    }
    
    // Move semantics
    LibraryGuard(LibraryGuard&& other) noexcept : module_(other.module_) {
        other.module_ = NULL;
    }
    
    LibraryGuard& operator=(LibraryGuard&& other) noexcept {
        if (this != &other) {
            Free();
            module_ = other.module_;
            other.module_ = NULL;
        }
        return *this;
    }
    
    // Delete copy
    LibraryGuard(const LibraryGuard&) = delete;
    LibraryGuard& operator=(const LibraryGuard&) = delete;
    
    HMODULE get() const { return module_; }
    
    HMODULE release() {
        HMODULE m = module_;
        module_ = NULL;
        return m;
    }
    
    void reset(HMODULE module = NULL) {
        Free();
        module_ = module;
    }
    
    bool isValid() const {
        return module_ != NULL;
    }
    
    operator bool() const {
        return isValid();
    }
    
    operator HMODULE() const {
        return module_;
    }

private:
    void Free() {
        if (isValid()) {
            FreeLibrary(module_);
            module_ = NULL;
        }
    }

private:
    HMODULE module_;
};

// RAII File Handle Guard
class FileHandleGuard {
public:
    FileHandleGuard() : handle_(INVALID_HANDLE_VALUE) {}
    
    explicit FileHandleGuard(HANDLE h) : handle_(h) {}
    
    ~FileHandleGuard() {
        Close();
    }
    
    // Move semantics
    FileHandleGuard(FileHandleGuard&& other) noexcept : handle_(other.handle_) {
        other.handle_ = INVALID_HANDLE_VALUE;
    }
    
    FileHandleGuard& operator=(FileHandleGuard&& other) noexcept {
        if (this != &other) {
            Close();
            handle_ = other.handle_;
            other.handle_ = INVALID_HANDLE_VALUE;
        }
        return *this;
    }
    
    // Delete copy
    FileHandleGuard(const FileHandleGuard&) = delete;
    FileHandleGuard& operator=(const FileHandleGuard&) = delete;
    
    HANDLE get() const { return handle_; }
    
    HANDLE release() {
        HANDLE h = handle_;
        handle_ = INVALID_HANDLE_VALUE;
        return h;
    }
    
    void reset(HANDLE h = INVALID_HANDLE_VALUE) {
        Close();
        handle_ = h;
    }
    
    bool isValid() const {
        return handle_ != INVALID_HANDLE_VALUE;
    }
    
    operator bool() const {
        return isValid();
    }
    
    operator HANDLE() const {
        return handle_;
    }

private:
    void Close() {
        if (isValid()) {
            CloseHandle(handle_);
            handle_ = INVALID_HANDLE_VALUE;
        }
    }

private:
    HANDLE handle_;
};

// Scope guard for generic cleanup
template<typename F>
class ScopeGuard {
public:
    explicit ScopeGuard(F&& f) : func_(std::forward<F>(f)), active_(true) {}
    
    ~ScopeGuard() {
        if (active_) {
            func_();
        }
    }
    
    void dismiss() {
        active_ = false;
    }
    
    // Delete copy and move
    ScopeGuard(const ScopeGuard&) = delete;
    ScopeGuard& operator=(const ScopeGuard&) = delete;
    ScopeGuard(ScopeGuard&&) = delete;
    ScopeGuard& operator=(ScopeGuard&&) = delete;

private:
    F func_;
    bool active_;
};

template<typename F>
ScopeGuard<F> MakeScopeGuard(F&& f) {
    return ScopeGuard<F>(std::forward<F>(f));
}

// Helper macros
#define THROW_EDR_ERROR(code, msg) \
    throw EDR::Exception(code, msg, "", __FILE__, __LINE__)

#define THROW_EDR_ERROR_CTX(code, msg, ctx) \
    throw EDR::Exception(code, msg, ctx, __FILE__, __LINE__)

#define CHECK_HANDLE(h, msg) \
    if (!(h) || (h) == INVALID_HANDLE_VALUE) { \
        THROW_EDR_ERROR(EDR::ErrorCode::INVALID_PARAMETER, msg); \
    }

#define CHECK_POINTER(p, msg) \
    if (!(p)) { \
        THROW_EDR_ERROR(EDR::ErrorCode::NULL_POINTER, msg); \
    }

#define ON_SCOPE_EXIT(code) \
    auto CONCAT(scopeGuard, __LINE__) = EDR::MakeScopeGuard([&]() { code; })

// Type aliases for convenience
using MemoryGuard = VirtualMemoryGuard;

} // namespace EDR

#endif // EDR_ERROR_HANDLING_HPP
