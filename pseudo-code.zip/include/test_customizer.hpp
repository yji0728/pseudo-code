/**
 * @file test_customizer.hpp
 * @brief 테스트 커스터마이징 시스템 (Test Customization System)
 * @details
 * JSON 기반 테스트 시나리오 정의 및 실행 커스터마이징
 * - 기법별 파라미터 설정
 * - 조건부 실행 규칙
 * - 테스트 체인 (순차/병렬)
 * - 사용자 정의 셸코드
 * - 동적 파라미터 바인딩
 * 
 * @author GitHub Copilot
 * @date 2025-01-XX
 */

#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#ifdef ERROR
#undef ERROR
#endif
#ifdef DEBUG
#undef DEBUG
#endif
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <chrono>
#include "json.hpp"
#include "logger.hpp"
#include "error_handling.hpp"

using json = nlohmann::json;

namespace EDR {

/**
 * @brief 테스트 실행 모드
 */
enum class ExecutionMode {
    SEQUENTIAL,     ///< 순차 실행
    PARALLEL,       ///< 병렬 실행
    CONDITIONAL,    ///< 조건부 실행
    CHAIN           ///< 체인 실행 (이전 결과에 따라)
};

/**
 * @brief 테스트 파라미터 타입
 */
enum class ParameterType {
    STRING,
    INTEGER,
    BOOLEAN,
    PROCESS_ID,
    SHELLCODE,
    FILE_PATH,
    REGISTRY_KEY
};

/**
 * @brief 테스트 파라미터
 */
struct TestParameter {
    std::string name;
    ParameterType type;
    json value;
    std::string description;
    bool required;
    json defaultValue;
    
    TestParameter() : type(ParameterType::STRING), required(false) {}
    
    TestParameter(const std::string& n, ParameterType t, const json& v, 
                  const std::string& desc = "", bool req = true)
        : name(n), type(t), value(v), description(desc), required(req) {}
};

/**
 * @brief 실행 조건
 */
struct ExecutionCondition {
    std::string conditionType;  ///< "process_exists", "memory_available", "os_version", etc.
    json parameters;
    bool negate;                ///< 조건 반전
    
    ExecutionCondition() : negate(false) {}
    
    /**
     * @brief 조건 평가
     */
    bool Evaluate() const;
};

/**
 * @brief 테스트 결과
 */
struct TestResult {
    std::string techniqueId;
    std::string techniqueName;
    bool success;
    std::chrono::milliseconds duration;
    std::string output;
    std::string errorMessage;
    json metrics;
    std::vector<std::string> detectionEvents;
    
    TestResult() : success(false), duration(0) {}
};

/**
 * @brief 커스텀 테스트 정의
 */
class CustomTest {
public:
    std::string id;
    std::string name;
    std::string description;
    std::string techniqueId;        ///< MITRE ATT&CK ID
    std::string category;
    
    // 실행 설정
    ExecutionMode executionMode;
    int priority;                   ///< 실행 우선순위 (높을수록 먼저)
    int maxRetries;
    std::chrono::seconds timeout;
    
    // 파라미터
    std::vector<TestParameter> parameters;
    
    // 조건
    std::vector<ExecutionCondition> preconditions;
    std::vector<ExecutionCondition> postconditions;
    
    // 의존성
    std::vector<std::string> dependencies;  ///< 선행 테스트 ID
    
    // 실행 함수
    std::function<TestResult(const std::map<std::string, json>&)> executeFunction;
    
    CustomTest() 
        : executionMode(ExecutionMode::SEQUENTIAL)
        , priority(0)
        , maxRetries(1)
        , timeout(60) {}
    
    /**
     * @brief JSON에서 테스트 로드
     */
    static CustomTest FromJSON(const json& j);
    
    /**
     * @brief JSON으로 내보내기
     */
    json ToJSON() const;
    
    /**
     * @brief 테스트 검증
     */
    bool Validate() const;
    
    /**
     * @brief 파라미터 설정
     */
    void SetParameter(const std::string& name, const json& value);
    
    /**
     * @brief 파라미터 가져오기
     */
    json GetParameter(const std::string& name) const;
};

/**
 * @brief 테스트 체인 (연속된 테스트들)
 */
class TestChain {
public:
    std::string id;
    std::string name;
    std::string description;
    
    std::vector<std::string> testIds;   ///< 실행할 테스트 ID 목록
    ExecutionMode executionMode;
    
    // 체인 옵션
    bool stopOnFirstFailure;
    bool shareContext;              ///< 테스트 간 컨텍스트 공유
    
    TestChain() 
        : executionMode(ExecutionMode::SEQUENTIAL)
        , stopOnFirstFailure(false)
        , shareContext(false) {}
    
    /**
     * @brief JSON에서 로드
     */
    static TestChain FromJSON(const json& j);
    
    /**
     * @brief JSON으로 내보내기
     */
    json ToJSON() const;
};

/**
 * @brief 테스트 시나리오 (여러 테스트/체인의 조합)
 */
class TestScenario {
public:
    std::string id;
    std::string name;
    std::string description;
    std::string author;
    std::string version;
    
    std::vector<CustomTest> tests;
    std::vector<TestChain> chains;
    
    // 시나리오 설정
    std::map<std::string, json> globalParameters;
    std::vector<ExecutionCondition> preconditions;
    
    TestScenario() : version("1.0") {}
    
    /**
     * @brief JSON 파일에서 시나리오 로드
     */
    static TestScenario LoadFromFile(const std::string& filepath);
    
    /**
     * @brief JSON 파일로 저장
     */
    void SaveToFile(const std::string& filepath) const;
    
    /**
     * @brief JSON에서 로드
     */
    static TestScenario FromJSON(const json& j);
    
    /**
     * @brief JSON으로 내보내기
     */
    json ToJSON() const;
    
    /**
     * @brief 시나리오 검증
     */
    bool Validate() const;
    
    /**
     * @brief 테스트 추가
     */
    void AddTest(const CustomTest& test);
    
    /**
     * @brief 체인 추가
     */
    void AddChain(const TestChain& chain);
    
    /**
     * @brief 전역 파라미터 설정
     */
    void SetGlobalParameter(const std::string& name, const json& value);
};

/**
 * @brief 테스트 실행 컨텍스트
 */
class ExecutionContext {
public:
    std::map<std::string, json> variables;      ///< 변수 저장소
    std::map<std::string, TestResult> results;  ///< 테스트 결과
    
    /**
     * @brief 변수 설정
     */
    void SetVariable(const std::string& name, const json& value) {
        variables[name] = value;
    }
    
    /**
     * @brief 변수 가져오기
     */
    json GetVariable(const std::string& name) const {
        auto it = variables.find(name);
        if (it != variables.end()) {
            return it->second;
        }
        return json();
    }
    
    /**
     * @brief 결과 저장
     */
    void SetResult(const std::string& testId, const TestResult& result) {
        results[testId] = result;
    }
    
    /**
     * @brief 결과 가져오기
     */
    TestResult GetResult(const std::string& testId) const {
        auto it = results.find(testId);
        if (it != results.end()) {
            return it->second;
        }
        return TestResult();
    }
    
    /**
     * @brief 초기화
     */
    void Clear() {
        variables.clear();
        results.clear();
    }
};

/**
 * @brief 테스트 커스터마이저 (메인 클래스)
 */
class TestCustomizer {
private:
    static TestCustomizer* instance_;
    
    std::map<std::string, CustomTest> registeredTests_;
    std::map<std::string, TestScenario> scenarios_;
    ExecutionContext context_;
    
    TestCustomizer() {}
    
public:
    static TestCustomizer& Instance() {
        if (!instance_) {
            instance_ = new TestCustomizer();
        }
        return *instance_;
    }
    
    /**
     * @brief 테스트 등록
     */
    void RegisterTest(const CustomTest& test) {
        if (!test.Validate()) {
            throw EDR::Exception(
                EDR::ErrorCode::INVALID_PARAMETER,
                "Invalid test definition: " + test.id
            );
        }
        registeredTests_[test.id] = test;
        EDR::Logger::Instance().Info("Test registered: " + test.id);
    }
    
    /**
     * @brief 시나리오 로드
     */
    void LoadScenario(const std::string& filepath) {
        try {
            auto scenario = TestScenario::LoadFromFile(filepath);
            if (!scenario.Validate()) {
                throw EDR::Exception(
                    EDR::ErrorCode::INVALID_PARAMETER,
                    "Invalid scenario: " + scenario.id
                );
            }
            scenarios_[scenario.id] = scenario;
            EDR::Logger::Instance().Info("Scenario loaded: " + scenario.id);
        } catch (const std::exception& e) {
            EDR::Logger::Instance().Error("Failed to load scenario: " + std::string(e.what()));
            throw;
        }
    }
    
    /**
     * @brief 시나리오 실행
     */
    std::vector<TestResult> ExecuteScenario(
        const std::string& scenarioId,
        const std::map<std::string, json>& parameters = {}
    );
    
    /**
     * @brief 단일 테스트 실행
     */
    TestResult ExecuteTest(
        const std::string& testId,
        const std::map<std::string, json>& parameters = {}
    );
    
    /**
     * @brief 테스트 체인 실행
     */
    std::vector<TestResult> ExecuteChain(
        const TestChain& chain,
        const std::map<std::string, json>& parameters = {}
    );
    
    /**
     * @brief 등록된 테스트 목록
     */
    std::vector<std::string> GetRegisteredTests() const {
        std::vector<std::string> result;
        for (const auto& [id, test] : registeredTests_) {
            result.push_back(id);
        }
        return result;
    }
    
    /**
     * @brief 시나리오 목록
     */
    std::vector<std::string> GetScenarios() const {
        std::vector<std::string> result;
        for (const auto& [id, scenario] : scenarios_) {
            result.push_back(id);
        }
        return result;
    }
    
    /**
     * @brief 테스트 정보 가져오기
     */
    CustomTest GetTest(const std::string& testId) const {
        auto it = registeredTests_.find(testId);
        if (it != registeredTests_.end()) {
            return it->second;
        }
        throw EDR::Exception(
            EDR::ErrorCode::INVALID_PARAMETER,
            "Test not found: " + testId
        );
    }
    
    /**
     * @brief 시나리오 정보 가져오기
     */
    TestScenario GetScenario(const std::string& scenarioId) const {
        auto it = scenarios_.find(scenarioId);
        if (it != scenarios_.end()) {
            return it->second;
        }
        throw EDR::Exception(
            EDR::ErrorCode::INVALID_PARAMETER,
            "Scenario not found: " + scenarioId
        );
    }
    
    /**
     * @brief 실행 컨텍스트 가져오기
     */
    ExecutionContext& GetContext() {
        return context_;
    }
    
    /**
     * @brief 컨텍스트 초기화
     */
    void ResetContext() {
        context_.Clear();
    }
    
    /**
     * @brief 빌트인 테스트 등록
     */
    void RegisterBuiltInTests();
    
    /**
     * @brief 테스트 템플릿 생성
     */
    static CustomTest CreateTestTemplate(
        const std::string& id,
        const std::string& name,
        const std::string& techniqueId
    );
    
    /**
     * @brief 시나리오 템플릿 생성
     */
    static TestScenario CreateScenarioTemplate(
        const std::string& id,
        const std::string& name
    );
};

// ============================================================================
// 조건 평가 헬퍼 함수들
// ============================================================================

/**
 * @brief 프로세스 존재 확인
 */
bool CheckProcessExists(const std::string& processName);

/**
 * @brief 사용 가능한 메모리 확인
 */
bool CheckMemoryAvailable(size_t requiredBytes);

/**
 * @brief OS 버전 확인
 */
bool CheckOSVersion(const std::string& minVersion);

/**
 * @brief 파일 존재 확인
 */
bool CheckFileExists(const std::string& filepath);

/**
 * @brief 레지스트리 키 존재 확인
 */
bool CheckRegistryKeyExists(const std::string& keyPath);

/**
 * @brief 관리자 권한 확인
 */
bool CheckIsElevated();

// ============================================================================
// 빌트인 테스트 팩토리 함수들
// ============================================================================

/**
 * @brief DLL Injection 테스트 생성
 */
CustomTest CreateDLLInjectionTest();

/**
 * @brief Process Hollowing 테스트 생성
 */
CustomTest CreateProcessHollowingTest();

/**
 * @brief APC Injection 테스트 생성
 */
CustomTest CreateAPCInjectionTest();

/**
 * @brief Shellcode Injection 테스트 생성
 */
CustomTest CreateShellcodeInjectionTest();

/**
 * @brief Fileless Execution 테스트 생성
 */
CustomTest CreateFilelessExecutionTest();

} // namespace EDR
