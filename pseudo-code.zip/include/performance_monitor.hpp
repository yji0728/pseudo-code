/*
 * EDR Testing Tools - Performance Monitoring System
 * 
 * Purpose: Measure execution time and resource usage of EDR testing techniques
 * 
 * Features:
 * - Execution time measurement (high-resolution)
 * - Memory usage tracking (peak, current)
 * - CPU usage monitoring
 * - Disk I/O statistics
 * - Network I/O statistics (placeholder)
 * - CSV/JSON export
 * 
 * Usage:
 *   PerformanceMonitor monitor;
 *   monitor.StartMeasurement();
 *   // ... run your test ...
 *   auto metrics = monitor.StopMeasurement();
 *   monitor.ExportToCSV("results.csv");
 */

#ifndef EDR_PERFORMANCE_MONITOR_HPP
#define EDR_PERFORMANCE_MONITOR_HPP

#include <windows.h>
#include <psapi.h>
#include <pdh.h>
#include <chrono>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "logger.hpp"
#include "error_handling.hpp"

#pragma comment(lib, "pdh.lib")
#pragma comment(lib, "psapi.lib")

namespace EDR {

// Performance metrics structure
struct PerformanceMetrics {
    // Timing
    std::chrono::microseconds executionTime;
    std::chrono::system_clock::time_point startTime;
    std::chrono::system_clock::time_point endTime;
    
    // Memory
    size_t peakMemoryUsage;         // Bytes
    size_t currentMemoryUsage;      // Bytes
    size_t memoryDelta;             // Change in memory usage
    
    // CPU
    double cpuUsagePercent;         // CPU usage percentage
    DWORD cpuTimeMs;                // CPU time in milliseconds
    
    // I/O
    size_t diskBytesRead;
    size_t diskBytesWritten;
    DWORD diskReadOps;
    DWORD diskWriteOps;
    
    // Process info
    DWORD processId;
    std::wstring processName;
    
    // Additional info
    std::string techniqueName;
    std::string description;
    bool success;
    
    PerformanceMetrics()
        : executionTime(0)
        , peakMemoryUsage(0)
        , currentMemoryUsage(0)
        , memoryDelta(0)
        , cpuUsagePercent(0.0)
        , cpuTimeMs(0)
        , diskBytesRead(0)
        , diskBytesWritten(0)
        , diskReadOps(0)
        , diskWriteOps(0)
        , processId(0)
        , success(false)
    {}
};

// Performance monitor class
class PerformanceMonitor {
private:
    bool isMonitoring_;
    HANDLE hProcess_;
    
    // Start state
    std::chrono::high_resolution_clock::time_point startTimePoint_;
    PROCESS_MEMORY_COUNTERS startMemCounters_;
    IO_COUNTERS startIoCounters_;
    FILETIME startCreationTime_, startExitTime_, startKernelTime_, startUserTime_;
    
    // Current metrics
    PerformanceMetrics currentMetrics_;
    
    // Historical data
    std::vector<PerformanceMetrics> metricsHistory_;

public:
    PerformanceMonitor()
        : isMonitoring_(false)
        , hProcess_(NULL)
    {
        ZeroMemory(&startMemCounters_, sizeof(startMemCounters_));
        ZeroMemory(&startIoCounters_, sizeof(startIoCounters_));
    }
    
    ~PerformanceMonitor() {
        if (isMonitoring_) {
            try {
                StopMeasurement();
            } catch (...) {
                // Suppress exceptions in destructor
            }
        }
    }
    
    // Deleted copy operations
    PerformanceMonitor(const PerformanceMonitor&) = delete;
    PerformanceMonitor& operator=(const PerformanceMonitor&) = delete;
    
    // Start performance measurement
    void StartMeasurement(const std::string& techniqueName = "",
                         const std::string& description = "") {
        if (isMonitoring_) {
            throw Exception(ErrorCode::INVALID_PARAMETER,
                           "Monitoring already in progress",
                           "StartMeasurement", __FILE__, __LINE__);
        }
        
        LOG_INFO("Starting performance measurement: " + techniqueName);
        
        // Get current process handle
        hProcess_ = GetCurrentProcess();
        
        // Record start time
        startTimePoint_ = std::chrono::high_resolution_clock::now();
        currentMetrics_.startTime = std::chrono::system_clock::now();
        currentMetrics_.techniqueName = techniqueName;
        currentMetrics_.description = description;
        currentMetrics_.processId = GetCurrentProcessId();
        
        // Get process name
        wchar_t processPath[MAX_PATH];
        if (GetModuleFileNameW(NULL, processPath, MAX_PATH)) {
            currentMetrics_.processName = processPath;
        }
        
        // Get initial memory counters
        startMemCounters_.cb = sizeof(PROCESS_MEMORY_COUNTERS);
        if (!GetProcessMemoryInfo(hProcess_, &startMemCounters_, sizeof(startMemCounters_))) {
            LOG_WARN("Failed to get initial memory info");
        }
        
        // Get initial I/O counters
        if (!GetProcessIoCounters(hProcess_, &startIoCounters_)) {
            LOG_WARN("Failed to get initial I/O info");
        }
        
        // Get initial CPU time
        if (!GetProcessTimes(hProcess_, &startCreationTime_, &startExitTime_,
                            &startKernelTime_, &startUserTime_)) {
            LOG_WARN("Failed to get initial CPU time");
        }
        
        isMonitoring_ = true;
        LOG_INFO("Performance monitoring started");
    }
    
    // Stop measurement and return metrics
    PerformanceMetrics StopMeasurement() {
        if (!isMonitoring_) {
            throw Exception(ErrorCode::INVALID_PARAMETER,
                           "No monitoring in progress",
                           "StopMeasurement", __FILE__, __LINE__);
        }
        
        LOG_INFO("Stopping performance measurement");
        
        // Record end time
        auto endTimePoint = std::chrono::high_resolution_clock::now();
        currentMetrics_.endTime = std::chrono::system_clock::now();
        currentMetrics_.executionTime = 
            std::chrono::duration_cast<std::chrono::microseconds>(
                endTimePoint - startTimePoint_);
        
        // Get final memory counters
        PROCESS_MEMORY_COUNTERS endMemCounters;
        endMemCounters.cb = sizeof(PROCESS_MEMORY_COUNTERS);
        if (GetProcessMemoryInfo(hProcess_, &endMemCounters, sizeof(endMemCounters))) {
            currentMetrics_.peakMemoryUsage = endMemCounters.PeakWorkingSetSize;
            currentMetrics_.currentMemoryUsage = endMemCounters.WorkingSetSize;
            currentMetrics_.memoryDelta = 
                static_cast<size_t>(static_cast<long long>(endMemCounters.WorkingSetSize) - 
                                   static_cast<long long>(startMemCounters_.WorkingSetSize));
        }
        
        // Get final I/O counters
        IO_COUNTERS endIoCounters;
        if (GetProcessIoCounters(hProcess_, &endIoCounters)) {
            currentMetrics_.diskBytesRead = 
                static_cast<size_t>(endIoCounters.ReadTransferCount - startIoCounters_.ReadTransferCount);
            currentMetrics_.diskBytesWritten = 
                static_cast<size_t>(endIoCounters.WriteTransferCount - startIoCounters_.WriteTransferCount);
            currentMetrics_.diskReadOps = 
                static_cast<DWORD>(endIoCounters.ReadOperationCount - startIoCounters_.ReadOperationCount);
            currentMetrics_.diskWriteOps = 
                static_cast<DWORD>(endIoCounters.WriteOperationCount - startIoCounters_.WriteOperationCount);
        }
        
        // Get final CPU time
        FILETIME endCreationTime, endExitTime, endKernelTime, endUserTime;
        if (GetProcessTimes(hProcess_, &endCreationTime, &endExitTime,
                           &endKernelTime, &endUserTime)) {
            
            // Convert FILETIME to ULONGLONG (100-nanosecond intervals)
            ULONGLONG startKernel = FileTimeToULongLong(startKernelTime_);
            ULONGLONG startUser = FileTimeToULongLong(startUserTime_);
            ULONGLONG endKernel = FileTimeToULongLong(endKernelTime);
            ULONGLONG endUser = FileTimeToULongLong(endUserTime);
            
            // Calculate CPU time in milliseconds
            ULONGLONG cpuTime = (endKernel - startKernel) + (endUser - startUser);
            currentMetrics_.cpuTimeMs = static_cast<DWORD>(cpuTime / 10000); // Convert to ms
            
            // Calculate CPU usage percentage
            double wallTime = static_cast<double>(currentMetrics_.executionTime.count()) / 1000.0; // ms
            if (wallTime > 0) {
                currentMetrics_.cpuUsagePercent = 
                    (static_cast<double>(currentMetrics_.cpuTimeMs) / wallTime) * 100.0;
            }
        }
        
        // Mark as success (caller can override)
        currentMetrics_.success = true;
        
        // Add to history
        metricsHistory_.push_back(currentMetrics_);
        
        isMonitoring_ = false;
        
        LOG_INFO("Performance measurement completed");
        LogMetrics(currentMetrics_);
        
        return currentMetrics_;
    }
    
    // Set success status
    void SetSuccess(bool success) {
        currentMetrics_.success = success;
        if (!metricsHistory_.empty()) {
            metricsHistory_.back().success = success;
        }
    }
    
    // Get metrics history
    const std::vector<PerformanceMetrics>& GetHistory() const {
        return metricsHistory_;
    }
    
    // Clear history
    void ClearHistory() {
        metricsHistory_.clear();
        LOG_INFO("Performance metrics history cleared");
    }
    
    // Export to CSV
    void ExportToCSV(const std::string& filename) const {
        if (metricsHistory_.empty()) {
            LOG_WARN("No metrics to export");
            return;
        }
        
        LOG_INFO("Exporting metrics to CSV: " + filename);
        
        std::ofstream file(filename);
        if (!file.is_open()) {
            throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                           "Failed to open CSV file: " + filename,
                           "ExportToCSV", __FILE__, __LINE__);
        }
        
        // Write CSV header
        file << "Technique,Description,Success,Execution Time (μs),Execution Time (ms),"
             << "Peak Memory (MB),Current Memory (MB),Memory Delta (MB),"
             << "CPU Usage (%),CPU Time (ms),"
             << "Disk Read (KB),Disk Write (KB),Disk Read Ops,Disk Write Ops,"
             << "Process ID,Process Name,Start Time,End Time\n";
        
        // Write data rows
        for (const auto& metrics : metricsHistory_) {
            file << EscapeCSV(metrics.techniqueName) << ","
                 << EscapeCSV(metrics.description) << ","
                 << (metrics.success ? "Success" : "Failed") << ","
                 << metrics.executionTime.count() << ","
                 << (metrics.executionTime.count() / 1000.0) << ","
                 << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << ","
                 << (metrics.currentMemoryUsage / 1024.0 / 1024.0) << ","
                 << (static_cast<double>(metrics.memoryDelta) / 1024.0 / 1024.0) << ","
                 << metrics.cpuUsagePercent << ","
                 << metrics.cpuTimeMs << ","
                 << (metrics.diskBytesRead / 1024.0) << ","
                 << (metrics.diskBytesWritten / 1024.0) << ","
                 << metrics.diskReadOps << ","
                 << metrics.diskWriteOps << ","
                 << metrics.processId << ","
                 << EscapeCSV(EDR::WStringToString(metrics.processName)) << ","
                 << FormatTime(metrics.startTime) << ","
                 << FormatTime(metrics.endTime) << "\n";
        }
        
        file.close();
        LOG_INFO("CSV export completed: " + std::to_string(metricsHistory_.size()) + " records");
    }
    
    // Export to JSON
    void ExportToJSON(const std::string& filename) const {
        if (metricsHistory_.empty()) {
            LOG_WARN("No metrics to export");
            return;
        }
        
        LOG_INFO("Exporting metrics to JSON: " + filename);
        
        std::ofstream file(filename);
        if (!file.is_open()) {
            throw Exception(ErrorCode::FILE_ACCESS_DENIED,
                           "Failed to open JSON file: " + filename,
                           "ExportToJSON", __FILE__, __LINE__);
        }
        
        file << "{\n";
        file << "  \"metrics\": [\n";
        
        for (size_t i = 0; i < metricsHistory_.size(); ++i) {
            const auto& metrics = metricsHistory_[i];
            
            file << "    {\n";
            file << "      \"technique\": \"" << EscapeJSON(metrics.techniqueName) << "\",\n";
            file << "      \"description\": \"" << EscapeJSON(metrics.description) << "\",\n";
            file << "      \"success\": " << (metrics.success ? "true" : "false") << ",\n";
            file << "      \"timing\": {\n";
            file << "        \"executionTimeMicros\": " << metrics.executionTime.count() << ",\n";
            file << "        \"executionTimeMs\": " << (metrics.executionTime.count() / 1000.0) << ",\n";
            file << "        \"startTime\": \"" << FormatTime(metrics.startTime) << "\",\n";
            file << "        \"endTime\": \"" << FormatTime(metrics.endTime) << "\"\n";
            file << "      },\n";
            file << "      \"memory\": {\n";
            file << "        \"peakMB\": " << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << ",\n";
            file << "        \"currentMB\": " << (metrics.currentMemoryUsage / 1024.0 / 1024.0) << ",\n";
            file << "        \"deltaMB\": " << (static_cast<double>(metrics.memoryDelta) / 1024.0 / 1024.0) << "\n";
            file << "      },\n";
            file << "      \"cpu\": {\n";
            file << "        \"usagePercent\": " << metrics.cpuUsagePercent << ",\n";
            file << "        \"timeMs\": " << metrics.cpuTimeMs << "\n";
            file << "      },\n";
            file << "      \"io\": {\n";
            file << "        \"diskReadKB\": " << (metrics.diskBytesRead / 1024.0) << ",\n";
            file << "        \"diskWriteKB\": " << (metrics.diskBytesWritten / 1024.0) << ",\n";
            file << "        \"diskReadOps\": " << metrics.diskReadOps << ",\n";
            file << "        \"diskWriteOps\": " << metrics.diskWriteOps << "\n";
            file << "      },\n";
            file << "      \"process\": {\n";
            file << "        \"pid\": " << metrics.processId << ",\n";
            file << "        \"name\": \"" << EscapeJSON(EDR::WStringToString(metrics.processName)) << "\"\n";
            file << "      }\n";
            file << "    }";
            
            if (i < metricsHistory_.size() - 1) {
                file << ",";
            }
            file << "\n";
        }
        
        file << "  ],\n";
        file << "  \"summary\": {\n";
        file << "    \"totalTests\": " << metricsHistory_.size() << ",\n";
        file << "    \"successfulTests\": " << CountSuccessful() << ",\n";
        file << "    \"failedTests\": " << (metricsHistory_.size() - CountSuccessful()) << "\n";
        file << "  }\n";
        file << "}\n";
        
        file.close();
        LOG_INFO("JSON export completed: " + std::to_string(metricsHistory_.size()) + " records");
    }
    
    // Print summary statistics
    void PrintSummary() const {
        if (metricsHistory_.empty()) {
            std::cout << "No performance data available.\n";
            return;
        }
        
        std::cout << "\n=== Performance Monitoring Summary ===\n\n";
        std::cout << "Total Tests: " << metricsHistory_.size() << "\n";
        std::cout << "Successful: " << CountSuccessful() << "\n";
        std::cout << "Failed: " << (metricsHistory_.size() - CountSuccessful()) << "\n\n";
        
        // Calculate averages
        double avgExecTime = 0.0;
        double avgMemory = 0.0;
        double avgCPU = 0.0;
        
        for (const auto& metrics : metricsHistory_) {
            avgExecTime += metrics.executionTime.count() / 1000.0; // ms
            avgMemory += metrics.peakMemoryUsage / 1024.0 / 1024.0; // MB
            avgCPU += metrics.cpuUsagePercent;
        }
        
        size_t count = metricsHistory_.size();
        avgExecTime /= count;
        avgMemory /= count;
        avgCPU /= count;
        
        std::cout << "Average Execution Time: " << std::fixed << std::setprecision(2) 
                  << avgExecTime << " ms\n";
        std::cout << "Average Peak Memory: " << avgMemory << " MB\n";
        std::cout << "Average CPU Usage: " << avgCPU << " %\n";
        std::cout << "\n=======================================\n\n";
    }

private:
    // Helper: Convert FILETIME to ULONGLONG
    static ULONGLONG FileTimeToULongLong(const FILETIME& ft) {
        ULARGE_INTEGER uli;
        uli.LowPart = ft.dwLowDateTime;
        uli.HighPart = ft.dwHighDateTime;
        return uli.QuadPart;
    }
    
    // Helper: Format time
    static std::string FormatTime(const std::chrono::system_clock::time_point& tp) {
        auto time_t = std::chrono::system_clock::to_time_t(tp);
        std::tm tm;
        localtime_s(&tm, &time_t);
        
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return oss.str();
    }
    
    // Helper: Escape CSV
    static std::string EscapeCSV(const std::string& str) {
        if (str.find(',') != std::string::npos || 
            str.find('"') != std::string::npos ||
            str.find('\n') != std::string::npos) {
            std::string escaped = "\"";
            for (char c : str) {
                if (c == '"') escaped += "\"\"";
                else escaped += c;
            }
            escaped += "\"";
            return escaped;
        }
        return str;
    }
    
    // Helper: Escape JSON
    static std::string EscapeJSON(const std::string& str) {
        std::ostringstream oss;
        for (char c : str) {
            switch (c) {
                case '"': oss << "\\\""; break;
                case '\\': oss << "\\\\"; break;
                case '\b': oss << "\\b"; break;
                case '\f': oss << "\\f"; break;
                case '\n': oss << "\\n"; break;
                case '\r': oss << "\\r"; break;
                case '\t': oss << "\\t"; break;
                default: oss << c; break;
            }
        }
        return oss.str();
    }
    
    // Helper: Count successful tests
    size_t CountSuccessful() const {
        size_t count = 0;
        for (const auto& metrics : metricsHistory_) {
            if (metrics.success) ++count;
        }
        return count;
    }
    
    // Helper: Log metrics
    void LogMetrics(const PerformanceMetrics& metrics) const {
        std::ostringstream oss;
        oss << "Performance Metrics for '" << metrics.techniqueName << "':\n";
        oss << "  Execution Time: " << (metrics.executionTime.count() / 1000.0) << " ms\n";
        oss << "  Peak Memory: " << (metrics.peakMemoryUsage / 1024.0 / 1024.0) << " MB\n";
        oss << "  CPU Usage: " << metrics.cpuUsagePercent << " %\n";
        oss << "  Disk Read: " << (metrics.diskBytesRead / 1024.0) << " KB\n";
        oss << "  Disk Write: " << (metrics.diskBytesWritten / 1024.0) << " KB";
        
        LOG_INFO(oss.str());
    }
};

} // namespace EDR

#endif // EDR_PERFORMANCE_MONITOR_HPP
