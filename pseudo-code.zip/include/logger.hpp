/*
 * EDR Testing Tools - Unified Logging System
 *
 * Purpose: Provide structured logging framework for EDR testing tools
 *
 * Features:
 * - Multiple log levels (DEBUG, INFO, WARN, ERROR, CRITICAL)
 * - File and console output
 * - Optional JSON structured logging
 * - Timestamp and thread ID
 *
 * Usage:
 *   EDR::Logger::Instance().SetOutputFile("test.log");
 *   EDR::Logger::Instance().SetLevel(EDRLOG_INFO);
 *   LOG_INFO("Test message");
 *   LOG_ERROR("Error occurred");
 */

#ifndef EDR_LOGGER_HPP
#define EDR_LOGGER_HPP

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#ifdef ERROR
#undef ERROR
#endif
#ifdef DEBUG
#undef DEBUG
#endif
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <mutex>
#include <iomanip>
#include <map>
#include <ctime>

// Log levels
enum EDRLogLevel {
    EDRLOG_DEBUG = 0,
    EDRLOG_INFO = 1,
    EDRLOG_WARN = 2,
    EDRLOG_ERROR = 3,
    EDRLOG_CRITICAL = 4
};

namespace EDR {

class Logger {
public:
    // Compatibility enum for callers using Logger::Level::INFO style
    enum class Level {
        DEBUG = EDRLOG_DEBUG,
        INFO = EDRLOG_INFO,
        WARN = EDRLOG_WARN,
        ERROR = EDRLOG_ERROR,
        CRITICAL = EDRLOG_CRITICAL
    };

    // Singleton access
    static Logger& Instance() {
        static Logger instance;
        return instance;
    }

    // Delete copy constructor and assignment operator
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    // Configuration
    void SetOutputFile(const std::string& filename) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (fileStream_.is_open()) {
            fileStream_.close();
        }
        filename_ = filename;
        fileStream_.open(filename_, std::ios::app);
        enableFileOutput_ = fileStream_.is_open();
    }

    void SetLevel(EDRLogLevel minLevel) {
        std::lock_guard<std::mutex> lock(mutex_);
        minLevel_ = minLevel;
    }

    // Overload for compatibility with Logger::Level
    void SetLevel(Level minLevel) {
        SetLevel(static_cast<EDRLogLevel>(minLevel));
    }

    void EnableConsole(bool enable) {
        std::lock_guard<std::mutex> lock(mutex_);
        enableConsoleOutput_ = enable;
    }

    void EnableJSON(bool enable) {
        std::lock_guard<std::mutex> lock(mutex_);
        jsonFormat_ = enable;
    }

    // Main logging function
    void Log(EDRLogLevel level, const std::string& message,
             const char* file = nullptr, int line = 0) {
        std::lock_guard<std::mutex> lock(mutex_);

        // Check level
        if (level < minLevel_) {
            return;
        }

        // Format message
        std::string formattedMsg = jsonFormat_
            ? FormatJSON(level, message, file, line)
            : FormatText(level, message, file, line);

        // Output to console
        if (enableConsoleOutput_) {
            OutputToConsole(level, formattedMsg);
        }

        // Output to file
        if (enableFileOutput_ && fileStream_.is_open()) {
            fileStream_ << formattedMsg << std::endl;
            fileStream_.flush();
        }
    }

    // Convenience methods for callers expecting Info/Warn/Error etc.
    void Debug(const std::string& message) { Log(EDRLOG_DEBUG, message); }
    void Info(const std::string& message) { Log(EDRLOG_INFO, message); }
    void Warn(const std::string& message) { Log(EDRLOG_WARN, message); }
    void Error(const std::string& message) { Log(EDRLOG_ERROR, message); }
    void Critical(const std::string& message) { Log(EDRLOG_CRITICAL, message); }

    // Structured logging with attributes
    void LogEvent(const std::string& eventType, EDRLogLevel level,
                  const std::map<std::string, std::string>& attributes) {
        std::lock_guard<std::mutex> lock(mutex_);

        if (level < minLevel_) {
            return;
        }

        std::string formattedMsg = FormatEventJSON(eventType, level, attributes);

        if (enableConsoleOutput_) {
            OutputToConsole(level, formattedMsg);
        }

        if (enableFileOutput_ && fileStream_.is_open()) {
            fileStream_ << formattedMsg << std::endl;
            fileStream_.flush();
        }
    }

    // Get level name
    static std::string GetLevelName(EDRLogLevel level) {
        switch (level) {
            case EDRLOG_DEBUG: return "DEBUG";
            case EDRLOG_INFO: return "INFO";
            case EDRLOG_WARN: return "WARN";
            case EDRLOG_ERROR: return "ERROR";
            case EDRLOG_CRITICAL: return "CRITICAL";
            default: return "UNKNOWN";
        }
    }

    // Destructor
    ~Logger() {
        if (fileStream_.is_open()) {
            fileStream_.close();
        }
    }

private:
    Logger()
        : minLevel_(EDRLOG_INFO)
        , enableConsoleOutput_(true)
        , enableFileOutput_(false)
        , jsonFormat_(false) {}

    // Get current timestamp
    std::string GetTimestamp() {
        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()) % std::chrono::seconds(1);

        tm timeinfo;
        localtime_s(&timeinfo, &time);

        std::stringstream ss;
        ss << std::put_time(&timeinfo, "%Y-%m-%d %H:%M:%S");
        ss << '.' << std::setfill('0') << std::setw(3) << ms.count();
        return ss.str();
    }

    // Get thread ID
    DWORD GetThreadId() { return ::GetCurrentThreadId(); }

    // Escape JSON string
    static std::string EscapeJSON(const std::string& str) {
        std::string escaped;
        escaped.reserve(str.size());
        for (char c : str) {
            switch (c) {
                case '"': escaped += "\\\""; break;
                case '\\': escaped += "\\\\"; break;
                case '\b': escaped += "\\b"; break;
                case '\f': escaped += "\\f"; break;
                case '\n': escaped += "\\n"; break;
                case '\r': escaped += "\\r"; break;
                case '\t': escaped += "\\t"; break;
                default: escaped += c; break;
            }
        }
        return escaped;
    }

    // Format text output
    std::string FormatText(EDRLogLevel level, const std::string& message,
                           const char* file, int line) {
        std::stringstream ss;
        ss << "[" << GetTimestamp() << "]";
        ss << " [" << GetLevelName(level) << "]";
        ss << " [TID:" << GetThreadId() << "]";
        if (file && line > 0) {
            ss << " [" << file << ":" << line << "]";
        }
        ss << " " << message;
        return ss.str();
    }

    // Format JSON output
    std::string FormatJSON(EDRLogLevel level, const std::string& message,
                           const char* file, int line) {
        std::stringstream ss;
        ss << "{";
        ss << "\"timestamp\":\"" << GetTimestamp() << "\",";
        ss << "\"level\":\"" << GetLevelName(level) << "\",";
        ss << "\"thread_id\":" << GetThreadId() << ",";
        if (file && line > 0) {
            ss << "\"file\":\"" << EscapeJSON(file) << "\",";
            ss << "\"line\":" << line << ",";
        }
        ss << "\"message\":\"" << EscapeJSON(message) << "\"";
        ss << "}";
        return ss.str();
    }

    // Format event JSON
    std::string FormatEventJSON(const std::string& eventType, EDRLogLevel level,
                                const std::map<std::string, std::string>& attributes) {
        std::stringstream ss;
        ss << "{";
        ss << "\"timestamp\":\"" << GetTimestamp() << "\",";
        ss << "\"level\":\"" << GetLevelName(level) << "\",";
        ss << "\"thread_id\":" << GetThreadId() << ",";
        ss << "\"event_type\":\"" << EscapeJSON(eventType) << "\",";
        ss << "\"attributes\":{";
        bool first = true;
        for (const auto& attr : attributes) {
            if (!first) ss << ",";
            ss << "\"" << EscapeJSON(attr.first) << "\":\"" << EscapeJSON(attr.second) << "\"";
            first = false;
        }
        ss << "}}";
        return ss.str();
    }

    // Output to console with color
    void OutputToConsole(EDRLogLevel level, const std::string& message) {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        WORD color = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE; // White
        switch (level) {
            case EDRLOG_DEBUG:   color = FOREGROUND_BLUE  | FOREGROUND_INTENSITY; break;
            case EDRLOG_INFO:    color = FOREGROUND_GREEN | FOREGROUND_INTENSITY; break;
            case EDRLOG_WARN:    color = FOREGROUND_RED   | FOREGROUND_GREEN | FOREGROUND_INTENSITY; break;
            case EDRLOG_ERROR:   color = FOREGROUND_RED   | FOREGROUND_INTENSITY; break;
            case EDRLOG_CRITICAL:color = FOREGROUND_RED   | FOREGROUND_BLUE | FOREGROUND_INTENSITY; break;
        }
        SetConsoleTextAttribute(hConsole, color);
        std::cout << message << std::endl;
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    }

private:
    EDRLogLevel minLevel_;
    bool enableConsoleOutput_;
    bool enableFileOutput_;
    bool jsonFormat_;
    std::string filename_;
    std::ofstream fileStream_;
    std::mutex mutex_;
};

// Helper functions for string conversion
inline std::wstring StringToWString(const std::string& str) {
    if (str.empty()) return std::wstring();
    int size = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), (int)str.length(), nullptr, 0);
    std::wstring wstr(size, 0);
    MultiByteToWideChar(CP_UTF8, 0, str.c_str(), (int)str.length(), &wstr[0], size);
    return wstr;
}

inline std::string WStringToString(const std::wstring& wstr) {
    if (wstr.empty()) return std::string();
    int size = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), nullptr, 0, nullptr, nullptr);
    std::string str(size, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), &str[0], size, nullptr, nullptr);
    return str;
}

} // namespace EDR

// Convenience macros
#define LOG_DEBUG(msg) EDR::Logger::Instance().Log(EDRLOG_DEBUG, msg, __FILE__, __LINE__)
#define LOG_INFO(msg) EDR::Logger::Instance().Log(EDRLOG_INFO, msg, __FILE__, __LINE__)
#define LOG_WARN(msg) EDR::Logger::Instance().Log(EDRLOG_WARN, msg, __FILE__, __LINE__)
#define LOG_ERROR(msg) EDR::Logger::Instance().Log(EDRLOG_ERROR, msg, __FILE__, __LINE__)
#define LOG_CRITICAL(msg) EDR::Logger::Instance().Log(EDRLOG_CRITICAL, msg, __FILE__, __LINE__)

// Event logging macro
#define LOG_EVENT(type, level, ...) \
    EDR::Logger::Instance().LogEvent(type, level, {__VA_ARGS__})

#endif // EDR_LOGGER_HPP
