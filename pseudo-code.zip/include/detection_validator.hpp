/*
 * EDR Detection Validator - EDR Testing Tools
 * 
 * Purpose: Automated EDR detection validation and verification
 * 
 * This system provides:
 * - ETW (Event Tracing for Windows) event collection
 * - Windows Event Log analysis
 * - Sysmon log parsing
 * - Detection rate calculation
 * - Real-time monitoring capabilities
 * 
 * Features:
 * - Multi-provider event collection
 * - Structured event data
 * - Detection timeline tracking
 * - Detailed detection reports
 * - False positive identification
 * 
 * Usage:
 *   DetectionValidator validator;
 *   validator.StartMonitoring();
 *   // Execute technique...
 *   auto result = validator.ValidateTechnique("T1055.001");
 *   validator.StopMonitoring();
 *   auto report = validator.GenerateReport();
 */

#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#ifdef ERROR
#undef ERROR
#endif
#ifdef DEBUG
#undef DEBUG
#endif
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <string>
#include <vector>
#include <map>
#include <cstring>
#include <chrono>
#include <memory>
#include <functional>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include "logger.hpp"
#include "error_handling.hpp"

// Use the bundled single-header json to avoid external include dependency
#include "json.hpp"

#pragma comment(lib, "tdh.lib")
#pragma comment(lib, "advapi32.lib")

namespace EDR {
// Comparator for GUID to use as std::map key
struct GuidLess {
    bool operator()(const GUID& a, const GUID& b) const noexcept {
        return std::memcmp(&a, &b, sizeof(GUID)) < 0;
    }
};

// ============================================================================
// Event Data Structures
// ============================================================================

/**
 * @brief ETW 이벤트 데이터
 */
struct ETWEvent {
    std::chrono::system_clock::time_point timestamp;
    GUID providerId;
    std::wstring providerName;
    USHORT eventId;
    std::wstring eventName;
    UCHAR level;
    ULONGLONG keyword;
    DWORD processId;
    DWORD threadId;
    std::map<std::wstring, std::wstring> properties;
    
    std::wstring ToString() const {
        std::wostringstream oss;
        auto time_t = std::chrono::system_clock::to_time_t(timestamp);
        oss << L"[" << std::put_time(std::localtime(&time_t), L"%Y-%m-%d %H:%M:%S") << L"] "
            << providerName << L" - Event " << eventId << L" (" << eventName << L")\n"
            << L"  Process: " << processId << L", Thread: " << threadId << L"\n";
        
        for (const auto& [key, value] : properties) {
            oss << L"  " << key << L": " << value << L"\n";
        }
        
        return oss.str();
    }
};

/**
 * @brief Sysmon 이벤트 데이터
 */
struct SysmonEvent {
    enum class Type {
        ProcessCreate = 1,          // Event ID 1
        FileCreateTime = 2,         // Event ID 2
        NetworkConnect = 3,         // Event ID 3
        ProcessTerminate = 5,       // Event ID 5
        DriverLoad = 6,             // Event ID 6
        ImageLoad = 7,              // Event ID 7
        CreateRemoteThread = 8,     // Event ID 8
        RawAccessRead = 9,          // Event ID 9
        ProcessAccess = 10,         // Event ID 10
        FileCreate = 11,            // Event ID 11
        RegistryEvent = 12,         // Event ID 12-14
        FileCreateStreamHash = 15,  // Event ID 15
        PipeEvent = 17,             // Event ID 17-18
        WmiEvent = 19,              // Event ID 19-21
        DnsQuery = 22,              // Event ID 22
        FileDelete = 23,            // Event ID 23
        ClipboardChange = 24,       // Event ID 24
        ProcessTampering = 25,      // Event ID 25
        FileDeleteDetected = 26     // Event ID 26
    };
    
    std::chrono::system_clock::time_point timestamp;
    Type type;
    std::wstring ruleName;
    DWORD processId;
    std::wstring processName;
    std::wstring image;
    std::wstring commandLine;
    std::wstring user;
    std::map<std::wstring, std::wstring> details;
    
    static Type ParseType(int eventId) {
        return static_cast<Type>(eventId);
    }
    
    std::wstring GetTypeName() const {
        static const std::map<Type, std::wstring> typeNames = {
            {Type::ProcessCreate, L"Process Create"},
            {Type::FileCreateTime, L"File Create Time"},
            {Type::NetworkConnect, L"Network Connect"},
            {Type::ProcessTerminate, L"Process Terminate"},
            {Type::DriverLoad, L"Driver Load"},
            {Type::ImageLoad, L"Image Load"},
            {Type::CreateRemoteThread, L"Create Remote Thread"},
            {Type::RawAccessRead, L"Raw Access Read"},
            {Type::ProcessAccess, L"Process Access"},
            {Type::FileCreate, L"File Create"},
            {Type::RegistryEvent, L"Registry Event"},
            {Type::FileCreateStreamHash, L"File Create Stream Hash"},
            {Type::PipeEvent, L"Pipe Event"},
            {Type::WmiEvent, L"WMI Event"},
            {Type::DnsQuery, L"DNS Query"},
            {Type::FileDelete, L"File Delete"},
            {Type::ClipboardChange, L"Clipboard Change"},
            {Type::ProcessTampering, L"Process Tampering"},
            {Type::FileDeleteDetected, L"File Delete Detected"}
        };
        
        auto it = typeNames.find(type);
        return (it != typeNames.end()) ? it->second : L"Unknown";
    }
};

/**
 * @brief Windows Event Log 항목
 */
struct WindowsEvent {
    std::chrono::system_clock::time_point timestamp;
    std::wstring source;
    DWORD eventId;
    std::wstring level;
    std::wstring message;
    std::map<std::wstring, std::wstring> data;
};

/**
 * @brief 탐지 결과
 */
struct DetectionResult {
    std::string technique;              // MITRE ATT&CK technique ID
    std::string techniqueName;          // Human-readable name
    bool detected;                      // Overall detection status
    std::vector<std::string> detectionMethods;  // EDR/monitoring tools that detected
    std::chrono::milliseconds detectionLatency; // Time to detection
    std::string severity;               // Low, Medium, High, Critical
    std::string confidence;             // Low, Medium, High
    
    std::vector<ETWEvent> etwEvents;
    std::vector<SysmonEvent> sysmonEvents;
    std::vector<WindowsEvent> windowsEvents;
    
    std::string details;                // Additional information
    std::map<std::string, std::string> metadata;
    
    // Detection scoring
    double detectionScore;              // 0.0 - 1.0
    int totalIndicators;                // Total detection indicators
    int triggeredIndicators;            // Indicators that fired
    
    std::string ToJSON() const {
        std::ostringstream oss;
        oss << "{\n"
            << "  \"technique\": \"" << technique << "\",\n"
            << "  \"techniqueName\": \"" << techniqueName << "\",\n"
            << "  \"detected\": " << (detected ? "true" : "false") << ",\n"
            << "  \"detectionMethods\": [";
        
        for (size_t i = 0; i < detectionMethods.size(); ++i) {
            oss << "\"" << detectionMethods[i] << "\"";
            if (i < detectionMethods.size() - 1) oss << ", ";
        }
        
        oss << "],\n"
            << "  \"detectionLatencyMs\": " << detectionLatency.count() << ",\n"
            << "  \"severity\": \"" << severity << "\",\n"
            << "  \"confidence\": \"" << confidence << "\",\n"
            << "  \"detectionScore\": " << detectionScore << ",\n"
            << "  \"totalIndicators\": " << totalIndicators << ",\n"
            << "  \"triggeredIndicators\": " << triggeredIndicators << ",\n"
            << "  \"etwEventCount\": " << etwEvents.size() << ",\n"
            << "  \"sysmonEventCount\": " << sysmonEvents.size() << ",\n"
            << "  \"windowsEventCount\": " << windowsEvents.size() << ",\n"
            << "  \"details\": \"" << details << "\"\n"
            << "}";
        
        return oss.str();
    }
};

/**
 * @brief 탐지 보고서
 */
struct DetectionReport {
    std::chrono::system_clock::time_point startTime;
    std::chrono::system_clock::time_point endTime;
    std::vector<DetectionResult> results;
    
    // Statistics
    int totalTechniques;
    int detectedTechniques;
    double overallDetectionRate;
    
    std::chrono::milliseconds averageDetectionLatency;
    std::chrono::milliseconds minDetectionLatency;
    std::chrono::milliseconds maxDetectionLatency;
    
    std::map<std::string, int> detectionMethodCounts;
    std::map<std::string, double> techniqueDetectionRates;
    
    std::string ExportToJSON() const;
    std::string ExportToHTML() const;
    void ExportToCSV(const std::string& filename) const;
};

// ============================================================================
// Detection Validator Class
// ============================================================================

/**
 * @brief EDR 탐지 검증기
 * 
 * 다양한 소스에서 이벤트를 수집하고 분석하여
 * EDR의 탐지 능력을 자동으로 검증합니다.
 */
class DetectionValidator {
public:
    /**
     * @brief 생성자
     */
    DetectionValidator();
    
    /**
     * @brief 소멸자
     */
    ~DetectionValidator();
    
    // 모니터링 제어
    /**
     * @brief 모니터링 시작
     * @return 성공 여부
     */
    bool StartMonitoring();
    
    /**
     * @brief 모니터링 중지
     * @return 성공 여부
     */
    bool StopMonitoring();
    
    /**
     * @brief 모니터링 상태 확인
     * @return 모니터링 중이면 true
     */
    bool IsMonitoring() const { return isMonitoring_; }
    
    // ETW 제어
    /**
     * @brief ETW 프로바이더 활성화
     * @param providerId 프로바이더 GUID
     * @param providerName 프로바이더 이름 (로깅용)
     * @return 성공 여부
     */
    bool EnableETWProvider(const GUID& providerId, const std::wstring& providerName);
    
    /**
     * @brief 여러 ETW 프로바이더 활성화
     * @param providers 프로바이더 GUID와 이름의 맵
     * @return 성공한 개수
     */
    int EnableETWProviders(const std::map<GUID, std::wstring, GuidLess>& providers);
    
    // 이벤트 수집
    /**
     * @brief Sysmon 로그 파싱
     * @param startTime 시작 시간
     * @return Sysmon 이벤트 목록
     */
    std::vector<SysmonEvent> ParseSysmonLogs(
        const std::chrono::system_clock::time_point& startTime);
    
    /**
     * @brief Windows Event Log 파싱
     * @param logName 로그 이름 (예: "Security", "System")
     * @param startTime 시작 시간
     * @return Windows 이벤트 목록
     */
    std::vector<WindowsEvent> ParseWindowsEventLog(
        const std::wstring& logName,
        const std::chrono::system_clock::time_point& startTime);
    
    /**
     * @brief 수집된 ETW 이벤트 가져오기
     * @return ETW 이벤트 목록
     */
    std::vector<ETWEvent> GetETWEvents() const;
    
    // 탐지 검증
    /**
     * @brief 특정 기법 탐지 검증
     * @param techniqueName 기법 이름 또는 ID
     * @return 탐지 결과
     */
    DetectionResult ValidateTechnique(const std::string& techniqueName);
    
    /**
     * @brief 여러 기법 일괄 검증
     * @param techniqueNames 기법 목록
     * @return 탐지 결과 목록
     */
    std::vector<DetectionResult> ValidateTechniques(
        const std::vector<std::string>& techniqueNames);
    
    /**
     * @brief 프로세스 ID로 탐지 검증
     * @param processId 대상 프로세스 ID
     * @return 탐지 결과
     */
    DetectionResult ValidateByProcessId(DWORD processId);
    
    // 보고서 생성
    /**
     * @brief 탐지 보고서 생성
     * @return 전체 탐지 보고서
     */
    DetectionReport GenerateReport();
    
    /**
     * @brief 특정 기간의 보고서 생성
     * @param startTime 시작 시간
     * @param endTime 종료 시간
     * @return 기간별 탐지 보고서
     */
    DetectionReport GenerateReport(
        const std::chrono::system_clock::time_point& startTime,
        const std::chrono::system_clock::time_point& endTime);
    
    // 설정
    /**
     * @brief 탐지 타임아웃 설정
     * @param timeout 타임아웃 (밀리초)
     */
    void SetDetectionTimeout(std::chrono::milliseconds timeout) {
        detectionTimeout_ = timeout;
    }
    
    /**
     * @brief 상세 로깅 활성화/비활성화
     * @param enable true면 상세 로깅 활성화
     */
    void SetVerboseLogging(bool enable) {
        verboseLogging_ = enable;
    }
    
    /**
     * @brief 실시간 콜백 등록
     * @param callback 이벤트 발생 시 호출될 함수
     */
    void SetRealtimeCallback(std::function<void(const ETWEvent&)> callback) {
        realtimeCallback_ = callback;
    }
    
    // 유틸리티
    /**
     * @brief Sysmon 설치 여부 확인
     * @return Sysmon이 설치되어 있으면 true
     */
    static bool IsSysmonInstalled();
    
    /**
     * @brief ETW 세션 활성화 확인
     * @param sessionName 세션 이름
     * @return 세션이 활성화되어 있으면 true
     */
    static bool IsETWSessionActive(const std::wstring& sessionName);
    
    /**
     * @brief 관리자 권한 확인
     * @return 관리자 권한이 있으면 true
     */
    static bool IsElevated();

private:
    // ETW 세션 관리
    TRACEHANDLE traceSessionHandle_;
    TRACEHANDLE traceConsumerHandle_;
    std::wstring sessionName_;
    
    // 이벤트 저장소
    std::vector<ETWEvent> etwEvents_;
    std::vector<DetectionResult> detectionResults_;
    
    // 상태
    bool isMonitoring_;
    std::chrono::system_clock::time_point monitoringStartTime_;
    std::chrono::system_clock::time_point monitoringEndTime_;
    
    // 설정
    std::chrono::milliseconds detectionTimeout_;
    bool verboseLogging_;
    std::function<void(const ETWEvent&)> realtimeCallback_;
    
    // 활성화된 프로바이더
    std::map<GUID, std::wstring, GuidLess> enabledProviders_;
    
    // ETW 콜백
    static void WINAPI EventRecordCallback(PEVENT_RECORD eventRecord);
    
    // 내부 헬퍼 함수
    bool StartETWSession();
    bool StopETWSession();
    void ProcessEventRecord(PEVENT_RECORD eventRecord);
    
    ETWEvent ParseETWEvent(PEVENT_RECORD eventRecord);
    bool MatchesTechnique(const ETWEvent& event, const std::string& technique);
    bool MatchesTechnique(const SysmonEvent& event, const std::string& technique);
    
    double CalculateDetectionScore(const DetectionResult& result);
    std::string DetermineConfidence(const DetectionResult& result);
    std::string DetermineSeverity(const std::string& technique);
};

// ============================================================================
// 자주 사용되는 ETW 프로바이더 GUID
// ============================================================================

namespace ETWProviders {
    // Microsoft-Windows-Kernel-Process
    static const GUID KernelProcess = 
        { 0x22fb2cd6, 0x0e7b, 0x422b, 
          { 0xa0, 0xc7, 0x2f, 0xad, 0x1f, 0xd0, 0xe7, 0x16 } };
    
    // Microsoft-Windows-Kernel-File
    static const GUID KernelFile = 
        { 0xedd08927, 0x9cc4, 0x4e65, 
          { 0xb9, 0x70, 0xc2, 0x56, 0x0f, 0xb5, 0xc2, 0x89 } };
    
    // Microsoft-Windows-Kernel-Registry
    static const GUID KernelRegistry = 
        { 0x70eb4f03, 0xc1de, 0x4f73, 
          { 0xa0, 0x51, 0x33, 0xd7, 0x97, 0x0b, 0x55, 0x9a } };
    
    // Microsoft-Windows-Kernel-Network
    static const GUID KernelNetwork = 
        { 0x7dd42a49, 0x5329, 0x4832, 
          { 0x8d, 0xfd, 0x43, 0xd9, 0x79, 0x15, 0x3a, 0x88 } };
    
    // Microsoft-Windows-Security-Auditing
    static const GUID SecurityAuditing = 
        { 0x54849625, 0x5478, 0x4994, 
          { 0xa5, 0xba, 0x3e, 0x3b, 0x05, 0x28, 0xf7, 0x21 } };
    
    // Microsoft-Windows-PowerShell
    static const GUID PowerShell = 
        { 0xa0c1853b, 0x5c40, 0x4b15, 
          { 0x8b, 0x66, 0xe0, 0xc0, 0x0a, 0xf7, 0xa2, 0x1b } };
}

// ============================================================================
// MITRE ATT&CK 기법 매핑
// ============================================================================

/**
 * @brief MITRE ATT&CK 기법 정보
 */
struct TechniqueInfo {
    std::string id;                     // T1055.001
    std::string name;                   // DLL Injection
    std::string tactic;                 // Defense Evasion
    std::vector<std::string> indicators; // Detection indicators
    
    // Sysmon 이벤트 ID 목록
    std::vector<int> sysmonEventIds;
    
    // ETW 프로바이더 목록
    std::vector<GUID> etwProviders;
    
    // Windows Event Log 이벤트 ID
    std::map<std::wstring, std::vector<int>> windowsEventIds;
};

/**
 * @brief 기법 정보 데이터베이스
 */
class TechniqueDatabase {
public:
    static TechniqueInfo GetTechniqueInfo(const std::string& techniqueId);
    static std::vector<TechniqueInfo> GetAllTechniques();
    static bool IsTechniqueSupported(const std::string& techniqueId);
    
private:
    static std::map<std::string, TechniqueInfo> techniques_;
    static void InitializeDatabase();
};

} // namespace EDR
