/**
 * @file report_generator.hpp
 * @brief ReportGenerator 선언부 (HTML 대시보드 및 ATT&CK Navigator JSON 생성)
 */

#pragma once

#include <string>
#include "detection_validator.hpp"

namespace EDR {

class ReportGenerator {
public:
    ReportGenerator(const DetectionReport& report, const std::string& outputDir = "reports");

    bool GenerateHTMLDashboard(const std::string& filename = "dashboard.html");
    bool GenerateAttackNavigatorJSON(const std::string& filename = "attack_navigator.json");
    bool GenerateAllReports();

private:
    // 데이터
    DetectionReport report_;
    std::string outputDir_;

    // 내부 유틸리티
    std::string GenerateHTMLHeader();
    std::string GenerateSummarySection();
    std::string GenerateChartsSection();
    std::string GenerateTechniquesSection();
    std::string GenerateTimelineSection();
    std::string GenerateDetailsSection();
    std::string GenerateJavaScriptData();
    std::string GenerateHTMLFooter();
    bool        GenerateSummaryReport();
    std::string GetCurrentTimestamp();
};

} // namespace EDR
