/**
 * @file realtime_monitor.hpp
 * @brief 실시간 모니터링 시스템 (Real-time Monitoring System)
 * @details
 * 테스트 실행 중 실시간 상태 모니터링
 * - 진행률 추적
 * - 실시간 로그 스트리밍
 * - 성능 지표 업데이트
 * - 탐지 이벤트 알림
 * - 대화형 제어
 * 
 * @author GitHub Copilot
 * @date 2025-01-XX
 */

#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#ifdef ERROR
#undef ERROR
#endif
#ifdef DEBUG
#undef DEBUG
#endif
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <chrono>
#include <mutex>
#include <thread>
#include <atomic>
#include <queue>
#include "json.hpp"
#include "logger.hpp"

using json = nlohmann::json;

namespace EDR {

/**
 * @brief 모니터링 이벤트 타입
 */
enum class MonitorEventType {
    TEST_STARTED,
    TEST_PROGRESS,
    TEST_COMPLETED,
    TEST_FAILED,
    LOG_MESSAGE,
    PERFORMANCE_UPDATE,
    DETECTION_EVENT,
    WARNING,
    ERROR,
    USER_ACTION
};

/**
 * @brief 모니터링 이벤트
 */
struct MonitorEvent {
    MonitorEventType type;
    std::string testId;
    std::chrono::system_clock::time_point timestamp;
    json data;
    std::string message;
    
    MonitorEvent() 
        : type(MonitorEventType::LOG_MESSAGE)
        , timestamp(std::chrono::system_clock::now()) {}
    
    MonitorEvent(MonitorEventType t, const std::string& tid, const std::string& msg)
        : type(t)
        , testId(tid)
        , timestamp(std::chrono::system_clock::now())
        , message(msg) {}
    
    /**
     * @brief JSON으로 변환
     */
    json ToJSON() const;
};

/**
 * @brief 실시간 성능 메트릭
 */
struct RealtimeMetrics {
    // CPU & Memory
    double cpuUsagePercent;
    size_t memoryUsageMB;
    size_t peakMemoryMB;
    
    // Disk I/O
    size_t diskReadMB;
    size_t diskWriteMB;
    
    // Network
    size_t networkSentMB;
    size_t networkReceivedMB;
    
    // Test stats
    int totalTests;
    int completedTests;
    int failedTests;
    int skippedTests;
    
    // Timing
    std::chrono::milliseconds totalDuration;
    std::chrono::milliseconds averageTestDuration;
    
    RealtimeMetrics() 
        : cpuUsagePercent(0.0)
        , memoryUsageMB(0)
        , peakMemoryMB(0)
        , diskReadMB(0)
        , diskWriteMB(0)
        , networkSentMB(0)
        , networkReceivedMB(0)
        , totalTests(0)
        , completedTests(0)
        , failedTests(0)
        , skippedTests(0)
        , totalDuration(0)
        , averageTestDuration(0) {}
    
    /**
     * @brief JSON으로 변환
     */
    json ToJSON() const;
    
    /**
     * @brief 진행률 계산
     */
    double GetProgressPercent() const {
        if (totalTests == 0) return 0.0;
        return (static_cast<double>(completedTests) / totalTests) * 100.0;
    }
};

/**
 * @brief 테스트 상태
 */
enum class TestStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    SKIPPED,
    PAUSED
};

/**
 * @brief 실시간 테스트 상태
 */
struct RealtimeTestStatus {
    std::string testId;
    std::string testName;
    TestStatus status;
    double progressPercent;
    std::chrono::milliseconds elapsedTime;
    std::string currentPhase;
    std::vector<std::string> recentLogs;
    
    RealtimeTestStatus()
        : status(TestStatus::PENDING)
        , progressPercent(0.0)
        , elapsedTime(0) {}
    
    /**
     * @brief JSON으로 변환
     */
    json ToJSON() const;
};

/**
 * @brief 모니터 제어 명령
 */
enum class MonitorCommand {
    PAUSE,
    RESUME,
    STOP,
    SKIP_CURRENT,
    INCREASE_VERBOSITY,
    DECREASE_VERBOSITY,
    TAKE_SNAPSHOT,
    EXPORT_LOGS
};

/**
 * @brief 실시간 모니터 (싱글톤)
 */
class RealtimeMonitor {
private:
    static RealtimeMonitor* instance_;
    
    // 모니터링 상태
    std::atomic<bool> isRunning_;
    std::atomic<bool> isPaused_;
    std::atomic<bool> shouldStop_;
    
    // 이벤트 큐
    std::queue<MonitorEvent> eventQueue_;
    std::mutex eventMutex_;
    
    // 현재 상태
    RealtimeMetrics metrics_;
    std::map<std::string, RealtimeTestStatus> testStatuses_;
    std::mutex statusMutex_;
    
    // 이벤트 핸들러
    std::vector<std::function<void(const MonitorEvent&)>> eventHandlers_;
    std::mutex handlerMutex_;
    
    // 업데이트 스레드
    std::unique_ptr<std::thread> updateThread_;
    std::unique_ptr<std::thread> eventThread_;
    
    // 설정
    std::chrono::milliseconds updateInterval_;
    int maxRecentLogs_;
    bool enableConsoleOutput_;
    bool enableFileOutput_;
    std::string logFilePath_;
    
    RealtimeMonitor()
        : isRunning_(false)
        , isPaused_(false)
        , shouldStop_(false)
        , updateInterval_(100)
        , maxRecentLogs_(50)
        , enableConsoleOutput_(true)
        , enableFileOutput_(false)
        , logFilePath_("realtime_monitor.log") {}
    
    /**
     * @brief 업데이트 루프
     */
    void UpdateLoop();
    
    /**
     * @brief 이벤트 처리 루프
     */
    void EventLoop();
    
    /**
     * @brief 성능 메트릭 수집
     */
    void CollectMetrics();
    
    /**
     * @brief 콘솔 출력
     */
    void PrintToConsole();
    
public:
    static RealtimeMonitor& Instance() {
        if (!instance_) {
            instance_ = new RealtimeMonitor();
        }
        return *instance_;
    }
    
    /**
     * @brief 모니터링 시작
     */
    void Start();
    
    /**
     * @brief 모니터링 중지
     */
    void Stop();
    
    /**
     * @brief 일시정지
     */
    void Pause() {
        isPaused_ = true;
        PushEvent(MonitorEvent(
            MonitorEventType::USER_ACTION,
            "",
            "Monitoring paused by user"
        ));
    }
    
    /**
     * @brief 재개
     */
    void Resume() {
        isPaused_ = false;
        PushEvent(MonitorEvent(
            MonitorEventType::USER_ACTION,
            "",
            "Monitoring resumed by user"
        ));
    }
    
    /**
     * @brief 이벤트 푸시
     */
    void PushEvent(const MonitorEvent& event) {
        std::lock_guard<std::mutex> lock(eventMutex_);
        eventQueue_.push(event);
    }
    
    /**
     * @brief 테스트 시작 알림
     */
    void NotifyTestStarted(const std::string& testId, const std::string& testName) {
        std::lock_guard<std::mutex> lock(statusMutex_);
        
        RealtimeTestStatus status;
        status.testId = testId;
        status.testName = testName;
        status.status = TestStatus::RUNNING;
        testStatuses_[testId] = status;
        
        metrics_.totalTests++;
        
        PushEvent(MonitorEvent(
            MonitorEventType::TEST_STARTED,
            testId,
            "Test started: " + testName
        ));
    }
    
    /**
     * @brief 테스트 진행 업데이트
     */
    void NotifyTestProgress(const std::string& testId, double percent, 
                           const std::string& phase) {
        std::lock_guard<std::mutex> lock(statusMutex_);
        
        auto it = testStatuses_.find(testId);
        if (it != testStatuses_.end()) {
            it->second.progressPercent = percent;
            it->second.currentPhase = phase;
        }
        
        MonitorEvent event(MonitorEventType::TEST_PROGRESS, testId, "");
        event.data = {
            {"progress", percent},
            {"phase", phase}
        };
        PushEvent(event);
    }
    
    /**
     * @brief 테스트 완료 알림
     */
    void NotifyTestCompleted(const std::string& testId, bool success) {
        std::lock_guard<std::mutex> lock(statusMutex_);
        
        auto it = testStatuses_.find(testId);
        if (it != testStatuses_.end()) {
            it->second.status = success ? TestStatus::COMPLETED : TestStatus::FAILED;
            it->second.progressPercent = 100.0;
        }
        
        if (success) {
            metrics_.completedTests++;
        } else {
            metrics_.failedTests++;
        }
        
        PushEvent(MonitorEvent(
            success ? MonitorEventType::TEST_COMPLETED : MonitorEventType::TEST_FAILED,
            testId,
            success ? "Test completed successfully" : "Test failed"
        ));
    }
    
    /**
     * @brief 로그 메시지 추가
     */
    void NotifyLog(const std::string& testId, const std::string& message) {
        std::lock_guard<std::mutex> lock(statusMutex_);
        
        auto it = testStatuses_.find(testId);
        if (it != testStatuses_.end()) {
            it->second.recentLogs.push_back(message);
            if (it->second.recentLogs.size() > static_cast<size_t>(maxRecentLogs_)) {
                it->second.recentLogs.erase(it->second.recentLogs.begin());
            }
        }
        
        PushEvent(MonitorEvent(MonitorEventType::LOG_MESSAGE, testId, message));
    }
    
    /**
     * @brief 탐지 이벤트 알림
     */
    void NotifyDetection(const std::string& testId, const std::string& detectionInfo) {
        MonitorEvent event(MonitorEventType::DETECTION_EVENT, testId, "Detection event");
        event.data = json::parse(detectionInfo);
        PushEvent(event);
    }
    
    /**
     * @brief 성능 업데이트 알림
     */
    void NotifyPerformanceUpdate(const json& perfData) {
        MonitorEvent event(MonitorEventType::PERFORMANCE_UPDATE, "", "Performance update");
        event.data = perfData;
        PushEvent(event);
    }
    
    /**
     * @brief 이벤트 핸들러 등록
     */
    void RegisterEventHandler(std::function<void(const MonitorEvent&)> handler) {
        std::lock_guard<std::mutex> lock(handlerMutex_);
        eventHandlers_.push_back(handler);
    }
    
    /**
     * @brief 현재 메트릭 가져오기
     */
    RealtimeMetrics GetMetrics() const {
        std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(statusMutex_));
        return metrics_;
    }
    
    /**
     * @brief 테스트 상태 가져오기
     */
    std::vector<RealtimeTestStatus> GetTestStatuses() const {
        std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(statusMutex_));
        std::vector<RealtimeTestStatus> result;
        for (const auto& [id, status] : testStatuses_) {
            result.push_back(status);
        }
        return result;
    }
    
    /**
     * @brief 특정 테스트 상태 가져오기
     */
    RealtimeTestStatus GetTestStatus(const std::string& testId) const {
        std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(statusMutex_));
        auto it = testStatuses_.find(testId);
        if (it != testStatuses_.end()) {
            return it->second;
        }
        return RealtimeTestStatus();
    }
    
    /**
     * @brief 스냅샷 생성
     */
    json TakeSnapshot() const;
    
    /**
     * @brief 로그 내보내기
     */
    void ExportLogs(const std::string& filepath) const;
    
    /**
     * @brief 설정
     */
    void SetUpdateInterval(std::chrono::milliseconds interval) {
        updateInterval_ = interval;
    }
    
    void SetMaxRecentLogs(int count) {
        maxRecentLogs_ = count;
    }
    
    void EnableConsoleOutput(bool enable) {
        enableConsoleOutput_ = enable;
    }
    
    void EnableFileOutput(bool enable, const std::string& filepath = "") {
        enableFileOutput_ = enable;
        if (!filepath.empty()) {
            logFilePath_ = filepath;
        }
    }
    
    /**
     * @brief 실행 중 여부
     */
    bool IsRunning() const {
        return isRunning_;
    }
    
    /**
     * @brief 일시정지 여부
     */
    bool IsPaused() const {
        return isPaused_;
    }
    
    /**
     * @brief 초기화
     */
    void Reset() {
        std::lock_guard<std::mutex> lock(statusMutex_);
        metrics_ = RealtimeMetrics();
        testStatuses_.clear();
        
        while (!eventQueue_.empty()) {
            eventQueue_.pop();
        }
    }
};

/**
 * @brief 실시간 모니터 유틸리티 클래스
 */
class MonitorUtils {
public:
    /**
     * @brief 진행률 바 생성
     */
    static std::string CreateProgressBar(double percent, int width = 50);
    
    /**
     * @brief 시간 포맷팅
     */
    static std::string FormatDuration(std::chrono::milliseconds duration);
    
    /**
     * @brief 바이트 크기 포맷팅
     */
    static std::string FormatBytes(size_t bytes);
    
    /**
     * @brief 컬러 콘솔 출력
     */
    static void PrintColored(const std::string& text, int colorCode);
    
    /**
     * @brief 콘솔 클리어
     */
    static void ClearConsole();
    
    /**
     * @brief 커서 위치 설정
     */
    static void SetCursorPosition(int x, int y);
};

/**
 * @brief WebSocket 서버 (실시간 웹 대시보드용)
 */
class MonitorWebSocketServer {
private:
    std::atomic<bool> isRunning_;
    std::unique_ptr<std::thread> serverThread_;
    int port_;
    
    void ServerLoop();
    
public:
    MonitorWebSocketServer(int port = 8080) 
        : isRunning_(false), port_(port) {}
    
    /**
     * @brief 서버 시작
     */
    void Start();
    
    /**
     * @brief 서버 중지
     */
    void Stop();
    
    /**
     * @brief 클라이언트에게 이벤트 브로드캐스트
     */
    void BroadcastEvent(const MonitorEvent& event);
    
    /**
     * @brief 현재 상태 브로드캐스트
     */
    void BroadcastStatus(const RealtimeMetrics& metrics,
                        const std::vector<RealtimeTestStatus>& statuses);
};

} // namespace EDR
