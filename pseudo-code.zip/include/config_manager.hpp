/**
 * @file config_manager.hpp
 * @brief 중앙화된 설정 관리 시스템 (Centralized Configuration Management System)
 * @details
 * JSON 기반 설정 파일 관리:
 * - 프로파일 지원 (개발/테스트/프로덕션)
 * - 테스트 시나리오 커스터마이징
 * - 실행 옵션 및 타임아웃 설정
 * - 로깅 설정
 * - 안전성 설정
 * - 환경 변수 오버라이드
 * 
 * 사용 예제:
 * @code
 * ConfigManager& config = ConfigManager::Instance();
 * config.LoadFromFile("config.json");
 * 
 * int timeout = config.GetExecutionTimeout();
 * std::vector<std::string> techniques = config.GetEnabledTechniques("process_injection");
 * @endcode
 */

#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#ifdef ERROR
#undef ERROR
#endif
#ifdef DEBUG
#undef DEBUG
#endif
#include <string>
#include <map>
#include <vector>
#include <fstream>
#include <sstream>
// Use the bundled single-header json to avoid external include dependency
#include "json.hpp"
#include "logger.hpp"
#include "error_handling.hpp"

namespace EDR {

using json = nlohmann::json;

/**
 * @class ConfigManager
 * @brief 싱글톤 패턴 기반 설정 관리 클래스
 */
class ConfigManager {
private:
    // 싱글톤 인스턴스
    inline static ConfigManager* instance_ = nullptr;
    
    // 설정 데이터
    json config_;
    std::string configFilePath_;
    std::string currentProfile_;
    
    // 프라이빗 생성자 (싱글톤)
    ConfigManager() 
        : configFilePath_("config.json")
        , currentProfile_("default") {
        LoadDefaults();
    }
    
    // 복사 생성자 및 대입 연산자 삭제
    ConfigManager(const ConfigManager&) = delete;
    ConfigManager& operator=(const ConfigManager&) = delete;
    
    /**
     * @brief 기본 설정 로드
     */
    void LoadDefaults() {
        config_ = {
            {"version", "1.0"},
            {"profile", "default"},
            {"execution", {
                {"timeout_seconds", 60},
                {"retry_count", 3},
                {"delay_between_tests_ms", 1000},
                {"max_concurrent_tests", 1},
                {"stop_on_first_failure", false}
            }},
            {"logging", {
                {"level", "INFO"},
                {"output_file", "logs/edr_test.log"},
                {"format", "json"},
                {"max_file_size_mb", 10},
                {"max_files", 5},
                {"enable_console", true}
            }},
            {"test_scenarios", {
                {"process_injection", {
                    {"enabled", true},
                    {"techniques", json::array({"dll_injection", "process_hollowing", "apc_injection"})}
                }},
                {"fileless", {
                    {"enabled", true},
                    {"techniques", json::array({"memory_execution", "wmi_execution"})}
                }},
                {"shellcode", {
                    {"enabled", true},
                    {"techniques", json::array({"shellcode_injection"})}
                }}
            }},
            {"safety", {
                {"require_confirmation", true},
                {"sandbox_check", true},
                {"allowed_targets", json::array({"notepad.exe", "calc.exe"})},
                {"max_execution_time_seconds", 300},
                {"enable_cleanup", true}
            }},
            {"performance", {
                {"enable_monitoring", true},
                {"export_format", "csv"},
                {"export_path", "reports/performance"}
            }},
            {"detection", {
                {"enable_validation", true},
                {"etw_providers", json::array({"Microsoft-Windows-Kernel-Process"})},
                {"sysmon_enabled", true},
                {"windows_event_log_enabled", true}
            }},
            {"reporting", {
                {"auto_generate", true},
                {"formats", json::array({"html", "json", "csv"})},
                {"output_directory", "reports"},
                {"include_screenshots", false}
            }}
        };
    }
    
public:
    /**
     * @brief 싱글톤 인스턴스 획득
     */
    static ConfigManager& Instance() {
        if (instance_ == nullptr) {
            instance_ = new ConfigManager();
        }
        return *instance_;
    }
    
    /**
     * @brief 설정 파일 로드
     * @param filepath 설정 파일 경로
     * @return 성공 시 true
     */
    bool LoadFromFile(const std::string& filepath) {
        try {
            std::ifstream file(filepath);
            if (!file.is_open()) {
                EDR::Logger::Instance().Warn("Config file not found, using defaults: " + filepath);
                return false;
            }
            
            config_ = json::parse(file);
            configFilePath_ = filepath;
            
            // 프로파일 설정
            if (config_.contains("profile")) {
                currentProfile_ = config_["profile"].get<std::string>();
            }
            
            EDR::Logger::Instance().Info("Configuration loaded from: " + filepath);
            EDR::Logger::Instance().Info("Active profile: " + currentProfile_);
            
            return true;
            
        } catch (const json::parse_error& e) {
            EDR::Logger::Instance().Error("Failed to parse config file: " + std::string(e.what()));
            return false;
        } catch (const std::exception& e) {
            EDR::Logger::Instance().Error("Failed to load config file: " + std::string(e.what()));
            return false;
        }
    }
    
    /**
     * @brief 설정을 파일로 저장
     * @param filepath 저장할 파일 경로 (기본값: 현재 설정 파일)
     * @return 성공 시 true
     */
    bool SaveToFile(const std::string& filepath = "") {
        try {
            std::string savePath = filepath.empty() ? configFilePath_ : filepath;
            
            std::ofstream file(savePath);
            if (!file.is_open()) {
                EDR::Logger::Instance().Error("Failed to open config file for writing: " + savePath);
                return false;
            }
            
            file << config_.dump(2);  // Pretty print with 2 spaces
            file.close();
            
            EDR::Logger::Instance().Info("Configuration saved to: " + savePath);
            return true;
            
        } catch (const std::exception& e) {
            EDR::Logger::Instance().Error("Failed to save config file: " + std::string(e.what()));
            return false;
        }
    }
    
    /**
     * @brief 프로파일 전환
     * @param profileName 프로파일 이름
     */
    void SetProfile(const std::string& profileName) {
        currentProfile_ = profileName;
        config_["profile"] = profileName;
    EDR::Logger::Instance().Info("Profile changed to: " + profileName);
    }
    
    /**
     * @brief 현재 프로파일 조회
     */
    std::string GetProfile() const {
        return currentProfile_;
    }
    
    // ===== Execution Settings =====
    
    int GetExecutionTimeout() const {
        return config_["execution"]["timeout_seconds"].get<int>();
    }
    
    void SetExecutionTimeout(int seconds) {
        config_["execution"]["timeout_seconds"] = seconds;
    }
    
    int GetRetryCount() const {
        return config_["execution"]["retry_count"].get<int>();
    }
    
    void SetRetryCount(int count) {
        config_["execution"]["retry_count"] = count;
    }
    
    int GetDelayBetweenTests() const {
        return config_["execution"]["delay_between_tests_ms"].get<int>();
    }
    
    void SetDelayBetweenTests(int milliseconds) {
        config_["execution"]["delay_between_tests_ms"] = milliseconds;
    }
    
    int GetMaxConcurrentTests() const {
        return config_["execution"]["max_concurrent_tests"].get<int>();
    }
    
    bool GetStopOnFirstFailure() const {
        return config_["execution"]["stop_on_first_failure"].get<bool>();
    }
    
    // ===== Logging Settings =====
    
    std::string GetLoggingLevel() const {
        return config_["logging"]["level"].get<std::string>();
    }
    
    void SetLoggingLevel(const std::string& level) {
        config_["logging"]["level"] = level;
    }
    
    std::string GetLogOutputFile() const {
        return config_["logging"]["output_file"].get<std::string>();
    }
    
    std::string GetLogFormat() const {
        return config_["logging"]["format"].get<std::string>();
    }
    
    int GetMaxLogFileSize() const {
        return config_["logging"]["max_file_size_mb"].get<int>();
    }
    
    int GetMaxLogFiles() const {
        return config_["logging"]["max_files"].get<int>();
    }
    
    bool GetEnableConsoleLogging() const {
        return config_["logging"]["enable_console"].get<bool>();
    }
    
    // ===== Test Scenarios =====
    
    bool IsScenarioEnabled(const std::string& scenarioName) const {
        if (!config_["test_scenarios"].contains(scenarioName)) {
            return false;
        }
        return config_["test_scenarios"][scenarioName]["enabled"].get<bool>();
    }
    
    void SetScenarioEnabled(const std::string& scenarioName, bool enabled) {
        if (!config_["test_scenarios"].contains(scenarioName)) {
            config_["test_scenarios"][scenarioName] = {
                {"enabled", enabled},
                {"techniques", json::array()}
            };
        } else {
            config_["test_scenarios"][scenarioName]["enabled"] = enabled;
        }
    }
    
    std::vector<std::string> GetEnabledTechniques(const std::string& scenarioName) const {
        std::vector<std::string> techniques;
        
        if (!config_["test_scenarios"].contains(scenarioName)) {
            return techniques;
        }
        
        if (!IsScenarioEnabled(scenarioName)) {
            return techniques;
        }
        
        const auto& techList = config_["test_scenarios"][scenarioName]["techniques"];
        for (const auto& tech : techList) {
            techniques.push_back(tech.get<std::string>());
        }
        
        return techniques;
    }
    
    std::vector<std::string> GetAllEnabledTechniques() const {
        std::vector<std::string> allTechniques;
        
        for (const auto& [scenarioName, scenarioData] : config_["test_scenarios"].items()) {
            if (scenarioData["enabled"].get<bool>()) {
                for (const auto& tech : scenarioData["techniques"]) {
                    allTechniques.push_back(tech.get<std::string>());
                }
            }
        }
        
        return allTechniques;
    }
    
    void AddTechnique(const std::string& scenarioName, const std::string& techniqueName) {
        if (!config_["test_scenarios"].contains(scenarioName)) {
            config_["test_scenarios"][scenarioName] = {
                {"enabled", true},
                {"techniques", json::array({techniqueName})}
            };
        } else {
            config_["test_scenarios"][scenarioName]["techniques"].push_back(techniqueName);
        }
    }
    
    // ===== Safety Settings =====
    
    bool GetRequireConfirmation() const {
        return config_["safety"]["require_confirmation"].get<bool>();
    }
    
    void SetRequireConfirmation(bool require) {
        config_["safety"]["require_confirmation"] = require;
    }
    
    bool GetSandboxCheck() const {
        return config_["safety"]["sandbox_check"].get<bool>();
    }
    
    void SetSandboxCheck(bool enable) {
        config_["safety"]["sandbox_check"] = enable;
    }
    
    std::vector<std::string> GetAllowedTargets() const {
        std::vector<std::string> targets;
        for (const auto& target : config_["safety"]["allowed_targets"]) {
            targets.push_back(target.get<std::string>());
        }
        return targets;
    }
    
    bool IsTargetAllowed(const std::string& targetName) const {
        for (const auto& target : config_["safety"]["allowed_targets"]) {
            if (target.get<std::string>() == targetName) {
                return true;
            }
        }
        return false;
    }
    
    int GetMaxExecutionTime() const {
        return config_["safety"]["max_execution_time_seconds"].get<int>();
    }
    
    bool GetEnableCleanup() const {
        return config_["safety"]["enable_cleanup"].get<bool>();
    }
    
    // ===== Performance Settings =====
    
    bool GetEnablePerformanceMonitoring() const {
        return config_["performance"]["enable_monitoring"].get<bool>();
    }
    
    void SetEnablePerformanceMonitoring(bool enable) {
        config_["performance"]["enable_monitoring"] = enable;
    }
    
    std::string GetPerformanceExportFormat() const {
        return config_["performance"]["export_format"].get<std::string>();
    }
    
    std::string GetPerformanceExportPath() const {
        return config_["performance"]["export_path"].get<std::string>();
    }
    
    // ===== Detection Settings =====
    
    bool GetEnableDetectionValidation() const {
        return config_["detection"]["enable_validation"].get<bool>();
    }
    
    void SetEnableDetectionValidation(bool enable) {
        config_["detection"]["enable_validation"] = enable;
    }
    
    std::vector<std::string> GetETWProviders() const {
        std::vector<std::string> providers;
        for (const auto& provider : config_["detection"]["etw_providers"]) {
            providers.push_back(provider.get<std::string>());
        }
        return providers;
    }
    
    bool GetSysmonEnabled() const {
        return config_["detection"]["sysmon_enabled"].get<bool>();
    }
    
    bool GetWindowsEventLogEnabled() const {
        return config_["detection"]["windows_event_log_enabled"].get<bool>();
    }
    
    // ===== Reporting Settings =====
    
    bool GetAutoGenerateReports() const {
        return config_["reporting"]["auto_generate"].get<bool>();
    }
    
    void SetAutoGenerateReports(bool enable) {
        config_["reporting"]["auto_generate"] = enable;
    }
    
    std::vector<std::string> GetReportFormats() const {
        std::vector<std::string> formats;
        for (const auto& format : config_["reporting"]["formats"]) {
            formats.push_back(format.get<std::string>());
        }
        return formats;
    }
    
    std::string GetReportOutputDirectory() const {
        return config_["reporting"]["output_directory"].get<std::string>();
    }
    
    bool GetIncludeScreenshots() const {
        return config_["reporting"]["include_screenshots"].get<bool>();
    }
    
    // ===== Generic Accessors =====
    
    /**
     * @brief JSON 경로로 값 조회
     * @param path JSON 경로 (예: "execution.timeout_seconds")
     * @return JSON 값
     */
    json GetValue(const std::string& path) const {
        std::vector<std::string> keys;
        std::stringstream ss(path);
        std::string key;
        
        while (std::getline(ss, key, '.')) {
            keys.push_back(key);
        }
        
        json current = config_;
        for (const auto& k : keys) {
            if (!current.contains(k)) {
                throw Exception(ErrorCode::INVALID_PARAMETER, 
                               "Config path not found: " + path);
            }
            current = current[k];
        }
        
        return current;
    }
    
    /**
     * @brief JSON 경로로 값 설정
     * @param path JSON 경로
     * @param value 설정할 값
     */
    void SetValue(const std::string& path, const json& value) {
        std::vector<std::string> keys;
        std::stringstream ss(path);
        std::string key;
        
        while (std::getline(ss, key, '.')) {
            keys.push_back(key);
        }
        
        json* current = &config_;
        for (size_t i = 0; i < keys.size() - 1; ++i) {
            if (!current->contains(keys[i])) {
                (*current)[keys[i]] = json::object();
            }
            current = &(*current)[keys[i]];
        }
        
        (*current)[keys.back()] = value;
    }
    
    /**
     * @brief 전체 설정을 JSON 객체로 반환
     */
    const json& GetConfig() const {
        return config_;
    }
    
    /**
     * @brief 설정 요약 출력
     */
    void PrintSummary() const {
    EDR::Logger::Instance().Info("=== Configuration Summary ===");
    EDR::Logger::Instance().Info("Profile: " + currentProfile_);
    EDR::Logger::Instance().Info("Execution Timeout: " + 
                   std::to_string(GetExecutionTimeout()) + "s");
    EDR::Logger::Instance().Info("Logging Level: " + GetLoggingLevel());
    EDR::Logger::Instance().Info("Safety Checks: " + 
                   std::string(GetSandboxCheck() ? "Enabled" : "Disabled"));
    EDR::Logger::Instance().Info("Performance Monitoring: " + 
                   std::string(GetEnablePerformanceMonitoring() ? "Enabled" : "Disabled"));
    EDR::Logger::Instance().Info("Detection Validation: " + 
                   std::string(GetEnableDetectionValidation() ? "Enabled" : "Disabled"));
        
        auto techniques = GetAllEnabledTechniques();
    EDR::Logger::Instance().Info("Enabled Techniques: " + std::to_string(techniques.size()));
    }
    
    /**
     * @brief 환경 변수로 설정 오버라이드
     * @details EDR_CONFIG_* 형식의 환경 변수로 설정 값 오버라이드
     * 예: EDR_CONFIG_EXECUTION_TIMEOUT=120
     */
    void ApplyEnvironmentVariableOverrides() {
        // 주요 설정에 대한 환경 변수 체크
        char buffer[1024];
        
        if (GetEnvironmentVariableA("EDR_CONFIG_EXECUTION_TIMEOUT", buffer, sizeof(buffer))) {
            SetExecutionTimeout(std::atoi(buffer));
            EDR::Logger::Instance().Info("Environment override: execution timeout = " + std::string(buffer));
        }
        
        if (GetEnvironmentVariableA("EDR_CONFIG_LOGGING_LEVEL", buffer, sizeof(buffer))) {
            SetLoggingLevel(buffer);
            EDR::Logger::Instance().Info("Environment override: logging level = " + std::string(buffer));
        }
        
        if (GetEnvironmentVariableA("EDR_CONFIG_SANDBOX_CHECK", buffer, sizeof(buffer))) {
            SetSandboxCheck(std::string(buffer) == "true" || std::string(buffer) == "1");
            EDR::Logger::Instance().Info("Environment override: sandbox check = " + std::string(buffer));
        }
    }
};

// 정적 멤버 초기화


} // namespace EDR
